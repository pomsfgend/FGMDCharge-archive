// pins.h — ESP32-S3-N16R8, smart-ebike. DRAFT: пины предварительные, ждём подтверждения BoB.
#pragma once
// Консоль: родной USB CDC (GPIO19/20), нужен флаг ARDUINO_USB_CDC_ON_BOOT=1
#if !defined(ARDUINO_USB_CDC_ON_BOOT) || (ARDUINO_USB_CDC_ON_BOOT != 1)
#warning "Console not on USB CDC: UART0 log will collide with Votol"
#endif

// BMS1 JBD SP24S004 — UART1, 9600 8N1, через изолятор (ADuM1201)
#define PIN_BMS1_TX   17
#define PIN_BMS1_RX   18
// BMS2 JBD SP24S004 — UART2, 9600 8N1, через отдельный изолятор
#define PIN_BMS2_TX   41   // предварительно (альтернатива 8/9)
#define PIN_BMS2_RX   42
// Votol EM50-4 (CAN-версия) — UART0, разъём 16-pin: конт.10 TX Votol -> RX ESP, конт.11 RX Votol <- TX ESP
// Логика ~3,3 В (документация 0–5 В): на RX ESP делитель/сдвиг уровня. Только чтение, в контроллер ничего не пишем.
#define PIN_VOTOL_TX  4    // предварительно
#define PIN_VOTOL_RX  5
// Тормоз: убран со схемы, берётся из байта 20 бит 4 ответа Votol. GPIO14, 15 в запасе.
// Дисплей (из docs/WIRING.md)
#define PIN_DISP_DC   16

// --- Проверки при компиляции (Def допишет полный список) ---
#define _FORBIDDEN(p) ((p)==0||(p)==3||(p)==19||(p)==20||((p)>=26&&(p)<=37)||(p)==45||(p)==46)
static_assert(!_FORBIDDEN(PIN_BMS1_TX) && !_FORBIDDEN(PIN_BMS1_RX), "BMS1 on forbidden pin");
static_assert(!_FORBIDDEN(PIN_BMS2_TX) && !_FORBIDDEN(PIN_BMS2_RX), "BMS2 on forbidden pin");
static_assert(!_FORBIDDEN(PIN_VOTOL_TX) && !_FORBIDDEN(PIN_VOTOL_RX), "Votol on forbidden pin");
static_assert(!_FORBIDDEN(PIN_DISP_DC), "IO on forbidden pin");
