package me.cube.cabin;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.RippleDrawable;
import android.os.SystemClock;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiNetworkSpecifier;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String BASE = "http://192.168.4.1";
    private static int BG = 0xFF090C12;
    private static int CARD = 0xFF131925;
    private static int CARD_HI = 0xFF1B2332;
    private static int LINE = 0xFF283142;
    private static int FG = 0xFFF1F4FA;
    private static int MUTED = 0xFF8E99AE;
    private static int COPPER = 0xFFFFB02E;
    private static int INK = 0xFF1A1205;
    private static final int OK = 0xFF3DDC97;
    private static final int BAD = 0xFFFF5D5D;
    private static final int COOL = 0xFF54C7EC;
    private static final int[] REG = {16, 17, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 47};
    private static final String[] REG_NAME = {
            "Ёмкость, Ач", "Цикл, Ач", "Пакет, перезаряд", "Пакет, возврат заряда",
            "Пакет, разряд", "Пакет, возврат разряда", "Ячейка, перезаряд", "Ячейка, возврат заряда",
            "Ячейка, разряд", "Ячейка, возврат разряда", "Ток заряда, А", "Ток разряда, А",
            "Баланс от, В", "Окно баланса, мВ", "Число ячеек"
    };
    private static final String[] REG_KIND = {
            "ah", "ah", "packv", "packv", "packv", "packv", "cellv", "cellv",
            "cellv", "cellv", "amp", "amp", "cellv", "mv", "n"
    };

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService net = Executors.newCachedThreadPool();
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback callback;
    private volatile Network cubeNet;
    private volatile boolean polling;
    private volatile boolean proxyRun;
    private boolean touching;
    private boolean wantConnect;
    private int tickN;
    private int bmsPack;
    private int proxyPort = -1;
    private double gpsKmh = -1;
    private double cubeKmh = -1;
    private ServerSocket proxy;
    private WebView web;
    private LocationManager locations;

    private TextView status;
    private View linkDot;
    private Gauge gauge;
    private TextView mDuty;
    private TextView mRate;
    private TextView mHz;
    private long holdUntil;
    private boolean resumePoll;
    private final LinearLayout[] tabBox = new LinearLayout[6];
    private final TabIcon[] tabIcon = new TabIcon[6];
    private final TextView[] tabText = new TextView[6];
    private TextView amb;
    private TextView lux;
    private TextView seat;
    private TextView duty;
    private TextView pwmVal;
    private TextView ambVal;
    private TextView comfVal;
    private TextView ceilVal;
    private TextView ampVal;
    private TextView eveVal;
    private TextView dayVal;
    private TextView speedCube;
    private TextView speedGps;
    private TextView motorMeta;
    private TextView bleNow;
    private LinearLayout cellsBox;
    private View speedFill;
    private TextView zvs;
    private TextView note;
    private TextView home;
    private TextView motorNow;
    private TextView bmsHead;
    private TextView cubeInfo;
    private Button heat;
    private Button[] heatMode = new Button[2];
    private static final int[] AUTO_OFF = {0, 30, 60, 90, 120};
    private final Button[] autoBtn = new Button[5];
    private Button[] light = new Button[3];
    private Button[] relay = new Button[1];
    private TextView par;
    private View[] pages = new View[6];
    private TextView sessionView;
    private int sessionTick;
    private Button in6;
    private Button in7;
    private View dutyFill;
    private SeekBar comfort;
    private SeekBar ceiling;
    private SeekBar manualDuty;
    private SeekBar ambOn;
    private SeekBar amps;
    private SeekBar bright;
    private SeekBar eve;
    private SeekBar day;
    private Button turnBtn;
    private EditText circ;
    private EditText diam;
    private EditText gear;
    private EditText poles;
    private EditText trim;
    private EditText reqA;
    private EditText reqVin;
    private TextView capLine;
    private EditText capAh;
    private EditText capWh;
    private EditText capSoc;
    private Button capBms;
    private Button capMan;
    private int capSrcWant;
    private TextView dwellVal;
    private SeekBar dwellBar;
    private Button cycleAuto;
    private Button cycleHand;
    private Button[] pagePick = new Button[5];
    private TextView sesLine;
    private TextView batNow, batPeak, batHi, batLo, batRem, batAfter;
    private LinearLayout ownHost;
    private final java.util.ArrayList<TextView> mineLive = new java.util.ArrayList<>();
    private double sesPeakA, sesMaxV, sesMinV, sesAfter;
    private boolean sesHave;
    private String lineNow = "нет связи";
    private String linePeak = "0.00";
    private String lineHi = "0.0";
    private String lineLo = "0.0";
    private String lineRem = "—";
    private String lineAfter = "ещё не было";
    private int seenLight = 2;
    private int seenLux = 18;
    private int seenRel;
    private int seenA;
    private int seenB;
    private TextView[] regNow = new TextView[REG.length];
    private EditText[] regIn = new EditText[REG.length];

    private Location prevFix;
    private int bleRole = -1;
    private LinearLayout fdList;
    private LinearLayout wifiNets;
    private TextView logBox;
    private EditText homePass;
    private EditText apName;
    private EditText apPass;
    private final LocationListener gps = new LocationListener() {
        @Override public void onLocationChanged(Location location) {
            if (location == null) return;
            double v = location.hasSpeed() ? Math.max(0, location.getSpeed() * 3.6) : -1;
            if (prevFix != null) {
                long dt = location.getTime() - prevFix.getTime();
                if (dt >= 400) {
                    double calc = location.distanceTo(prevFix) / (dt / 1000.0) * 3.6;
                    if (v < 0.5) v = calc;
                }
            }
            prevFix = new Location(location);
            if (v >= 0) gpsKmh = v;
            ui.post(MainActivity.this::paintGps);
        }
        @Override public void onStatusChanged(String p, int s, android.os.Bundle b) {}
        @Override public void onProviderEnabled(String p) {}
        @Override public void onProviderDisabled(String p) {}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        locations = (LocationManager) getSystemService(LOCATION_SERVICE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(CARD);
        applySkin(getSharedPreferences("cabin85", MODE_PRIVATE).getInt("skin", 0));
        setContentView(build());
        int open = getSharedPreferences("cabin85", MODE_PRIVATE).getInt("tab", 0);
        show(open >= 0 && open < pages.length ? open : 0);
        startProxy();
        status.setText("Не подключено");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (resumePoll) {
            resumePoll = false;
            startPoll();
        }
        if (hasLocation()) startGps();
    }

    /* Nothing runs while the screen is not in front: no polling, no GPS. */
    @Override
    protected void onPause() {
        if (polling) resumePoll = true;
        polling = false;
        ui.removeCallbacksAndMessages(null);
        if (locations != null) {
            try { locations.removeUpdates(gps); } catch (Exception ignored) {}
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        polling = false;
        proxyRun = false;
        if (callback != null && cm != null) {
            try { cm.unregisterNetworkCallback(callback); } catch (Exception ignored) {}
        }
        if (locations != null) {
            try { locations.removeUpdates(gps); } catch (Exception ignored) {}
        }
        if (proxy != null) {
            try { proxy.close(); } catch (Exception ignored) {}
        }
        if (web != null) web.destroy();
        net.shutdownNow();
        super.onDestroy();
    }

    private String ver() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    private void setLink(int state) {
        if (linkDot == null) return;
        if (gauge != null) gauge.setLinked(state > 0);
        int c = state > 0 ? OK : (state < 0 ? BAD : MUTED);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(c);
        linkDot.setBackground(d);
    }

    private View build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout head = row();
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(18), dp(14), dp(14), dp(8));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        LinearLayout titleRow = flat();
        titleRow.setGravity(Gravity.BOTTOM);
        titleRow.addView(label("Кабина", 26, FG, true));
        TextView vv = label(" " + ver(), 12, MUTED, false);
        vv.setPadding(dp(6), 0, 0, dp(4));
        titleRow.addView(vv);
        titles.addView(titleRow);
        LinearLayout st = flat();
        st.setGravity(Gravity.CENTER_VERTICAL);
        st.setPadding(0, dp(2), 0, 0);
        linkDot = new View(this);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(8), dp(8));
        dl.rightMargin = dp(8);
        linkDot.setLayoutParams(dl);
        setLink(0);
        st.addView(linkDot);
        status = label("Открываю…", 12, MUTED, false);
        status.setSingleLine(true);
        status.setEllipsize(android.text.TextUtils.TruncateAt.END);
        st.addView(status);
        titles.addView(st);
        head.addView(titles, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button join = button("Подключить", true);
        join.setOnClickListener(v -> connect());
        LinearLayout.LayoutParams jl = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        join.setPadding(dp(16), dp(9), dp(16), dp(9));
        join.setLayoutParams(jl);
        head.addView(join);
        root.addView(head);

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        frame.setClipChildren(true);
        frame.setPadding(dp(12), 0, dp(12), 0);
        pages[0] = scroll(pageCabin());
        pages[1] = scroll(pageMotor());
        pages[2] = scroll(pageBms());
        pages[3] = scroll(pageCube());
        pages[4] = scroll(pageSession());
        pages[5] = scroll(pageMine());
        for (View p : pages) {
            frame.addView(p, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        }
        root.addView(frame, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout nav = flat();
        nav.setBackgroundColor(CARD);
        nav.setPadding(dp(4), dp(6), dp(4), dp(6));
        nav.setElevation(dp(8));
        String[] names = {"Кабина", "Мотор", "АКБ", "Куб", "Сессия", "Свои"};
        for (int i = 0; i < names.length; i++) {
            final int n = i;
            LinearLayout tab = new LinearLayout(this);
            tab.setOrientation(LinearLayout.VERTICAL);
            tab.setGravity(Gravity.CENTER_HORIZONTAL);
            tab.setPadding(0, dp(6), 0, dp(4));
            tabIcon[i] = new TabIcon(this, i);
            tab.addView(tabIcon[i], new LinearLayout.LayoutParams(dp(26), dp(26)));
            tabText[i] = label(names[i], 11, MUTED, false);
            tabText[i].setGravity(Gravity.CENTER);
            tab.addView(tabText[i]);
            tab.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22FFFFFF), null, null));
            tab.setOnClickListener(v -> show(n));
            tabBox[i] = tab;
            nav.addView(tab, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
        root.addView(nav);
        return root;
    }

    /* Ring gauge for the seat: value, target mark, heater duty. */
    private final class Gauge extends View {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mark = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF box = new RectF();
        private int seatV = -32768;
        private int target = 3200;
        private int maxV = 4200;
        private int duty;
        private int rate;
        private String fault = "";
        private boolean on;
        private boolean linked;
        private float shown;

        Gauge(android.content.Context c) {
            super(c);
            track.setStyle(Paint.Style.STROKE);
            track.setStrokeCap(Paint.Cap.ROUND);
            track.setStrokeWidth(dp(14));
            track.setColor(CARD_HI);
            arc.setStyle(Paint.Style.STROKE);
            arc.setStrokeCap(Paint.Cap.ROUND);
            arc.setStrokeWidth(dp(14));
            txt.setTextAlign(Paint.Align.CENTER);
            mark.setStyle(Paint.Style.STROKE);
            mark.setStrokeCap(Paint.Cap.ROUND);
            mark.setStrokeWidth(dp(3));
            mark.setColor(FG);
        }

        void setLinked(boolean l) {
            if (linked != l) {
                linked = l;
                invalidate();
            }
        }

        void set(int seat, int tgt, int mx, int d, int r, String f, boolean heatOn) {
            seatV = seat;
            target = tgt;
            maxV = Math.max(mx, tgt + 100);
            duty = d;
            rate = r;
            fault = f == null ? "" : f;
            on = heatOn;
            float want = seat == -32768 ? 0f
                    : Math.max(0f, Math.min(1f, (seat - 500f) / Math.max(1f, maxV - 500f)));
            final float from = shown;
            android.animation.ValueAnimator va = android.animation.ValueAnimator.ofFloat(from, want);
            va.setDuration(350);
            va.addUpdateListener(a -> {
                shown = (float) a.getAnimatedValue();
                invalidate();
            });
            va.start();
        }

        @Override protected void onMeasure(int w, int h) {
            int ww = View.MeasureSpec.getSize(w);
            setMeasuredDimension(ww, Math.min(ww, dp(232)));
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float r = Math.min(w, h) / 2f - dp(16);
            float cx = w / 2f;
            float cy = h / 2f + dp(6);
            box.set(cx - r, cy - r, cx + r, cy + r);
            c.drawArc(box, 135, 270, false, track);
            int col;
            boolean bad = "seat".equals(fault) || seatV == -32768;
            if (bad) col = MUTED;
            else if ("hot".equals(fault)) col = BAD;
            else if (seatV >= target - 50) col = OK;
            else col = on || duty > 0 ? COPPER : COOL;
            arc.setColor(col);
            if (shown > 0.003f) c.drawArc(box, 135, 270 * shown, false, arc);
            if (!bad) {
                float f = Math.max(0f, Math.min(1f, (target - 500f) / Math.max(1f, maxV - 500f)));
                double ang = Math.toRadians(135 + 270 * f);
                float r1 = r - dp(14);
                float r2 = r + dp(14);
                c.drawLine(cx + (float) Math.cos(ang) * r1, cy + (float) Math.sin(ang) * r1,
                        cx + (float) Math.cos(ang) * r2, cy + (float) Math.sin(ang) * r2, mark);
            }
            txt.setColor(bad ? MUTED : FG);
            txt.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            txt.setTextSize(dp(54));
            String big = seatV == -32768 ? "—" : temp(seatV);
            c.drawText(big, cx, cy + dp(10), txt);
            txt.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            txt.setColor(MUTED);
            txt.setTextSize(dp(13));
            String sub;
            if (!linked) sub = "нет связи с кубом";
            else if ("seat".equals(fault)) sub = "нет датчика на коврике";
            else if ("hot".equals(fault)) sub = "потолок " + (maxV / 100) + "°";
            else {
                sub = "цель " + (target / 100) + "°";
                if ((on || duty > 0) && rate >= 3 && seatV != -32768 && seatV < target - 50) {
                    int min = Math.round((target - seatV) / (float) rate / 60f);
                    if (min < 1) min = 1;
                    if (min <= 60) sub += " · ещё ≈" + min + " мин";
                }
            }
            c.drawText(sub, cx, cy + dp(34), txt);
            txt.setColor(col);
            txt.setTextSize(dp(15));
            c.drawText("ШИМ " + duty + "%", cx, cy + dp(60), txt);
        }
    }

    /* Tab icons drawn in code: no image files, no extra libraries. */
    private final class TabIcon extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final int kind;
        private int color = MUTED;

        TabIcon(android.content.Context c, int k) {
            super(c);
            kind = k;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(dp(2));
        }

        void tint(int c) {
            color = c;
            invalidate();
        }

        @Override protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight());
            float u = s / 24f;
            p.setColor(color);
            path.reset();
            switch (kind) {
                case 0: /* cabin: house */
                    path.moveTo(3 * u, 11 * u); path.lineTo(12 * u, 3.5f * u); path.lineTo(21 * u, 11 * u);
                    path.moveTo(5.5f * u, 9.5f * u); path.lineTo(5.5f * u, 20 * u);
                    path.lineTo(18.5f * u, 20 * u); path.lineTo(18.5f * u, 9.5f * u);
                    path.moveTo(10 * u, 20 * u); path.lineTo(10 * u, 14 * u);
                    path.lineTo(14 * u, 14 * u); path.lineTo(14 * u, 20 * u);
                    c.drawPath(path, p);
                    break;
                case 1: /* motor: ring with spokes */
                    c.drawCircle(12 * u, 12 * u, 6 * u, p);
                    c.drawCircle(12 * u, 12 * u, 1.6f * u, p);
                    for (int i = 0; i < 8; i++) {
                        double a = Math.PI / 4 * i;
                        c.drawLine(12 * u + (float) Math.cos(a) * 8 * u, 12 * u + (float) Math.sin(a) * 8 * u,
                                12 * u + (float) Math.cos(a) * 10.5f * u, 12 * u + (float) Math.sin(a) * 10.5f * u, p);
                    }
                    break;
                case 2: /* battery */
                    c.drawRoundRect(new RectF(2.5f * u, 7 * u, 19 * u, 17 * u), 2 * u, 2 * u, p);
                    c.drawLine(21.5f * u, 10 * u, 21.5f * u, 14 * u, p);
                    path.moveTo(11.5f * u, 8.5f * u); path.lineTo(8.5f * u, 12.3f * u);
                    path.lineTo(12.5f * u, 12.3f * u); path.lineTo(9.5f * u, 15.8f * u);
                    c.drawPath(path, p);
                    break;
                case 3: /* cube */
                    path.moveTo(12 * u, 2.5f * u); path.lineTo(20.5f * u, 7.3f * u);
                    path.lineTo(20.5f * u, 16.7f * u); path.lineTo(12 * u, 21.5f * u);
                    path.lineTo(3.5f * u, 16.7f * u); path.lineTo(3.5f * u, 7.3f * u);
                    path.close();
                    path.moveTo(3.5f * u, 7.3f * u); path.lineTo(12 * u, 12 * u);
                    path.lineTo(20.5f * u, 7.3f * u);
                    path.moveTo(12 * u, 12 * u); path.lineTo(12 * u, 21.5f * u);
                    c.drawPath(path, p);
                    break;
                case 5: /* own tabs */
                    c.drawRect(new RectF(3 * u, 3 * u, 10 * u, 10 * u), p);
                    c.drawRect(new RectF(14 * u, 3 * u, 21 * u, 10 * u), p);
                    c.drawRect(new RectF(3 * u, 14 * u, 10 * u, 21 * u), p);
                    c.drawRect(new RectF(14 * u, 14 * u, 21 * u, 21 * u), p);
                    break;
                default: /* session: list */
                    for (int i = 0; i < 3; i++) {
                        float y = (6.5f + i * 5.5f) * u;
                        c.drawCircle(4.5f * u, y, 0.9f * u, p);
                        c.drawLine(9 * u, y, 21 * u, y, p);
                    }
                    break;
            }
        }
    }

    private LinearLayout pageCabin() {
        LinearLayout box = col();
        LinearLayout hero = card();
        gauge = new Gauge(this);
        hero.addView(gauge, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        box.addView(hero);
        LinearLayout metrics = row();
        metrics.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        ((LinearLayout.LayoutParams) metrics.getLayoutParams()).topMargin = dp(8);
        amb = metric(metrics, "Улица");
        lux = metric(metrics, "Свет");
        seat = metric(metrics, "Сиденье");
        box.addView(metrics);
        LinearLayout metrics2 = row();
        LinearLayout.LayoutParams m2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        m2.topMargin = dp(8);
        metrics2.setLayoutParams(m2);
        mDuty = metric(metrics2, "ШИМ");
        mRate = metric(metrics2, "Нагрев");
        mHz = metric(metrics2, "Датчик");
        box.addView(metrics2);

        LinearLayout heatCard = card();
        heatCard.addView(label("Коврик", 18, FG, true));
        note = label("", 14, MUTED, false);
        heatCard.addView(note);
        heat = button("Подогрев выключен", false);
        heat.setOnClickListener(v -> post("/api/cabin", "heat=" + (heat.isSelected() ? "0" : "1")));
        heatCard.addView(heat);
        LinearLayout mode = seg();
        String[] mn = {"Ручное", "Авто"};
        for (int i = 0; i < 2; i++) {
            final int m = i;
            heatMode[i] = button(mn[i], false);
            heatMode[i].setOnClickListener(v -> post("/api/cabin", "mode=" + m));
            mode.addView(heatMode[i], weight());
        }
        heatCard.addView(mode);
        heatCard.addView(hint("Таймер подогрева: выключится сам"));
        LinearLayout timer = row();
        for (int i = 0; i < AUTO_OFF.length; i++) {
            final int mins = AUTO_OFF[i];
            autoBtn[i] = button(mins == 0 ? "Нет" : (mins + " мин"), false);
            autoBtn[i].setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            autoBtn[i].setPadding(dp(2), dp(10), dp(2), dp(10));
            autoBtn[i].setOnClickListener(v -> post("/api/cabin", "auto_off=" + mins));
            timer.addView(autoBtn[i], weight());
        }
        heatCard.addView(timer);
        duty = label("скважность 0%", 14, MUTED, false);
        duty.setPadding(0, dp(10), 0, 0);
        heatCard.addView(duty);
        FrameLayout bar = new FrameLayout(this);
        bar.setBackgroundColor(CARD_HI);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(8));
        bl.topMargin = dp(6);
        bl.bottomMargin = dp(8);
        bar.setLayoutParams(bl);
        dutyFill = new View(this);
        dutyFill.setBackgroundColor(COPPER);
        bar.addView(dutyFill, new FrameLayout.LayoutParams(0, FrameLayout.LayoutParams.MATCH_PARENT));
        heatCard.addView(bar);
        pwmVal = label("0%", 16, COPPER, true);
        heatCard.addView(named("ШИМ, вручную", pwmVal));
        manualDuty = bar(0, 100, 0);
        manualDuty.setOnSeekBarChangeListener(slider("manual", 0, pwmVal, "%"));
        heatCard.addView(manualDuty);
        ambVal = label("10 °C", 16, COPPER, true);
        heatCard.addView(named("Улица, включить ниже", ambVal));
        ambOn = bar(0, 110, 50);
        ambOn.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (ambVal != null) ambVal.setText((p - 40) + " °C");
            }
            @Override public void onStartTrackingTouch(SeekBar s) { touching = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                touching = false;
                holdUntil = SystemClock.uptimeMillis() + 2500;
                post("/api/cabin", "amb_on=" + (s.getProgress() - 40));
            }
        });
        heatCard.addView(ambOn);
        comfVal = label("32 °C", 16, COPPER, true);
        heatCard.addView(named("Комфорт", comfVal));
        comfort = bar(0, 120, 32);
        comfort.setOnSeekBarChangeListener(slider("comfort", 0, comfVal, " °C"));
        heatCard.addView(comfort);
        ceilVal = label("42 °C", 16, COPPER, true);
        heatCard.addView(named("Потолок коврика", ceilVal));
        ceiling = bar(20, 140, 42);
        ceiling.setOnSeekBarChangeListener(slider("seat_max", 20, ceilVal, " °C"));
        heatCard.addView(ceiling);
        box.addView(heatCard);

        LinearLayout lightCard = card();
        lightCard.addView(label("Фара", 18, FG, true));
        LinearLayout seg = seg();
        String[] ln = {"Выкл", "Вкл", "Авто"};
        for (int i = 0; i < 3; i++) {
            final int modeL = i;
            light[i] = button(ln[i], false);
            light[i].setOnClickListener(v -> post("/api/cabin", "light=" + modeL));
            seg.addView(light[i], weight());
        }
        lightCard.addView(seg);
        eveVal = label("30 лк", 16, COPPER, true);
        lightCard.addView(named("Вечер, включить ниже", eveVal));
        SeekBar eve = bar(0, 200, 30);
        dayVal = label("80 лк", 16, COPPER, true);
        eve.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                eveVal.setText(p + " лк");
            }
            @Override public void onStartTrackingTouch(SeekBar s) { touching = true; }
            @Override public void onStopTrackingTouch(SeekBar s) { touching = false;
                holdUntil = SystemClock.uptimeMillis() + 2500; postLux(); }
        });
        lightCard.addView(eve);
        lightCard.addView(named("День, выключить выше", dayVal));
        SeekBar day = bar(20, 400, 80);
        day.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                dayVal.setText(p + " лк");
            }
            @Override public void onStartTrackingTouch(SeekBar s) { touching = true; }
            @Override public void onStopTrackingTouch(SeekBar s) { touching = false;
                holdUntil = SystemClock.uptimeMillis() + 2500; postLux(); }
        });
        lightCard.addView(day);
        this.eve = eve;
        this.day = day;
        box.addView(lightCard);

        LinearLayout relCard = card();
        relCard.addView(label("Реле", 18, FG, true));
        relay[0] = button("Лента", false);
        relay[0].setOnClickListener(v -> post("/api/cabin", "r2=" + (v.isSelected() ? "0" : "1")));
        relCard.addView(relay[0]);
        box.addView(relCard);

        LinearLayout zCard = card();
        zvs = label("—", 40, COPPER, true);
        zCard.addView(zvs);
        in6 = button("240 В", false);
        in6.setOnClickListener(v -> post("/api/cabin", "in6=" + (v.isSelected() ? "0" : "1")));
        zCard.addView(in6);
        in7 = button("Батарея", false);
        in7.setOnClickListener(v -> post("/api/cabin", "in7=" + (v.isSelected() ? "0" : "1")));
        zCard.addView(in7);
        par = label("Дырка 38 разомкнута", 16, FG, false);
        zCard.addView(par);
        box.addView(zCard);
        return box;
    }

    private LinearLayout pageMotor() {
        LinearLayout box = col();
        LinearLayout speeds = card();
        LinearLayout top = row();
        speedCube = big(top, "Куб");
        speedGps = big(top, "GPS");
        speeds.addView(top);
        FrameLayout track = new FrameLayout(this);
        track.setBackgroundColor(CARD_HI);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(10));
        tl.topMargin = dp(10);
        track.setLayoutParams(tl);
        speedFill = new View(this);
        speedFill.setBackgroundColor(COPPER);
        track.addView(speedFill, new FrameLayout.LayoutParams(0, FrameLayout.LayoutParams.MATCH_PARENT));
        speeds.addView(track);
        motorMeta = label("обороты —", 14, MUTED, false);
        speeds.addView(motorMeta);
        speeds.addView(label("GPS с телефона уходит на экран куба, вкладка Скорость.", 13, MUTED, false));
        motorNow = motorMeta;
        box.addView(speeds);
        LinearLayout form = card();
        form.addView(label("Колесо", 16, FG, true));
        form.addView(label("Окружность, мм", 13, MUTED, false));
        circ = field("");
        form.addView(circ);
        form.addView(label("Диаметр, мм", 13, MUTED, false));
        diam = field("");
        form.addView(diam);
        Button fromDiam = button("Окружность из диаметра", false);
        fromDiam.setOnClickListener(v -> {
            try {
                double mm = Double.parseDouble(diam.getText().toString().replace(',', '.'));
                circ.setText(String.valueOf((int) Math.round(mm * Math.PI)));
            } catch (Exception e) {
                status.setText("Диаметр не число");
            }
        });
        form.addView(fromDiam);
        form.addView(label("Передача", 13, MUTED, false));
        gear = field("");
        gear.setText("1.000");
        form.addView(gear);
        form.addView(label("Пары полюсов", 13, MUTED, false));
        poles = field("");
        poles.setText("20");
        form.addView(poles);
        form.addView(label("Подгон, %", 13, MUTED, false));
        trim = field("");
        trim.setText("100");
        form.addView(trim);
        Button save = button("Записать в куб", true);
        save.setOnClickListener(v -> saveMotor(false));
        form.addView(save);
        Button fit = button("Подогнать под GPS", false);
        fit.setOnClickListener(v -> saveMotor(true));
        form.addView(fit);
        box.addView(form);

        LinearLayout lock = card();
        lock.addView(label("Фара и АКБ по радио", 16, FG, true));
        bleNow = label("Роль ещё не прочитана", 13, MUTED, false);
        lock.addView(bleNow);
        lock.addView(label("Одно радио. Фара: куб светится как CONTROLDM, байты идут на UART. АКБ: Xiaoxiang.", 13, MUTED, false));
        Button bridge = button("Телефон на фару через куб", true);
        bridge.setOnClickListener(v -> {
            if (bleRole == 0) {
                status.setText("Уже мост. В Worthless Controls ищи CONTROLDM.");
                return;
            }
            status.setText("Радио станет CONTROLDM. Куб перезагрузится.");
            post("/api/ble", "role=0");
        });
        lock.addView(bridge);
        Button phoneBms = button("Телефон на АКБ", false);
        phoneBms.setOnClickListener(v -> {
            status.setText("Радио станет Xiaoxiang BMS. Куб перезагрузится.");
            post("/api/ble", "role=1");
        });
        lock.addView(phoneBms);
        Button at = button("Прошить BLE-модуль", false);
        at.setOnClickListener(v -> {
            status.setText("Шью HM-10 на TX48/RX39. Контроллер с этих пинов снять.");
            net.execute(() -> {
                String r = http("POST", "/api/fardriver", "at=1");
                ui.post(() -> {
                    if (r == null) status.setText("Куб не ответил на прошивку модуля");
                    else status.setText("Модуль: " + r + ". HC-05 не виден в Worthless. Ищи CONTROLDM.");
                });
            });
        });
        lock.addView(at);
        lock.addView(label("HC-05 это не BLE. Кнопка для HM-10/JDY. Куб и так виден как CONTROLDM.", 13, MUTED, false));
        box.addView(lock);
        return box;
    }


    private void applySkin(int skin) {
        if (skin == 2) {
            BG = 0xFFF4EFE4; CARD = 0xFFFFFDF8; CARD_HI = 0xFFEFE8DA; LINE = 0xFFD9CBB3;
            FG = 0xFF1C1914; MUTED = 0xFF5C564C; COPPER = 0xFFC4840D; INK = 0xFF1A1408;
        } else if (skin == 1) {
            BG = 0xFF2A3140; CARD = 0xFF3A4458; CARD_HI = 0xFF323B4D; LINE = 0xFF5C6B82;
            FG = 0xFFF2F5F8; MUTED = 0xFFC5CEDA; COPPER = 0xFFF0C14B; INK = 0xFF1A1408;
        } else {
            BG = 0xFF090C12; CARD = 0xFF131925; CARD_HI = 0xFF1B2332; LINE = 0xFF283142;
            FG = 0xFFF1F4FA; MUTED = 0xFF8E99AE; COPPER = 0xFFFFB02E; INK = 0xFF1A1205;
        }
    }

    private void showBat(String now, String peak, String hi, String lo, String rem, String after) {
        lineNow = now; linePeak = peak; lineHi = hi; lineLo = lo; lineRem = rem; lineAfter = after;
        if (batNow != null) batNow.setText(now);
        if (batPeak != null) batPeak.setText(peak);
        if (batHi != null) batHi.setText(hi);
        if (batLo != null) batLo.setText(lo);
        if (batRem != null) batRem.setText(rem);
        if (batAfter != null) batAfter.setText(after);
        paintMineLive();
    }

    private String mineRaw() {
        String s = getSharedPreferences("cabin85", MODE_PRIVATE).getString("tabs", "");
        if (s == null || s.length() == 0) return "АКБ|now,peak,max,min,rem,after;Путь|flags";
        return s;
    }

    private String[] mineTabs() {
        String raw = mineRaw();
        if (raw.length() == 0) return new String[0];
        return raw.split(";", -1);
    }

    private void mineWrite(String raw, boolean draw) {
        getSharedPreferences("cabin85", MODE_PRIVATE).edit().putString("tabs", raw).apply();
        if (draw) renderMine();
    }

    private String joinTabs(String[] tabs) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < tabs.length; i++) {
            if (i > 0) b.append(';');
            b.append(tabs[i] == null ? "" : tabs[i]);
        }
        return b.toString();
    }

    private int mineAt() {
        int n = getSharedPreferences("cabin85", MODE_PRIVATE).getInt("mine", 0);
        int len = mineTabs().length;
        if (len == 0) return 0;
        if (n < 0) n = 0;
        if (n >= len) n = len - 1;
        return n;
    }

    private LinearLayout pageMine() {
        LinearLayout box = col();
        LinearLayout skins = seg();
        int skin = getSharedPreferences("cabin85", MODE_PRIVATE).getInt("skin", 0);
        String[] sn = {"Ночь", "Нейтральная", "Светлая"};
        for (int i = 0; i < 3; i++) {
            final int n = i;
            Button b = button(sn[i], skin == i);
            b.setOnClickListener(v -> {
                getSharedPreferences("cabin85", MODE_PRIVATE).edit().putInt("skin", n).putInt("tab", 5).apply();
                recreate();
            });
            skins.addView(b, weight());
        }
        box.addView(skins);
        box.addView(label("Новая вкладка, блоки и порядок. Жёлтым на экране куба горит то, что включено.", 13, MUTED, false));
        Button add = button("Добавить вкладку", true);
        add.setOnClickListener(v -> {
            String raw = mineRaw();
            if (raw.length() > 0 && !raw.endsWith(";")) raw += ";";
            raw += "Новая|";
            mineWrite(raw, false);
            getSharedPreferences("cabin85", MODE_PRIVATE).edit().putInt("mine", mineTabs().length - 1).apply();
            renderMine();
        });
        box.addView(add);
        ownHost = col();
        box.addView(ownHost);
        renderMine();
        return box;
    }

    private void renderMine() {
        if (ownHost == null) return;
        ownHost.removeAllViews();
        mineLive.clear();
        String[] tabs = mineTabs();
        if (tabs.length == 0) return;
        int open = mineAt();
        HorizontalScrollView sc = new HorizontalScrollView(this);
        LinearLayout row = flat();
        for (int i = 0; i < tabs.length; i++) {
            final int n = i;
            String title = tabs[i];
            int bar = title.indexOf('|');
            if (bar >= 0) title = title.substring(0, bar);
            if (title.length() == 0) title = "вкладка";
            Button b = button(title, i == open);
            b.setOnClickListener(v -> {
                getSharedPreferences("cabin85", MODE_PRIVATE).edit().putInt("mine", n).apply();
                renderMine();
            });
            row.addView(b);
        }
        sc.addView(row);
        ownHost.addView(sc);
        String cur = tabs[open];
        int bar = cur.indexOf('|');
        String title = bar >= 0 ? cur.substring(0, bar) : cur;
        String widgets = bar >= 0 ? cur.substring(bar + 1) : "";
        EditText name = field("название");
        name.setText(title);
        name.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(android.text.Editable s) {
                String[] now = mineTabs();
                int at = mineAt();
                if (at < 0 || at >= now.length) return;
                String w = "";
                int p = now[at].indexOf('|');
                if (p >= 0) w = now[at].substring(p + 1);
                String t = s.toString().replace(";", "").replace("|", "");
                if (t.length() > 16) t = t.substring(0, 16);
                now[at] = t + "|" + w;
                mineWrite(joinTabs(now), false);
            }
        });
        ownHost.addView(name);
        LinearLayout adds = flat();
        adds.setOrientation(LinearLayout.VERTICAL);
        String[] ids = {"now", "peak", "max", "min", "rem", "after", "flags"};
        String[] labels = {"Сейчас", "Пик А", "Макс В", "Мин В", "Осталось", "После зарядки", "Что включено"};
        for (int i = 0; i < ids.length; i++) {
            final String id = ids[i];
            Button b = button("+ " + labels[i], false);
            b.setOnClickListener(v -> addWidget(id));
            adds.addView(b);
        }
        ownHost.addView(adds);
        String[] ws = widgets.length() == 0 ? new String[0] : widgets.split(",", -1);
        for (int i = 0; i < ws.length; i++) {
            if (ws[i].length() == 0) continue;
            final int idx = i;
            final String id = ws[i];
            LinearLayout line = flat();
            line.setGravity(Gravity.CENTER_VERTICAL);
            TextView live = label("—", 16, FG, true);
            live.setTag(id);
            live.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            mineLive.add(live);
            line.addView(live);
            Button up = button("вверх", false);
            Button dn = button("вниз", false);
            Button rm = button("убрать", false);
            up.setOnClickListener(v -> moveWidget(idx, -1));
            dn.setOnClickListener(v -> moveWidget(idx, 1));
            rm.setOnClickListener(v -> dropWidget(idx));
            line.addView(up);
            line.addView(dn);
            line.addView(rm);
            ownHost.addView(line);
        }
        LinearLayout order = flat();
        Button upTab = button("вкладку выше", false);
        Button dnTab = button("вкладку ниже", false);
        upTab.setOnClickListener(v -> moveMineTab(-1));
        dnTab.setOnClickListener(v -> moveMineTab(1));
        order.addView(upTab, weight());
        order.addView(dnTab, weight());
        ownHost.addView(order);
        if (tabs.length > 1) {
            Button del = button("Удалить вкладку", false);
            del.setOnClickListener(v -> {
                String[] now = mineTabs();
                int at = mineAt();
                StringBuilder b = new StringBuilder();
                for (int i = 0; i < now.length; i++) {
                    if (i == at) continue;
                    if (b.length() > 0) b.append(';');
                    b.append(now[i]);
                }
                getSharedPreferences("cabin85", MODE_PRIVATE).edit().putInt("mine", Math.max(0, at - 1)).apply();
                mineWrite(b.toString(), true);
            });
            ownHost.addView(del);
        }
        paintMineLive();
    }

    private void addWidget(String id) {
        String[] tabs = mineTabs();
        int at = mineAt();
        if (at < 0 || at >= tabs.length) return;
        String cur = tabs[at];
        int bar = cur.indexOf('|');
        String title = bar >= 0 ? cur.substring(0, bar) : cur;
        String widgets = bar >= 0 ? cur.substring(bar + 1) : "";
        if (("," + widgets + ",").contains("," + id + ",")) return;
        if (widgets.length() > 0 && !widgets.endsWith(",")) widgets += ",";
        widgets += id;
        tabs[at] = title + "|" + widgets;
        mineWrite(joinTabs(tabs), true);
    }

    private void moveWidget(int index, int dir) {
        String[] tabs = mineTabs();
        int at = mineAt();
        if (at < 0 || at >= tabs.length) return;
        String cur = tabs[at];
        int bar = cur.indexOf('|');
        String title = bar >= 0 ? cur.substring(0, bar) : cur;
        String widgets = bar >= 0 ? cur.substring(bar + 1) : "";
        String[] ws = widgets.length() == 0 ? new String[0] : widgets.split(",", -1);
        int next = index + dir;
        if (index < 0 || index >= ws.length || next < 0 || next >= ws.length) return;
        String tmp = ws[index];
        ws[index] = ws[next];
        ws[next] = tmp;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < ws.length; i++) {
            if (ws[i].length() == 0) continue;
            if (b.length() > 0) b.append(',');
            b.append(ws[i]);
        }
        tabs[at] = title + "|" + b;
        mineWrite(joinTabs(tabs), true);
    }

    private void dropWidget(int index) {
        String[] tabs = mineTabs();
        int at = mineAt();
        if (at < 0 || at >= tabs.length) return;
        String cur = tabs[at];
        int bar = cur.indexOf('|');
        String title = bar >= 0 ? cur.substring(0, bar) : cur;
        String widgets = bar >= 0 ? cur.substring(bar + 1) : "";
        String[] ws = widgets.length() == 0 ? new String[0] : widgets.split(",", -1);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < ws.length; i++) {
            if (i == index || ws[i].length() == 0) continue;
            if (b.length() > 0) b.append(',');
            b.append(ws[i]);
        }
        tabs[at] = title + "|" + b;
        mineWrite(joinTabs(tabs), true);
    }

    private void moveMineTab(int dir) {
        String[] tabs = mineTabs();
        int at = mineAt();
        int next = at + dir;
        if (at < 0 || next < 0 || next >= tabs.length) return;
        String tmp = tabs[at];
        tabs[at] = tabs[next];
        tabs[next] = tmp;
        getSharedPreferences("cabin85", MODE_PRIVATE).edit().putInt("mine", next).apply();
        mineWrite(joinTabs(tabs), true);
    }

    private boolean lampNow() {
        return seenLight == 1 || (seenLight == 2 && seenLux >= 0 && seenLux < 40);
    }

    private void paintMineLive() {
        String flags = "фара " + (lampNow() ? "вкл" : "выкл")
                + "\nлента " + (((seenRel & 4) != 0) ? "вкл" : "выкл")
                + "\nимит " + (seenA == 1 ? "вкл" : "выкл")
                + "\nакб " + (seenB == 1 ? "вкл" : "выкл")
                + "\nпар " + (seenB == 1 ? "вкл" : "выкл");
        for (TextView t : mineLive) {
            if (t == null || t.getTag() == null) continue;
            String id = String.valueOf(t.getTag());
            if ("now".equals(id)) t.setText(lineNow);
            else if ("peak".equals(id)) t.setText(linePeak + " А");
            else if ("max".equals(id)) t.setText(lineHi + " В");
            else if ("min".equals(id)) t.setText(lineLo + " В");
            else if ("rem".equals(id)) t.setText(lineRem + " А·ч");
            else if ("after".equals(id)) t.setText(lineAfter);
            else if ("flags".equals(id)) t.setText(flags);
            t.setTextColor("flags".equals(id) ? FG : COPPER);
        }
    }

    private LinearLayout pageBms() {
        LinearLayout box = col();
        bmsHead = label("АКБ ещё не прочитаны", 22, FG, true);
        box.addView(cardOf(bmsHead));
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.VERTICAL);
        batNow = metric(stats, "Сейчас, В и А");
        batPeak = metric(stats, "Пик тока за сессию, А");
        batHi = metric(stats, "Максимум, В");
        batLo = metric(stats, "Минимум, В");
        batRem = metric(stats, "Осталось, А·ч");
        batAfter = metric(stats, "После зарядки, А·ч");
        box.addView(stats);
        LinearLayout cap = card();
        capLine = label("Ёмкость с BMS появится после связи", 15, FG, false);
        cap.addView(capLine);
        LinearLayout srcRow = seg();
        capBms = button("С BMS", true);
        capMan = button("Вручную", false);
        capBms.setOnClickListener(v -> {
            capSrcWant = 0;
            mark(capBms, true);
            mark(capMan, false);
            post("/api/bms", "src=0");
        });
        capMan.setOnClickListener(v -> {
            capSrcWant = 1;
            mark(capBms, false);
            mark(capMan, true);
        });
        srcRow.addView(capBms, weight());
        srcRow.addView(capMan, weight());
        cap.addView(srcRow);
        capAh = field("полная, А·ч");
        capWh = field("полная, Вт·ч");
        capSoc = field("SOC, %");
        cap.addView(capAh);
        cap.addView(capWh);
        cap.addView(capSoc);
        Button saveCap = button("Запомнить", true);
        saveCap.setOnClickListener(v -> {
            StringBuilder q = new StringBuilder("src=").append(capSrcWant);
            String ah = capAh.getText().toString().trim();
            String wh = capWh.getText().toString().trim();
            String soc = capSoc.getText().toString().trim();
            if (ah.length() > 0) q.append("&ah=").append(Uri.encode(ah));
            if (wh.length() > 0) q.append("&wh=").append(Uri.encode(wh));
            if (capSrcWant == 1 && soc.length() > 0) q.append("&soc=").append(Uri.encode(soc));
            post("/api/bms", q.toString());
            status.setText("Ёмкость записана");
        });
        cap.addView(saveCap);
        box.addView(cap);
        cellsBox = new LinearLayout(this);
        cellsBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout cellCard = card();
        cellCard.addView(label("Ячейки", 16, FG, true));
        cellCard.addView(cellsBox);
        box.addView(cellCard);
        LinearLayout role = card();
        Button reread = button("Прочитать регистры ещё раз", false);
        reread.setOnClickListener(v -> post("/api/bms", "read=1"));
        role.addView(reread);
        box.addView(role);
        LinearLayout form = card();
        for (int i = 0; i < REG.length; i++) {
            final int idx = i;
            LinearLayout block = new LinearLayout(this);
            block.setOrientation(LinearLayout.VERTICAL);
            block.setPadding(0, dp(10), 0, dp(4));
            block.addView(label(REG_NAME[i], 15, FG, false));
            LinearLayout controls = flat();
            controls.setGravity(Gravity.CENTER_VERTICAL);
            regNow[i] = label("—", 13, MUTED, false);
            controls.addView(regNow[i]);
            regIn[i] = field("");
            LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            ep.leftMargin = dp(8);
            regIn[i].setLayoutParams(ep);
            controls.addView(regIn[i]);
            Button w = button("Ок", false);
            w.setMinimumWidth(0);
            w.setMinWidth(0);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(64), LinearLayout.LayoutParams.WRAP_CONTENT);
            bp.leftMargin = dp(6);
            bp.topMargin = 0;
            w.setLayoutParams(bp);
            w.setOnClickListener(v -> writeReg(idx));
            controls.addView(w);
            block.addView(controls);
            form.addView(block);
        }
        box.addView(form);
        return box;
    }

    private LinearLayout pageCube() {
        LinearLayout box = col();
        cubeInfo = label("Сессия, станция и экран появятся после связи.", 15, FG, false);
        box.addView(cardOf(cubeInfo));
        LinearLayout req = card();
        req.addView(label("Запрос 240 В", 16, FG, true));
        reqA = field("амперы");
        reqVin = field("VIN");
        req.addView(reqA);
        req.addView(reqVin);
        Button go = button("Записать в куб", true);
        go.setOnClickListener(v -> {
            String amp = reqA.getText().toString().trim();
            if (amp.length() == 0) amp = "50";
            StringBuilder q = new StringBuilder("i=").append(Uri.encode(amp));
            String vin = reqVin.getText().toString().trim();
            if (vin.length() > 0) q.append("&vin=").append(Uri.encode(vin));
            post("/api/setpoints", q.toString());
            status.setText("Ток записан. Напряжение 240 В.");
        });
        req.addView(go);
        box.addView(req);
        LinearLayout scr = card();
        scr.addView(label("Яркость экрана", 16, FG, true));
        bright = bar(5, 100, 80);
        bright.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { }
            @Override public void onStartTrackingTouch(SeekBar s) { touching = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                touching = false;
                holdUntil = SystemClock.uptimeMillis() + 2500;
                post("/api/panel", "br=" + s.getProgress());
            }
        });
        scr.addView(bright);
        turnBtn = button("Экран +90", true);
        turnBtn.setOnClickListener(v -> {
            status.setText("Поворачиваю экран на 90°");
            post("/api/panel", "turn=1");
        });
        scr.addView(turnBtn);
        scr.addView(label("Смена вкладок", 16, FG, true));
        LinearLayout leaf = seg();
        cycleAuto = button("По кругу", true);
        cycleHand = button("Вручную", false);
        cycleAuto.setOnClickListener(v -> post("/api/panel", "cycle=1"));
        cycleHand.setOnClickListener(v -> post("/api/panel", "cycle=0"));
        leaf.addView(cycleAuto, weight());
        leaf.addView(cycleHand, weight());
        scr.addView(leaf);
        dwellVal = label("5 с", 16, COPPER, true);
        scr.addView(dwellVal);
        dwellBar = bar(2, 30, 5);
        dwellBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (dwellVal != null) dwellVal.setText(p + " с");
            }
            @Override public void onStartTrackingTouch(SeekBar s) { touching = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                touching = false;
                holdUntil = SystemClock.uptimeMillis() + 2500;
                post("/api/panel", "dwell=" + s.getProgress());
            }
        });
        scr.addView(dwellBar);
        String[] screens = {"Кабина", "Станция", "Скорость", "Путь", "АКБ"};
        for (int i = 0; i < screens.length; i++) {
            final int n = i;
            pagePick[i] = button(screens[i], false);
            pagePick[i].setOnClickListener(v -> post("/api/panel", "page=" + n));
            scr.addView(pagePick[i]);
        }
        box.addView(scr);
        LinearLayout proto = card();
        proto.addView(label("Протокол станции", 16, FG, true));
        String[] pn = {"Авто", "15/A", "2011", "23B"};
        for (int i = 0; i < pn.length; i++) {
            final int p = i;
            Button b = button(pn[i], false);
            b.setOnClickListener(v -> post("/api/panel", "proto=" + p));
            proto.addView(b);
        }
        box.addView(proto);
        LinearLayout acts = card();
        Button start = button("Старт сессии", false);
        start.setOnClickListener(v -> post("/api/start", ""));
        acts.addView(start);
        Button stop = button("Стоп сессии", false);
        stop.setOnClickListener(v -> post("/api/stop", ""));
        acts.addView(stop);
        addAction(acts, "Wi-Fi точки заново", "/api/panel", "wifi=1");
        addAction(acts, "BLE заново", "/api/panel", "ble=1");
        addAction(acts, "Перезагрузить куб", "/api/reboot", "");
        Button fw = button("Прошивка из файла", true);
        fw.setOnClickListener(v -> pickFirmware());
        acts.addView(fw);
        box.addView(acts);

        LinearLayout wire = card();
        wire.addView(label("Провод CAN", 16, FG, true));
        Button wireBtn = button("Проверка до модуля", false);
        wireBtn.setOnClickListener(v -> post("/api/panel", "wire=1"));
        wire.addView(wireBtn);
        Button busBtn = button("Проверка кабеля CAN", false);
        busBtn.setOnClickListener(v -> post("/api/panel", "bus=1"));
        wire.addView(busBtn);
        Button relayTest = button("Щёлкнуть реле станции", false);
        relayTest.setOnClickListener(v -> postJson("/api/settings", "{\"relay_test\":true}"));
        wire.addView(relayTest);
        box.addView(wire);

        LinearLayout home = card();
        home.addView(label("Домашняя сеть", 16, FG, true));
        Button scanWifi = button("Найти сети", true);
        scanWifi.setOnClickListener(v -> scanHome());
        home.addView(scanWifi);
        wifiNets = col();
        home.addView(wifiNets);
        home.addView(label("Пароль выбранной сети", 13, MUTED, false));
        homePass = field("");
        home.addView(homePass);
        box.addView(home);

        LinearLayout ap = card();
        ap.addView(label("Точка куба", 16, FG, true));
        ap.addView(label("Имя", 13, MUTED, false));
        apName = field("");
        apName.setText("Cube");
        ap.addView(apName);
        ap.addView(label("Пароль, от 8 знаков", 13, MUTED, false));
        apPass = field("");
        apPass.setText("12345678");
        ap.addView(apPass);
        Button saveAp = button("Сохранить точку", true);
        saveAp.setOnClickListener(v -> post("/api/panel",
                "ssid=" + Uri.encode(apName.getText().toString()) + "&pass=" + Uri.encode(apPass.getText().toString())));
        ap.addView(saveAp);
        box.addView(ap);

        LinearLayout logs = card();
        logs.addView(label("Журнал", 16, FG, true));
        Button espLog = button("Журнал куба", false);
        espLog.setOnClickListener(v -> loadText("/api/log"));
        logs.addView(espLog);
        Button espSave = button("Скачать журнал", true);
        espSave.setOnClickListener(v -> download("/api/trace", "cube-log.txt", "text/plain"));
        logs.addView(espSave);
        Button canLog = button("Журнал CAN", false);
        canLog.setOnClickListener(v -> loadText("/api/can"));
        logs.addView(canLog);
        Button canSave = button("Скачать CAN", true);
        canSave.setOnClickListener(v -> download("/api/can", "cube-can.txt", "text/plain"));
        logs.addView(canSave);
        Button sessions = button("Список сессий", false);
        sessions.setOnClickListener(v -> loadText("/api/logs"));
        logs.addView(sessions);
        Button zip = button("Скачать сессии", true);
        zip.setOnClickListener(v -> download("/api/logs.zip", "cube-logs.zip", "application/zip"));
        logs.addView(zip);
        logBox = label("Журнал появится здесь.", 12, MUTED, false);
        logBox.setTextIsSelectable(true);
        logs.addView(logBox);
        box.addView(logs);
        return box;
    }

    private void addAction(LinearLayout host, String title, String path, String body) {
        Button b = button(title, false);
        b.setOnClickListener(v -> post(path, body));
        host.addView(b);
    }

    private FrameLayout pageSite() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        try {
            web = new WebView(this);
            web.setBackgroundColor(BG);
            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    return rewrite(view, url);
                }
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return rewrite(view, request.getUrl().toString());
                }
            });
            frame.addView(web, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        } catch (Throwable t) {
            frame.addView(label("Встроенный сайт на этом телефоне не открылся. Вкладки выше работают.", 16, FG, false));
        }
        return frame;
    }

    private boolean rewrite(WebView view, String url) {
        if (url != null && url.startsWith(BASE)) {
            view.loadUrl("http://127.0.0.1:" + proxyPort + url.substring(BASE.length()));
            return true;
        }
        return false;
    }

    private LinearLayout pageScheme() {
        LinearLayout box = col();
        String[][] rows = {
                {"Три питания", "Пачка ~60 В: коврик, лампа, плюс на IN7. 12 В: лента, вход повышайки, затвор. Катушки реле — по надписи на синем кубике. 5 В: пин 5V и TJA1050. Логика только с 3,3 В. Земля одна."},
                {"8 реле", "Джампер JD-VCC снять. VCC логики на 3,3 В. JD-VCC: на корпусе 12V — от 12 В, 5V — от 5 В. Замыкаются COM и NO, когда IN на земле. NC не нужен. IN8 пустой."},
                {"IN1 лампа", "GPIO42. COM плюс пачки, NO плюс лампы, минус лампы на минус пачки. Это не Fardriver."},
                {"Реле", "IN1 фара, дырка 42. IN3 лента, дырка 40. Дырка 41 припаяна к экрану и на реле не идёт. Дырка 38 замыкается вместе с батареей на дырке 7."},
                {"IN3 лента", "Дырка 40. Кнопка «Лента»."},
                {"Дырка 41", "Провод T_IRQ так и остаётся. Тач прошивка не читает, экран только показывает. Перепаивать не нужно."},
                {"Дырка 38", "Второе силовое рядом с батареей. Включается и выключается вместе с дыркой 7. Отдельной кнопки нет."},
                {"IN6 подготовка", "GPIO6. NO на DC+ станции. Замыкается первым, станция видит повышайку."},
                {"IN7 пачка", "GPIO7. COM плюс пачки, NO на тот же DC+. Вместе с IN6 не включено. DC− на минус пачки."},
                {"Резистор", "10 кОм 10 Вт между HV+ и HV−, до IN5. На 100 В около 1 Вт. На 390 В будет 15 Вт, так не оставлять."},
                {"Делитель", "Четыре 470 кОм 1/4 Вт из набора от HV+ до узла, узел на GPIO4, с узла 10 кОм 1/4 Вт на минус повышайки. 12 кОм нет. Стабилитрона 3,3 В нет, 15 В сюда не ставить."},
                {"Расширителя нет", "IN сидят прямо на ногах. MCP23017 не паять."},
                {"BMP280", "Чёрная плата, дырки VIN GND SCL SDA. VIN только 3,3 В, пяти вольт там нет. SCL GPIO47, SDA GPIO15."},
                {"BH1750", "Синяя GY-302, дырки сверху: VCC 3,3 В, GND земля, SCL GPIO47, SDA GPIO15, ADDR на землю."},
                {"DS18B20", "Красный 3,3 В, чёрный земля, жёлтый GPIO8, 4,7 кОм между жёлтым и 3,3 В. T_IRQ экрана сюда не сажать."},
                {"IRFP250", "Надпись на себя, ноги вниз: затвор, сток, исток. Спина это сток. Плюс коврика на плюс пачки, минус коврика на сток, исток на минус пачки."},
                {"PC817", "Точка у ноги 1. Нога 1 через 330 Ом на GPIO5, нога 2 на землю, нога 4 на 12 В, нога 3 через 100 Ом на затвор. 4,7 кОм между затвором и истоком. Стабилитрон 15 В полоской к затвору. 1N5408 полоской к плюсу коврика."},
                {"TJA1050", "Надписи слева направо: CANH и CANL на станцию. Любая GND на землю куба. CTX напрямую на GPIO17. CRX через 10 кОм на GPIO18, от GPIO18 резистор 20 кОм на землю. Дырка 5V на пин 5V. Дырку 3.3 не подключать. Транзисторы не паять."},
                {"АКБ одна", "T1409. TTL: VCC на 3V3 куба, GND на землю, RXD от GPIO1, TXD на GPIO2. RS232: GND на землю UART BMS, TXD на RX BMS, RXD на TX BMS. Ногу 11–15 В разъёма BMS на эту плату не сажать."},
                {"Не трогать", "GPIO 0, 3, 45, 46, 19, 20, 26–37, 43, 44. Экран SPI: 12, 11, 9, 10, 13, 14, 21. T_CS 16 и T_IRQ 41 припаяны, тач не читается. Фарик по TTL: TX куба GPIO48, RX куба GPIO39, только 3,3 В."}
        };
        for (String[] row : rows) {
            LinearLayout c = card();
            c.addView(label(row[0], 16, FG, true));
            c.addView(hint(row[1]));
            box.addView(c);
        }
        return box;
    }

    private LinearLayout pageSession() {
        LinearLayout box = col();
        box.addView(label("Сессия со станцией", 18, FG, true));
        box.addView(hint("Весь журнал с включения куба. Здесь написано, что станция прислала и принял ли куб её кадры."));
        Button refresh = button("Обновить", true);
        refresh.setOnClickListener(v -> loadSession());
        box.addView(refresh);
        sessionView = label("Нажми «Подключить», потом открой эту вкладку ещё раз.", 13, MUTED, false);
        sessionView.setTextIsSelectable(true);
        sessionView.setTypeface(android.graphics.Typeface.MONOSPACE);
        box.addView(sessionView);
        return box;
    }

    private void loadSession() {
        net.execute(() -> {
            String body = http("GET", "/api/trace", null);
            ui.post(() -> {
                if (sessionView == null) return;
                if (body == null) {
                    sessionView.setText("Куб не ответил. Нажми «Подключить» и открой вкладку снова.");
                    return;
                }
                String text = plainSession(body);
                if (text.length() > 80000) {
                    text = "…показан конец журнала…\n" + text.substring(text.length() - 80000);
                }
                if (text.trim().isEmpty()) text = "Журнал пуст. Сессия ещё не началась.";
                int y = 0;
                if (pages[4] instanceof android.widget.ScrollView) y = ((android.widget.ScrollView) pages[4]).getScrollY();
                sessionView.setText(text);
                int keep = y;
                if (pages[4] instanceof android.widget.ScrollView) {
                    ((android.widget.ScrollView) pages[4]).post(() -> ((android.widget.ScrollView) pages[4]).setScrollY(keep));
                }
            });
        });
    }

    private static String plainSession(String raw) {
        String s = raw.replace("\u001b", "");
        s = s.replaceAll("\\[[0-9;]*m", "");
        s = s.replace("арбитраж", "кадр не влез, станция говорила одновременно");
        s = s.replace("нет ACK", "станция не подтвердила кадр");
        s = s.replace("TX BHM ок pri3", "приветствие ушло");
        s = s.replace("TX BHM ок", "приветствие ушло");
        s = s.replace("TX BHM без ответа", "приветствие без ответа");
        s = s.replace("TX BRM 49B GBT-2015", "строка паспорта (старая прошивка писала её даже без подтверждения)");
        s = s.replace("TX BRM 41B GBT-2011", "строка паспорта, старый протокол");
        s = s.replace("TX BCP 13B", "параметры батареи");
        s = s.replace("CST, сессия стоп", "станция остановила сессию");
        s = s.replace("CST from charger, session kept", "станция прислала стоп");
        s = s.replace("CRM AA, go BCP", "станция узнала батарею");
        s = s.replace("RX 1826F456", "RX станция: приветствие");
        s = s.replace("RX 1801F456", "RX станция: узнавание");
        s = s.replace("RX 101AF456", "RX станция: стоп");
        s = s.replace("RX 1808F456", "RX станция: её возможности");
        s = s.replace("RX 100AF456", "RX станция: готова");
        s = s.replace("CHM -> GBT-2015/2023-A", "станция говорит по протоколу 2015");
        s = s.replace("auto start: station on CAN", "куб увидел станцию и начал сессию");
        s = s.replace("unplug: CAN silent, relays off", "станция замолчала, реле выключены");
        s = s.replace("CML ok, BRO AA", "пределы станции есть, куб готов");
        s = s.replace("TX BEM timeout, relays off", "куб сообщил таймаут, реле выключены");
        s = s.replace("CEM charger error, session kept", "станция: ошибка связи");
        s = s.replace("CAN 17→CTX 18←CRX 250k", "шина");
        s = s.replace("bus-off", "шина легла");
        return s;
    }

    private int shown;

    private void show(int n) {
        if (n < 0) n = 0;
        if (n >= pages.length) n = pages.length - 1;
        shown = n;
        getSharedPreferences("cabin85", MODE_PRIVATE).edit().putInt("tab", n).apply();
        for (int i = 0; i < pages.length; i++) {
            pages[i].setVisibility(i == n ? View.VISIBLE : View.GONE);
            boolean on = i == n;
            tabIcon[i].tint(on ? COPPER : MUTED);
            tabText[i].setTextColor(on ? COPPER : MUTED);
            tabText[i].setTypeface(Typeface.create("sans-serif-medium", on ? Typeface.BOLD : Typeface.NORMAL));
        }
        if (n == 4) loadSession();
    }

    private void connect() {
        wantConnect = true;
        if (!permsOk()) {
            requestPerms();
            status.setText("Разреши геолокацию. На Android 13 ещё «устройства рядом». Без этого сеть Cube система не отдаёт.");
            return;
        }
        status.setText("Ищу куб. Мобильный интернет не переключаю.");
        if (hasLocation()) startGps();
        net.execute(() -> {
            String body = http("GET", "/api/status", null);
            if (body != null) ui.post(this::startPoll);
            else ui.post(this::askWifi);
        });
    }

    private boolean permsOk() {
        if (Build.VERSION.SDK_INT < 23) return true;
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            return false;
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED)
            return false;
        return true;
    }

    private void requestPerms() {
        if (Build.VERSION.SDK_INT < 23) return;
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION,
                    android.Manifest.permission.NEARBY_WIFI_DEVICES
            }, 7);
        } else {
            requestPermissions(new String[]{
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
            }, 7);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (hasLocation()) startGps();
        if (wantConnect && permsOk()) connect();
        else if (wantConnect) status.setText("Без разрешения сеть Cube не вызвать. Остальные вкладки можно смотреть.");
    }

    private boolean hasLocation() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressLint("MissingPermission")
    private void startGps() {
        if (locations == null || !hasLocation()) return;
        try {
            Location last = locations.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null) last = locations.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null) gps.onLocationChanged(last);
        } catch (Exception ignored) {}
        try { locations.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0f, gps); } catch (Exception ignored) {}
        try { locations.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0f, gps); } catch (Exception ignored) {}
    }

    private void askWifi() {
        try {
            if (Build.VERSION.SDK_INT >= 29) askModern();
            else askLegacy();
        } catch (Throwable e) {
            status.setText("Wi-Fi не запросился: " + e.getClass().getSimpleName());
        }
    }

    private void askModern() {
        if (callback != null) {
            try { cm.unregisterNetworkCallback(callback); } catch (Exception ignored) {}
            callback = null;
        }
        WifiNetworkSpecifier spec = new WifiNetworkSpecifier.Builder()
                .setSsid("Cube")
                .setWpa2Passphrase("12345678")
                .build();
        NetworkRequest req = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(spec)
                .build();
        callback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                cubeNet = network;
                ui.post(() -> {
                    status.setText("Cube есть. Мобильный интернет остаётся у телефона.");
                    startPoll();
                });
            }
            @Override public void onUnavailable() {
                ui.post(() -> status.setText("Окно Cube закрыли или точка не найдена"));
            }
        };
        cm.requestNetwork(req, callback);
        status.setText("В системном окне нажми подключить Cube");
    }

    @SuppressWarnings("deprecation")
    private void askLegacy() {
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        if (wm != null) {
            if (!wm.isWifiEnabled()) wm.setWifiEnabled(true);
            WifiConfiguration conf = new WifiConfiguration();
            conf.SSID = "\"Cube\"";
            conf.preSharedKey = "\"12345678\"";
            conf.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
            int id = wm.addNetwork(conf);
            if (id >= 0) {
                wm.disconnect();
                wm.enableNetwork(id, true);
                wm.reconnect();
            }
        }
        status.setText("Android до 10: система сама может спросить, оставлять ли мобильный интернет.");
        net.execute(() -> {
            for (int i = 0; i < 24; i++) {
                if (http("GET", "/api/status", null) != null) {
                    ui.post(this::startPoll);
                    return;
                }
                try { Thread.sleep(500); } catch (InterruptedException e) { return; }
            }
            ui.post(() -> status.setText("Куб не ответил"));
        });
    }

    private void startPoll() {
        if (polling) return;
        polling = true;
        tick();
    }

    /* Cabin tab polls twice a second so the seat value is live; the other
     * tabs once a second. Each tick asks only for what the open tab shows. */
    private int pollMs() {
        return shown == 0 ? 500 : 1000;
    }

    private void tick() {
        if (!polling) return;
        final int n = ++tickN;
        final int tab = shown;
        net.execute(() -> {
            boolean wantSt = tab != 0 || n % 2 == 0;
            boolean wantCab = tab == 0 || n % 2 == 0;
            String st = wantSt ? http("GET", "/api/status", null) : null;
            String cab = wantCab ? http("GET", "/api/cabin", null) : null;
            String bms = (tab == 2 || tab == 5 || n % 6 == 0) && n % 2 == 1 ? http("GET", "/api/bms", null) : null;
            ui.post(() -> {
                if (!polling) return;
                boolean asked = wantSt || wantCab;
                boolean got = st != null || cab != null;
                if (asked && !got) {
                    status.setText("Куб молчит");
                    setLink(-1);
                } else if (got) {
                    status.setText("На связи");
                    setLink(1);
                }
                if (cab != null) paintCabin(cab);
                if (st != null) paintStatus(st);
                if (bms != null) paintBms(bms);
                if (st != null) {
                    int g10 = gpsKmh < 0 ? -1 : (int) Math.round(gpsKmh * 10.0);
                    if (g10 > 2500) g10 = 2500;
                    post("/api/panel", "gps10=" + g10);
                }
                if (shown == 4 && (n % 2 == 0)) loadSession();
                ui.postDelayed(this::tick, pollMs());
            });
        });
    }

    private void post(String path, String form) {
        net.execute(() -> http("POST", path, form == null ? "" : form));
    }

    private void postJson(String path, String json) {
        net.execute(() -> httpRaw("POST", path, json, "application/json"));
    }

    private void loadText(String path) {
        status.setText("Читаю…");
        net.execute(() -> {
            String body = http("GET", path, null);
            ui.post(() -> {
                if (body == null) {
                    status.setText("Не открылось");
                    return;
                }
                String show = body.length() > 1800 ? body.substring(body.length() - 1800) : body;
                if (show.trim().length() == 0) show = "пусто";
                if (logBox != null) logBox.setText(show);
                String line = show.replace('\n', ' ').trim();
                if (line.length() > 80) line = line.substring(0, 80);
                status.setText(line);
            });
        });
    }

    private void download(String path, String name, String mime) {
        status.setText("Скачиваю " + name);
        net.execute(() -> {
            byte[] data = httpBytes(path);
            ui.post(() -> {
                if (data == null || data.length == 0) {
                    status.setText("Файл не скачался");
                    return;
                }
                String err = saveDownload(name, mime, data);
                status.setText(err == null ? ("Сохранено: " + name) : err);
            });
        });
    }

    private byte[] httpBytes(String path) {
        HttpURLConnection c = null;
        try {
            URL url = new URL(BASE + path);
            Network n = cubeNetwork();
            c = (HttpURLConnection) (n != null ? n.openConnection(url) : url.openConnection());
            c.setConnectTimeout(4000);
            c.setReadTimeout(20000);
            c.setRequestMethod("GET");
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null || code >= 400) return null;
            return readBytes(in, 700000);
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private String saveDownload(String name, String mime, byte[] data) {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.IS_PENDING, 1);
                android.net.Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return "Система не дала файл";
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os == null) return "Файл не открылся";
                os.write(data);
                os.close();
                v.clear();
                v.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, v, null, null);
                return null;
            } catch (Exception e) {
                return "Не записал: " + e.getClass().getSimpleName();
            }
        }
        return "Нужен Android 10 или новее";
    }

    private void scanHome() {
        status.setText("Ищу домашние сети. Точка Cube на это время может моргнуть.");
        net.execute(() -> {
            String body = http("GET", "/api/wifi/scan", null);
            ui.post(() -> paintNets(body));
        });
    }

    private void paintNets(String body) {
        if (wifiNets == null) return;
        wifiNets.removeAllViews();
        if (body == null) {
            status.setText("Скан не удался");
            return;
        }
        try {
            JSONArray nets = new JSONObject(body).optJSONArray("nets");
            if (nets == null || nets.length() == 0) {
                wifiNets.addView(hint("Сетей нет"));
                return;
            }
            for (int i = 0; i < nets.length(); i++) {
                String ssid = nets.optString(i);
                Button b = button(ssid, false);
                b.setOnClickListener(v -> {
                    String pass = homePass == null ? "" : homePass.getText().toString();
                    status.setText("Подключаю " + ssid);
                    post("/api/wifi/join", "ssid=" + Uri.encode(ssid) + "&pass=" + Uri.encode(pass));
                });
                wifiNets.addView(b);
            }
        } catch (Exception e) {
            status.setText("Список сетей не разобрать");
        }
    }

    private Network cubeNetwork() {
        Network held = cubeNet;
        if (held != null) return held;
        if (cm == null) return null;
        try {
            Network[] all = cm.getAllNetworks();
            for (Network n : all) {
                LinkProperties lp = cm.getLinkProperties(n);
                if (lp == null) continue;
                for (LinkAddress a : lp.getLinkAddresses()) {
                    if (a.getAddress() instanceof Inet4Address) {
                        String host = a.getAddress().getHostAddress();
                        if (host != null && host.startsWith("192.168.4.")) return n;
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private String http(String method, String path, String form) {
        HttpURLConnection c = null;
        try {
            URL url = new URL(BASE + path);
            Network n = cubeNetwork();
            c = (HttpURLConnection) (n != null ? n.openConnection(url) : url.openConnection());
            c.setConnectTimeout(2500);
            c.setReadTimeout(15000);
            c.setRequestMethod(method);
            if (form != null) {
                byte[] b = form.getBytes(StandardCharsets.UTF_8);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                OutputStream os = c.getOutputStream();
                os.write(b);
                os.close();
            }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null || code >= 400) return null;
            return readAll(in, 700000);
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private String httpRaw(String method, String path, String body, String type) {
        HttpURLConnection c = null;
        try {
            URL url = new URL(BASE + path);
            Network n = cubeNetwork();
            c = (HttpURLConnection) (n != null ? n.openConnection(url) : url.openConnection());
            c.setConnectTimeout(4000);
            c.setReadTimeout(8000);
            c.setRequestMethod(method);
            byte[] b = body.getBytes(StandardCharsets.UTF_8);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", type);
            OutputStream os = c.getOutputStream();
            os.write(b);
            os.close();
            int code = c.getResponseCode();
            return code >= 400 ? null : "ok";
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private String readAll(InputStream in, int cap) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        int total = 0;
        while ((n = in.read(buf)) > 0 && total < cap) {
            bos.write(buf, 0, n);
            total += n;
        }
        return bos.toString("UTF-8");
    }

    private void paintCabin(String body) {
        try {
            JSONObject j = new JSONObject(body);
            amb.setText(tempOr(j, "bme", "amb"));
            lux.setText(j.optInt("bh") == 1 ? (j.optInt("lux") + " лк") : "нет");
            seat.setText(tempOr(j, "seat_ok", "seat"));
            int d = j.optInt("duty");
            int left = j.optInt("heat_left", -1);
            int ao = j.optInt("auto_off", 0);
            duty.setText("скважность " + d + "%" + (left >= 0 ? " · выкл через " + left + " мин" : ""));
            for (int i = 0; i < autoBtn.length; i++) mark(autoBtn[i], AUTO_OFF[i] == ao);
            if (dutyFill != null) {
                int w = dutyFill.getParent() instanceof View
                        ? ((View) dutyFill.getParent()).getWidth() : 0;
                android.view.ViewGroup.LayoutParams lp = dutyFill.getLayoutParams();
                int next = w > 0 ? w * d / 100 : 0;
                dutyFill.animate().cancel();
                android.animation.ValueAnimator va = android.animation.ValueAnimator.ofInt(lp.width, next);
                va.setDuration(180);
                va.addUpdateListener(a -> {
                    lp.width = (int) a.getAnimatedValue();
                    dutyFill.setLayoutParams(lp);
                });
                va.start();
            }
            boolean hon = j.optInt("heat") == 1;
            mark(heat, hon);
            heat.setText(hon ? "Подогрев включён" : "Подогрев выключен");
            String fault = j.optString("fault", "");
            if ("seat".equals(fault)) note.setText("Датчика на коврике нет.");
            else if ("hot".equals(fault)) note.setText("Потолок.");
            else if ("zvs".equals(fault)) note.setText("Выход разомкнут, выше предела.");
            else if ("pile".equals(fault)) note.setText("Станция дала ток, выход разомкнут.");
            else if (j.optInt("mode") == 1) note.setText("Авто.");
            else note.setText("Ручное " + j.optInt("manual") + "%.");
            int seatV = j.optInt("seat_ok") == 1 ? j.optInt("seat", -32768) : -32768;
            int rate = j.optInt("seat_rate", 0);
            int sps = j.optInt("seat_sps", 0);
            if (gauge != null) gauge.set(seatV, j.optInt("comfort", 3200), j.optInt("seat_max", 4200), d, rate, fault, hon);
            if (mDuty != null) mDuty.setText(d + "%");
            if (mRate != null) mRate.setText(seatV == -32768 ? "—" : ((rate >= 0 ? "+" : "") + one(rate * 0.6 / 100.0) + "°/мин"));
            if (mHz != null) mHz.setText(sps > 0 ? one(sps / 10.0) + " Гц" : "—");
            int hm = j.optInt("mode");
            for (int i = 0; i < heatMode.length; i++) mark(heatMode[i], i == hm);
            int mode = j.optInt("light");
            seenLight = mode;
            seenLux = j.optInt("lux");
            seenRel = j.optInt("rel");
            for (int i = 0; i < light.length; i++) mark(light[i], i == mode);
            int rel = j.optInt("rel");
            mark(relay[0], (rel & (1 << 2)) != 0);
            zvs.setText(j.optInt("zvs_ok") == 1 ? (j.optInt("zvs_mv") / 1000 + " В") : "нет");
            if (!editing()) {
                comfort.setProgress(clamp(j.optInt("comfort") / 100, 0, 120));
                ceiling.setProgress(clamp(j.optInt("seat_max") / 100, 20, 140));
                manualDuty.setProgress(j.optInt("manual"));
                ambOn.setProgress(clamp(j.optInt("amb_on", 1000) / 100 + 40, 0, 110));
                if (amps != null) amps.setProgress(clamp(j.optInt("amp_lim", 8000) / 1000, 1, 20));
                if (eve != null) eve.setProgress(clamp(j.optInt("lux_on", 30), 0, 200));
                if (day != null) day.setProgress(clamp(j.optInt("lux_off", 80), 20, 400));
                if (pwmVal != null) pwmVal.setText(j.optInt("manual") + "%");
                if (comfVal != null) comfVal.setText((j.optInt("comfort") / 100) + " °C");
                if (ceilVal != null) ceilVal.setText((j.optInt("seat_max") / 100) + " °C");
                if (ambVal != null) ambVal.setText((j.optInt("amb_on", 1000) / 100) + " °C");
                if (ampVal != null) ampVal.setText((j.optInt("amp_lim", 8000) / 1000) + " А");
                if (eveVal != null) eveVal.setText(j.optInt("lux_on", 30) + " лк");
                if (dayVal != null) dayVal.setText(j.optInt("lux_off", 80) + " лк");
            }
            paintMineLive();
        } catch (Exception ignored) {}
    }

    private void paintFd(String body) {
        if (fdList == null) return;
        try {
            JSONObject j = new JSONObject(body);
            JSONArray items = j.optJSONArray("items");
            fdList.removeAllViews();
            if (j.optInt("link") == 1)
                fdList.addView(label(j.optString("name") + " " + j.optString("peer"), 14, COPPER, true));
            if (items == null) return;
            for (int i = 0; i < items.length(); i++) {
                JSONObject it = items.getJSONObject(i);
                String addr = it.optString("addr");
                String name = it.optString("name");
                if (name.length() == 0) name = addr;
                Button b = button(name, false);
                b.setOnClickListener(v -> post("/api/fdlink", "addr=" + addr));
                fdList.addView(b);
            }
        } catch (Exception ignored) {}
    }

    private void paintStatus(String body) {
        try {
            JSONObject j = new JSONObject(body);
            double cube = j.optInt("fd_kmh10") / 10.0;
            cubeKmh = cube;
            int rpm = j.optInt("fd_rpm");
            String link = j.optInt("fd_link") == 1 ? "есть" : "нет";
            if (speedCube != null) speedCube.setText(one(cube));
            paintGps();
            if (speedFill != null && speedFill.getParent() instanceof View) {
                int w = ((View) speedFill.getParent()).getWidth();
                android.view.ViewGroup.LayoutParams lp = speedFill.getLayoutParams();
                int shown = (int) Math.max(0, Math.min(80, cube));
                lp.width = w > 0 ? w * shown / 80 : 0;
                speedFill.setLayoutParams(lp);
            }
            if (motorMeta != null) {
                motorMeta.setText("обороты " + rpm + "   связь " + link
                        + "\nток " + one(j.optInt("fd_amps10") / 10.0) + " А   "
                        + one(j.optInt("fd_volts10") / 10.0) + " В   ошибка " + j.optInt("fd_err"));
            }
            if (!circ.isFocused() && j.has("fd_circ")) circ.setText(String.valueOf(j.optInt("fd_circ")));
            if (!gear.isFocused() && j.has("fd_gear")) gear.setText(String.format(java.util.Locale.US, "%.3f", j.optInt("fd_gear") / 1000.0));
            if (!poles.isFocused() && j.optInt("fd_poles") > 0) poles.setText(String.valueOf(j.optInt("fd_poles")));
            if (!trim.isFocused() && j.has("fd_trim")) trim.setText(String.format(java.util.Locale.US, "%.1f", j.optInt("fd_trim") / 10.0));
            if (!diam.isFocused() && j.optInt("fd_diam") > 0)
                diam.setText(String.valueOf((int) Math.round(j.optInt("fd_diam") / 10.0 * 25.4)));
            if (!editing() && j.has("br")) bright.setProgress(j.optInt("br"));
            cubeInfo.setText("Прошивка " + j.optString("fw") + " " + j.optString("version")
                    + "\nстанция " + j.optString("stage") + "  протокол " + j.optString("protocol")
                    + "\n" + one(j.optDouble("voltage_v")) + " В  " + one(j.optDouble("current_a")) + " А  "
                    + j.optLong("power_w") + " Вт  SOC " + j.optInt("soc") + "%"
                    + "\nАКБ: " + j.optString("bms_a")
                    + "\nVIN " + j.optString("vin") + "  " + one(j.optDouble("cap_kwh")) + " кВт·ч"
                    + "\n240 В " + (j.optInt("relay_a") == 1 ? "замкнут" : "разомкнут")
                    + "   Батарея " + (j.optInt("relay_b") == 1 ? "замкнута" : "разомкнута")
                    + "   дырка 38 " + (j.optInt("relay_b") == 1 ? "тоже" : "тоже разомкнута"));
            if (j.has("ble_role")) bleRole = j.optInt("ble_role");
            if (bleNow != null && j.has("ble_role")) {
                bleNow.setText(j.optInt("ble_role") == 1 ? "Радио: АКБ, Xiaoxiang" : "Радио: мост CONTROLDM");
            }
            if (turnBtn != null && j.has("scr")) turnBtn.setText("Экран " + j.optInt("scr") + "°");
            if (cycleAuto != null && j.has("cycle")) {
                mark(cycleAuto, j.optInt("cycle") == 1);
                mark(cycleHand, j.optInt("cycle") != 1);
            }
            if (!editing() && dwellBar != null && j.has("dwell")) {
                dwellBar.setProgress(clamp(j.optInt("dwell"), 2, 30));
                if (dwellVal != null) dwellVal.setText(j.optInt("dwell") + " с");
            }
            if (pagePick[0] != null && j.has("page")) {
                int pg = j.optInt("page");
                for (int i = 0; i < pagePick.length; i++) mark(pagePick[i], i == pg);
            }
            seenA = j.optInt("relay_a");
            seenB = j.optInt("relay_b");
            if (in6 != null) mark(in6, seenA == 1);
            if (in7 != null) mark(in7, seenB == 1);
            paintMineLive();
            if (par != null) par.setText(j.optInt("relay_b") == 1 ? "Дырка 38 замкнута" : "Дырка 38 разомкнута");
        } catch (Exception ignored) {}
    }

    private void paintGps() {
        if (speedGps != null) speedGps.setText(gpsKmh < 0 ? "—" : one(gpsKmh));
    }

    private void paintBms(String body) {
        try {
            JSONObject root = new JSONObject(body);
            JSONArray packs = root.optJSONArray("packs");
            if (packs == null || bmsPack >= packs.length()) {
                bmsHead.setText("Плата не ответила");
                showBat("нет связи", linePeak, lineHi, lineLo, "—", lineAfter);
                return;
            }
            JSONObject p = packs.getJSONObject(bmsPack);
            if (bleNow != null) {
                int role = root.optInt("ble_role", 0);
                bleRole = role;
                bleNow.setText(role == 1 ? "Радио: АКБ, Xiaoxiang" : "Радио: мост CONTROLDM");
            }
            if (!p.optBoolean("ok")) {
                bmsHead.setText("АКБ: нет связи");
                if (capLine != null) capLine.setText(root.optInt("need_cap") == 1
                        ? "Связи нет. Введи А·ч или Вт·ч и запомни."
                        : "Связи нет");
                if (cellsBox != null) cellsBox.removeAllViews();
                showBat("нет связи", linePeak, lineHi, lineLo, "—", lineAfter);
                return;
            }
            int fullWh = root.optInt("full_wh");
            int remWh = root.optInt("remain_wh");
            int fullMah = p.optInt("full_mah");
            double volts = p.optInt("mv") / 1000.0;
            double amps = p.optInt("ma") / 1000.0;
            if (!sesHave || volts > sesMaxV) sesMaxV = volts;
            if (!sesHave || volts < sesMinV) sesMinV = volts;
            if (Math.abs(amps) > sesPeakA) sesPeakA = Math.abs(amps);
            sesHave = true;
            int remMah = p.has("remain_mah") ? p.optInt("remain_mah") : p.optInt("mah");
            if (remMah <= 0 && fullMah > 0 && p.optInt("soc") > 0) remMah = fullMah * p.optInt("soc") / 100;
            double packPeak = Math.abs(p.optInt("peak_ma") / 1000.0);
            if (packPeak > sesPeakA) sesPeakA = packPeak;
            if (amps < -0.2) sesAfter = remMah / 1000.0;
            bmsHead.setText(one(volts) + " В   " + one(amps) + " А\nSOC " + p.optInt("soc") + "%");
            showBat(one(volts) + " В   " + one(amps) + " А",
                    one(sesPeakA), one(sesMaxV), one(sesMinV),
                    one(remMah / 1000.0),
                    sesAfter > 0 ? one(sesAfter) + " А·ч" : "ещё не было");
            if (capLine != null) {
                String line = "осталось " + remWh + " Вт·ч из " + fullWh
                        + "\n" + (fullMah > 0
                        ? ("полная с BMS " + one(fullMah / 1000.0) + " А·ч")
                        : "полная с BMS не прочитана");
                if (root.optInt("need_cap") == 1) line += "\nВведи А·ч или Вт·ч";
                line += root.optInt("cap_src") == 0 ? "\nсейчас с BMS" : "\nсейчас вручную";
                capLine.setText(line);
            }
            paintCells(p);
            JSONArray regs = p.optJSONArray("regs");
            int div = p.optInt("amp_div");
            for (int i = 0; i < REG.length; i++) {
                JSONObject rec = null;
                if (regs != null) {
                    for (int k = 0; k < regs.length(); k++) {
                        JSONObject r = regs.getJSONObject(k);
                        if (r.optInt("r") == REG[i]) { rec = r; break; }
                    }
                }
                if (rec == null || rec.optInt("ok") != 1) {
                    regNow[i].setText("жду это число с платы");
                    continue;
                }
                int raw = rec.optInt("v");
                int scale = scaleOf(REG_KIND[i], raw, div);
                regNow[i].setText("в плате: " + view(REG_KIND[i], raw, scale));
                if (!regIn[i].isFocused()) {
                    regIn[i].setText(view(REG_KIND[i], raw, scale));
                    regIn[i].setTag(scale);
                }
            }
        } catch (Exception ignored) {}
    }

    private void paintCells(JSONObject p) {
        if (cellsBox == null) return;
        cellsBox.removeAllViews();
        JSONArray cv = p.optJSONArray("cells");
        if (cv == null || cv.length() == 0) return;
        long bal = p.optLong("bal");
        int max = 0;
        int min = 99999;
        for (int i = 0; i < cv.length(); i++) {
            int mv = cv.optInt(i);
            if (mv > max) max = mv;
            if (mv > 0 && mv < min) min = mv;
        }
        LinearLayout row = null;
        for (int i = 0; i < cv.length() && i < 24; i++) {
            if (i % 4 == 0) {
                row = flat();
                cellsBox.addView(row);
            }
            int mv = cv.optInt(i);
            boolean on = (bal & (1L << i)) != 0;
            boolean low = !on && max - min >= 20 && mv <= max - 20;
            TextView t = label((i + 1) + "\n" + String.format(java.util.Locale.US, "%.3f", mv / 1000.0), 12, FG, true);
            t.setGravity(Gravity.CENTER);
            t.setBackground(round(on ? 0xFF1B6A86 : (low ? 0xFF7A2C34 : CARD_HI)));
            t.setPadding(dp(4), dp(6), dp(4), dp(6));
            LinearLayout.LayoutParams lp = weight();
            lp.rightMargin = dp(4);
            lp.topMargin = dp(4);
            row.addView(t, lp);
        }
    }

    private void writeReg(int idx) {
        try {
            int scale = regIn[idx].getTag() instanceof Integer ? (Integer) regIn[idx].getTag() : 1;
            double n = Double.parseDouble(regIn[idx].getText().toString().replace(',', '.'));
            int mag = (int) Math.round(Math.abs(n) * scale);
            if (REG[idx] == 41) mag = -mag;
            post("/api/bms", "pack=" + bmsPack + "&reg=" + REG[idx] + "&value=" + mag);
            status.setText("Пишу регистр " + REG[idx]);
        } catch (Exception e) {
            status.setText("Число не разобрать");
        }
    }

    private int scaleOf(String kind, int raw, int div) {
        int a = Math.abs(raw);
        if ("amp".equals(kind)) {
            if (div == 10 || div == 100) return div;
            if (a >= 500) return 100;
            if (a >= 200) return 10;
            return 1;
        }
        if ("ah".equals(kind)) return a >= 200 ? 100 : 1;
        if ("packv".equals(kind)) return 100;
        if ("cellv".equals(kind)) return 1000;
        return 1;
    }

    private String view(String kind, int raw, int scale) {
        double shown = Math.abs(raw) / (double) scale;
        if ("packv".equals(kind)) return String.format(java.util.Locale.US, "%.2f", shown);
        if ("cellv".equals(kind)) return String.format(java.util.Locale.US, "%.3f", shown);
        if ("ah".equals(kind) && scale > 1) return String.format(java.util.Locale.US, "%.2f", shown);
        if ("amp".equals(kind) && scale >= 100) return String.format(java.util.Locale.US, "%.2f", shown);
        if ("amp".equals(kind) && scale == 10) return String.format(java.util.Locale.US, "%.1f", shown);
        return String.valueOf((int) Math.round(shown));
    }

    private void saveMotor(boolean fitGps) {
        try {
            int circMm = parseInt(circ.getText().toString(), 0);
            int gearX = (int) Math.round(parseDouble(gear.getText().toString(), 1) * 1000);
            int trimX = (int) Math.round(parseDouble(trim.getText().toString(), 100) * 10);
            int poleN = parseInt(poles.getText().toString(), 20);
            double diamMm = parseDouble(diam.getText().toString(), 0);
            if (fitGps) {
                if (gpsKmh < 3 || cubeKmh < 3) {
                    status.setText("Для подгона нужны обе скорости больше 3 км/ч");
                    return;
                }
                trimX = (int) Math.round(trimX * gpsKmh / cubeKmh);
                if (trimX < 200) trimX = 200;
                if (trimX > 3000) trimX = 3000;
                trim.setText(String.format(java.util.Locale.US, "%.1f", trimX / 10.0));
            }
            double inches = diamMm > 0 ? diamMm / 25.4 : 0;
            StringBuilder q = new StringBuilder();
            q.append("circ=").append(circMm);
            q.append("&gear=").append(gearX);
            q.append("&trim=").append(trimX);
            q.append("&poles=").append(poleN);
            if (inches >= 8 && inches <= 40) q.append("&diam=").append(String.format(java.util.Locale.US, "%.1f", inches));
            post("/api/fardriver", q.toString());
            status.setText(fitGps ? "Подгон записан в куб" : "Размеры записаны в куб");
        } catch (Exception e) {
            status.setText("Поле мотора не число");
        }
    }

    private void startProxy() {
        try {
            proxy = new ServerSocket();
            proxy.setReuseAddress(true);
            proxy.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0));
            proxyPort = proxy.getLocalPort();
            proxyRun = true;
            net.execute(this::proxyLoop);
        } catch (Exception e) {
            proxyPort = -1;
        }
    }

    private void proxyLoop() {
        while (proxyRun) {
            try {
                Socket s = proxy.accept();
                net.execute(() -> serve(s));
            } catch (Exception e) {
                if (!proxyRun) return;
            }
        }
    }

    private void serve(Socket s) {
        try {
            s.setSoTimeout(8000);
            InputStream in = s.getInputStream();
            ByteArrayOutputStream head = new ByteArrayOutputStream();
            int prev = 0;
            while (head.size() < 8192) {
                int b = in.read();
                if (b < 0) break;
                head.write(b);
                if (prev == '\n' && b == '\n') break;
                if (head.size() >= 4) {
                    byte[] a = head.toByteArray();
                    int n = a.length;
                    if (n >= 4 && a[n - 4] == '\r' && a[n - 3] == '\n' && a[n - 2] == '\r' && a[n - 1] == '\n') break;
                }
                prev = b;
            }
            String hs = head.toString("ISO-8859-1");
            String[] lines = hs.split("\r\n");
            if (lines.length == 0 || lines[0].length() == 0) { s.close(); return; }
            String[] req = lines[0].split(" ");
            String method = req[0];
            String path = req.length > 1 ? req[1] : "/";
            int clen = 0;
            for (String line : lines) {
                if (line.toLowerCase(java.util.Locale.US).startsWith("content-length:")) {
                    clen = Integer.parseInt(line.substring(15).trim());
                }
            }
            byte[] body = new byte[Math.max(0, Math.min(clen, 2000000))];
            int got = 0;
            while (got < body.length) {
                int r = in.read(body, got, body.length - got);
                if (r < 0) break;
                got += r;
            }
            byte[] outBody;
            String ctype = "text/html; charset=utf-8";
            int code = 200;
            HttpURLConnection c = null;
            try {
                URL url = new URL(BASE + path);
                Network n = cubeNetwork();
                c = (HttpURLConnection) (n != null ? n.openConnection(url) : url.openConnection());
                c.setConnectTimeout(3000);
                c.setReadTimeout(8000);
                c.setRequestMethod(method);
                if (got > 0 && !"GET".equals(method) && !"HEAD".equals(method)) {
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    OutputStream os = c.getOutputStream();
                    os.write(body, 0, got);
                    os.close();
                }
                code = c.getResponseCode();
                if (c.getContentType() != null) ctype = c.getContentType();
                InputStream rin = code >= 400 ? c.getErrorStream() : c.getInputStream();
                outBody = rin == null ? new byte[0] : readBytes(rin, 4000000);
            } catch (Exception e) {
                code = 503;
                outBody = "<html><body style='background:#14120e;color:#f3efe4;font-family:sans-serif'><p>Куб ещё не в этой сети. Нажми «Подключить». Мобильный интернет при этом не отключается. Вкладки Кабина, Мотор, АКБ, Куб и Схема листаются и без связи.</p></body></html>".getBytes(StandardCharsets.UTF_8);
            } finally {
                if (c != null) c.disconnect();
            }
            String reason = code == 200 ? "OK" : "ERR";
            String hdr = "HTTP/1.1 " + code + " " + reason + "\r\nContent-Type: " + ctype
                    + "\r\nContent-Length: " + outBody.length + "\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n";
            OutputStream os = s.getOutputStream();
            os.write(hdr.getBytes(StandardCharsets.ISO_8859_1));
            os.write(outBody);
            os.flush();
        } catch (Exception ignored) {
        } finally {
            try { s.close(); } catch (Exception ignored) {}
        }
    }

    private byte[] readBytes(InputStream in, int cap) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        int total = 0;
        while ((n = in.read(buf)) > 0 && total < cap) {
            bos.write(buf, 0, n);
            total += n;
        }
        return bos.toByteArray();
    }

    private ScrollView scroll(LinearLayout child) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.setBackgroundColor(BG);
        sv.setClipToPadding(true);
        sv.addView(child);
        return sv;
    }

    private LinearLayout col() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(0, dp(8), 0, dp(24));
        return l;
    }

    /* Horizontal row with an 8 dp gap between neighbours. */
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        GradientDrawable gap = new GradientDrawable();
        gap.setSize(dp(8), 1);
        gap.setColor(0x00000000);
        l.setDividerDrawable(gap);
        l.setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
        return l;
    }

    /* Horizontal row without gaps, for text pieces that sit together. */
    private LinearLayout flat() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    /* Row of buttons that belong together: gap between, 8 dp above. */
    private LinearLayout seg() {
        LinearLayout l = row();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        l.setLayoutParams(lp);
        return l;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(CARD));
        int p = dp(16);
        l.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        l.setLayoutParams(lp);
        return l;
    }

    private LinearLayout cardOf(View v) {
        LinearLayout c = card();
        c.addView(v);
        return c;
    }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTypeface(Typeface.create("sans-serif-medium", bold ? Typeface.BOLD : Typeface.NORMAL));
        if (!bold) t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        return t;
    }

    private TextView hint(String text) {
        TextView t = label(text, 13, MUTED, false);
        t.setPadding(0, dp(6), 0, dp(4));
        return t;
    }

    private TextView metric(LinearLayout host, String name) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(round(CARD));
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView k = label(name, 12, MUTED, false);
        TextView v = label("—", 19, FG, true);
        box.addView(k);
        box.addView(v);
        box.setMinimumHeight(dp(66));
        host.addView(box, weight());
        return v;
    }

    private Button button(String text, boolean fill) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setStateListAnimator(null);
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        b.setMinimumWidth(0);
        b.setMinWidth(0);
        b.setPadding(dp(12), dp(12), dp(12), dp(12));
        b.setTextColor(fill ? INK : FG);
        b.setBackground(ripple(fill ? pill(COPPER, 0) : pill(CARD_HI, LINE)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        b.setOnTouchListener((v, ev) -> {
            if (ev.getAction() == android.view.MotionEvent.ACTION_DOWN)
                v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(80).start();
            if (ev.getAction() == android.view.MotionEvent.ACTION_UP
                    || ev.getAction() == android.view.MotionEvent.ACTION_CANCEL)
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
            return false;
        });
        return b;
    }

    private GradientDrawable pill(int fill, int line) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(14));
        if (line != 0) d.setStroke(dp(1), line);
        return d;
    }

    private RippleDrawable ripple(GradientDrawable base) {
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), base, null);
    }

    private EditText field(String hintText) {
        EditText e = new EditText(this);
        e.setHint(hintText);
        e.setHintTextColor(MUTED);
        e.setTextColor(FG);
        e.setBackground(pill(CARD_HI, LINE));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setSingleLine(true);
        return e;
    }

    private SeekBar bar(int min, int max, int value) {
        SeekBar s = new SeekBar(this);
        s.setPadding(dp(10), dp(8), dp(10), dp(8));
        s.setProgressTintList(ColorStateList.valueOf(COPPER));
        s.setThumbTintList(ColorStateList.valueOf(COPPER));
        s.setProgressBackgroundTintList(ColorStateList.valueOf(LINE));
        s.setMax(max);
        if (Build.VERSION.SDK_INT >= 26) s.setMin(min);
        s.setProgress(value);
        return s;
    }

    private LinearLayout named(String title, TextView value) {
        LinearLayout r = row();
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(8), 0, 0);
        TextView t = label(title, 14, MUTED, false);
        r.addView(t, weight());
        r.addView(value);
        return r;
    }

    private TextView big(LinearLayout host, String name) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), 0, dp(4), 0);
        box.addView(label(name, 13, MUTED, false));
        TextView v = label("0.0", 40, COPPER, true);
        box.addView(v);
        box.addView(label("км/ч", 12, MUTED, false));
        host.addView(box, weight());
        return v;
    }

    /* True while a slider is dragged and for 2.5 s after, so a poll that
     * still carries the old value cannot pull the slider back. */
    private boolean editing() {
        return touching || SystemClock.uptimeMillis() < holdUntil;
    }

    private void postLux() {
        int on = eve == null ? 30 : Math.max(0, eve.getProgress());
        int off = day == null ? 80 : Math.max(0, day.getProgress());
        post("/api/cabin", "lux_on=" + on + "&lux_off=" + off);
    }

    private SeekBar.OnSeekBarChangeListener slider(String key, int min, TextView live, String unit) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                int v = Math.max(min, p);
                if (live != null) live.setText(v + unit);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { touching = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                touching = false;
                holdUntil = SystemClock.uptimeMillis() + 2500;
                int v = Math.max(min, s.getProgress());
                post("/api/cabin", key + "=" + v);
            }
        };
    }

    private void mark(Button b, boolean on) {
        if (b == null) return;
        b.setSelected(on);
        b.setBackground(ripple(on ? pill(COPPER, 0) : pill(CARD_HI, LINE)));
        b.setTextColor(on ? INK : FG);
    }

    private GradientDrawable round(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(18));
        d.setStroke(dp(1), LINE);
        return d;
    }

    private GradientDrawable stroke() {
        return pill(CARD_HI, LINE);
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private String temp(int hundredths) {
        int sign = hundredths < 0 ? -1 : 1;
        int a = Math.abs(hundredths);
        return (sign < 0 ? "-" : "") + (a / 100) + "." + (a % 100 / 10) + "°";
    }

    private String tempOr(org.json.JSONObject j, String okKey, String key) {
        int v = j.optInt(key, -32768);
        if (v == -32768) return "нет";
        return temp(v);
    }

    private int clamp(int v, int lo, int hi) {
        if (v < lo) return lo;
        if (v > hi) return hi;
        return v;
    }

    private void pickFirmware() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, 62);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == 62 && result == RESULT_OK && data != null && data.getData() != null)
            uploadFirmware(data.getData());
    }

    private void uploadFirmware(Uri uri) {
        status.setText("Шлю прошивку…");
        net.execute(() -> {
            HttpURLConnection c = null;
            try {
                java.io.InputStream in = getContentResolver().openInputStream(uri);
                if (in == null) {
                    ui.post(() -> status.setText("Файл не открылся"));
                    return;
                }
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                int total = 0;
                while ((n = in.read(buf)) > 0 && total < 1700000) {
                    bos.write(buf, 0, n);
                    total += n;
                }
                in.close();
                byte[] bin = bos.toByteArray();
                if (bin.length < 24 || (bin[0] & 0xFF) != 0xE9) {
                    ui.post(() -> status.setText("Это не файл прошивки"));
                    return;
                }
                URL url = new URL(BASE + "/api/ota");
                Network netw = cubeNetwork();
                c = (HttpURLConnection) (netw != null ? netw.openConnection(url) : url.openConnection());
                c.setConnectTimeout(8000);
                c.setReadTimeout(120000);
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setFixedLengthStreamingMode(bin.length);
                c.setRequestProperty("Content-Type", "application/octet-stream");
                java.io.OutputStream os = c.getOutputStream();
                os.write(bin);
                os.close();
                int code = c.getResponseCode();
                ui.post(() -> status.setText(code == 200 ? "Куб пишет и перезагрузится" : "Прошивка не принята"));
            } catch (Exception e) {
                ui.post(() -> status.setText("Прошивка не ушла"));
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private String one(double v) {
        return String.format(java.util.Locale.US, "%.1f", v);
    }

    private int parseInt(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return fallback; }
    }

    private double parseDouble(String s, double fallback) {
        try { return Double.parseDouble(s.trim().replace(',', '.')); } catch (Exception e) { return fallback; }
    }
}
