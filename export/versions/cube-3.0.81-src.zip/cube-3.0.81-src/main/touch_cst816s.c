#include "touch_cst816s.h"
#include "config.h"
#include "app_state.h"
#include "driver/gpio.h"
#include "driver/spi_master.h"
#include "esp_log.h"
#include "esp_timer.h"

static const char *TAG = "TOUCH";
static spi_device_handle_t s_dev;
static bool s_ok;
static int s_logs;
static int s_z_gate = 80;
static int s_last_z;
static int s_irq_low;

int touch_last_z(void) { return s_last_z; }
int touch_irq_low(void) { return s_irq_low; }

void touch_set_gate(int z)
{
    if (z < 40) z = 40;
    if (z > 400) z = 400;
    s_z_gate = z;
}

int touch_get_gate(void)
{
    return s_z_gate;
}

static int pen_down(void)
{
#if CUBE_XPT_IRQ_GPIO >= 0
    return gpio_get_level(CUBE_XPT_IRQ_GPIO) == 0;
#else
    return 1;
#endif
}

static int xpt_sample(uint8_t cmd)
{
    spi_transaction_t tr = {
        .cmd = cmd,
        .rxlength = 16,
        .flags = SPI_TRANS_USE_RXDATA,
    };
    if (!s_dev || spi_device_polling_transmit(s_dev, &tr) != ESP_OK) return -1;
    return (((int)tr.rx_data[0] << 8 | tr.rx_data[1]) >> 3) & 0x0FFF;
}

static int xpt_settled(uint8_t cmd)
{
    (void)xpt_sample(cmd);
    return xpt_sample(cmd);
}

static int map_raw(int raw, int lo, int hi, int span)
{
    if (raw < lo) raw = lo;
    if (raw > hi) raw = hi;
    return (raw - lo) * (span - 1) / (hi - lo);
}

esp_err_t touch_init(void)
{
    if (s_ok && s_dev) {
        ESP_LOGW(TAG, "XPT2046 already on SPI CS=%d", CUBE_XPT_CS_GPIO);
        return ESP_OK;
    }
    app_state_set_touch(false, false);
    ESP_LOGW(TAG, "XPT2046 not on the bus yet");
    return ESP_OK;
}

esp_err_t touch_attach_spi(void)
{
    spi_device_interface_config_t dev = {
        .clock_speed_hz = 2000000,
        .mode = 0,
        .spics_io_num = CUBE_XPT_CS_GPIO,
        .queue_size = 1,
        .command_bits = 8,
        .flags = SPI_DEVICE_HALFDUPLEX,
    };
    esp_err_t err = spi_bus_add_device(SPI2_HOST, &dev, &s_dev);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "XPT2046 add failed: %s", esp_err_to_name(err));
        return err;
    }
    s_ok = true;
    app_state_set_touch(true, false);
#if CUBE_XPT_IRQ_GPIO >= 0
    gpio_config_t io = {
        .pin_bit_mask = 1ULL << CUBE_XPT_IRQ_GPIO,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io);
#endif
    ESP_LOGW(TAG, "XPT2046 CS=%d IRQ=%d MISO=%d только T_DO", CUBE_XPT_CS_GPIO, CUBE_XPT_IRQ_GPIO, CUBE_LCD_MISO_GPIO);
    return ESP_OK;
}

bool touch_is_available(void) { return s_ok; }

void touch_lvgl_read(lv_indev_drv_t *drv, lv_indev_data_t *data)
{
    (void)drv;
    static int16_t last_x;
    static int16_t last_y;
    static int stable;
    static int idle;
    if (!s_ok) {
        data->state = LV_INDEV_STATE_REL;
        data->point.x = last_x;
        data->point.y = last_y;
        return;
    }
    s_irq_low = pen_down();
    int z = xpt_settled(0xB0);
    int xraw = xpt_settled(0xD0);
    int yraw = xpt_settled(0x90);
    s_last_z = z;
    bool coords = xraw > 150 && yraw > 150 && xraw < 3950 && yraw < 3950;
    bool zhit = z > s_z_gate && z < 4000;
    /* IRQ on GPIO41 is only a hint. A stuck or quiet line must not hide a real press. */
    bool hit = coords && (zhit || s_irq_low);
    int x = map_raw(xraw < 0 ? 0 : xraw, 300, 3800, CUBE_LCD_H_RES);
    int y = map_raw(yraw < 0 ? 0 : yraw, 300, 3800, CUBE_LCD_V_RES);
#if CUBE_TOUCH_INVERT_X
    x = CUBE_LCD_H_RES - 1 - x;
#endif
#if CUBE_TOUCH_INVERT_Y
    y = CUBE_LCD_V_RES - 1 - y;
#endif
    {
        static int64_t s_log_us;
        int64_t now = esp_timer_get_time();
        if (now - s_log_us > 15000000) {
            s_log_us = now;
            ESP_LOGW(TAG, "тач z=%d x=%d y=%d irq=%d", z, xraw, yraw, s_irq_low);
        }
    }
    if (hit && s_logs < 8) {
        ESP_LOGI(TAG, "raw x=%d y=%d z=%d -> %d,%d", xraw, yraw, z, x, y);
        s_logs++;
    }
    if (hit) {
        idle = 0;
        if (stable < 4) stable++;
        last_x = (int16_t)x;
        last_y = (int16_t)y;
    } else {
        stable = 0;
        if (idle < 3) idle++;
    }
    data->point.x = last_x;
    data->point.y = last_y;
    data->state = (stable >= 2) ? LV_INDEV_STATE_PR : LV_INDEV_STATE_REL;
    app_state_set_touch(true, data->state == LV_INDEV_STATE_PR);
}
