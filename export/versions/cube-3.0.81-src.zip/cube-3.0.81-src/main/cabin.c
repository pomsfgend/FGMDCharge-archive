#include "cabin.h"

#include "app_state.h"
#include "config.h"
#include "sm_relay.h"

#include <stdio.h>
#include <string.h>

#include "driver/gpio.h"
#include "driver/i2c.h"
#include "driver/ledc.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_adc/adc_cali.h"
#include "esp_adc/adc_cali_scheme.h"
#include "esp_log.h"
#include "esp_rom_sys.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "nvs.h"

static const char *TAG = "CABIN";

#define OW_PIN CUBE_SEAT_OW_GPIO
#define I2C_PORT ((i2c_port_t)CUBE_CABIN_I2C_PORT)
#define NO_TEMP (-32768)

typedef struct {
    int16_t comfort;
    int16_t seat_max;
    int16_t amp_lim;
    int16_t lux_on;
    int16_t lux_off;
    uint8_t heat;
    uint8_t light;
    uint8_t duty_max;
    uint8_t rel;
    uint8_t heat_mode;
    uint8_t manual_duty;
    int16_t amb_on;
} cfg_t;

static cfg_t s_cfg;
static SemaphoreHandle_t s_mu;
static int s_ready;
static int s_amb = NO_TEMP;
static int s_seat = NO_TEMP;
static int s_lux = -1;
static int s_ima = 0;
static int s_zvs_mv = 0;
static int s_duty;
static int s_bme_ok;
static int s_bh_ok;
static int s_ina_ok;
static int s_seat_ok;
static int s_seat_miss;
static volatile int64_t s_seat_ms;      /* time of the last good sample */
static volatile int s_seat_pred;        /* seat temp + lead, 0.01 C */
static volatile int s_seat_rate;        /* 0.01 C per second */
static volatile int s_seat_dt_ms = 400; /* spacing of good samples */
static volatile int s_pid_out;          /* duty from the PID, 0..100 */
static int s_amb_miss;
static int s_auto_off_min = 90;          /* heater switch turns itself off after this; 0 = never */
static int64_t s_heat_t0;                /* when the heater switch went on, ms; 0 = off */
static int s_heat_left = -1;             /* minutes left, -1 = no timer running */
static int s_i2c_ticks;
static int s_mcp_ok;
static int s_zvs_ok;
static int s_lamp;
static uint8_t s_rel_now;
static char s_fault[8];
static uint8_t s_bme_addr;
static uint8_t s_bh_addr;
static int s_bh_kind; /* 1 = BH1750, 2 = MAX44009 on GY-39 */
static uint8_t s_ina_addr;
static uint8_t s_mcp_addr;
static uint16_t s_t1;
static int16_t s_t2;
static int16_t s_t3;
static int32_t s_pid_i;
static adc_oneshot_unit_handle_t s_adc;
static adc_cali_handle_t s_cal;

static void fault_set(const char *s)
{
    snprintf(s_fault, sizeof(s_fault), "%s", s ? s : "");
}

static void cfg_defaults(void)
{
    memset(&s_cfg, 0, sizeof(s_cfg));
    s_cfg.comfort = 3200;
    s_cfg.seat_max = 4200;
    s_cfg.amp_lim = 8000;
    s_cfg.lux_on = 30;
    s_cfg.lux_off = 80;
    s_cfg.light = 2;
    s_cfg.duty_max = 100;
    s_cfg.heat_mode = 0;
    s_cfg.manual_duty = 0;
    s_cfg.amb_on = 1000;
}

static void auto_off_load(void);

static void cfg_load(void)
{
    nvs_handle_t h;
    cfg_t tmp;
    size_t n = sizeof(tmp);
    cfg_defaults();
    if (nvs_open("cabin", NVS_READONLY, &h) != ESP_OK) return;
    if (nvs_get_blob(h, "cfg", &tmp, &n) == ESP_OK && n == sizeof(tmp)) {
        s_cfg = tmp;
    }
    nvs_close(h);
    if (s_cfg.comfort < 0 || s_cfg.comfort > 12000) s_cfg.comfort = 3200;
    if (s_cfg.seat_max < 2000 || s_cfg.seat_max > 14000) s_cfg.seat_max = 4200;
    if (s_cfg.amp_lim < 500 || s_cfg.amp_lim > 20000) s_cfg.amp_lim = 8000;
    if (s_cfg.lux_on == 40 && s_cfg.lux_off == 120) {
        s_cfg.lux_on = 30;
        s_cfg.lux_off = 80;
    }
    if (s_cfg.duty_max > 100) s_cfg.duty_max = 100;
    if (s_cfg.heat_mode > 1) s_cfg.heat_mode = 0;
    if (s_cfg.manual_duty > 100) s_cfg.manual_duty = 0;
    if (s_cfg.amb_on < -4000 || s_cfg.amb_on > 7000) s_cfg.amb_on = 1000;
    if (s_cfg.light > 2) s_cfg.light = 2;
    /* Converter output opens after reboot. GPIO39 is not a relay. */
    s_cfg.rel = (uint8_t)(s_cfg.rel & (uint8_t)~(1u << 4));
    s_cfg.heat = 0;
    auto_off_load();
}

static void cfg_save(void)
{
    nvs_handle_t h;
    cfg_t c;
    if (s_mu) xSemaphoreTake(s_mu, portMAX_DELAY);
    c = s_cfg;
    if (s_mu) xSemaphoreGive(s_mu);
    if (nvs_open("cabin", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_blob(h, "cfg", &c, sizeof(c));
    nvs_commit(h);
    nvs_close(h);
}

static esp_err_t i2c_w(uint8_t addr, const uint8_t *d, size_t n)
{
    return i2c_master_write_to_device(I2C_PORT, addr, d, n, pdMS_TO_TICKS(40));
}

static esp_err_t i2c_wr(uint8_t addr, uint8_t reg, uint8_t *out, size_t n)
{
    return i2c_master_write_read_device(I2C_PORT, addr, &reg, 1, out, n, pdMS_TO_TICKS(40));
}

static int i2c_probe(uint8_t addr)
{
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    esp_err_t err;
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (uint8_t)((addr << 1) | I2C_MASTER_WRITE), true);
    i2c_master_stop(cmd);
    err = i2c_master_cmd_begin(I2C_PORT, cmd, pdMS_TO_TICKS(25));
    i2c_cmd_link_delete(cmd);
    return err == ESP_OK;
}

static const int k_rel_gpio[8] = {42, -1, 40, -1, -1, -1, -1, -1};

static void rel_apply(uint8_t olat)
{
    int i;
    for (i = 0; i < 8; ++i) {
        if (k_rel_gpio[i] < 0) continue;
        gpio_set_level(k_rel_gpio[i], (olat & (1u << i)) ? 1 : 0);
    }
    s_rel_now = (uint8_t)~olat;
}

static void rel_gpio_init(void)
{
    uint64_t mask = 0;
    int i;
    gpio_config_t io;
    for (i = 0; i < 8; ++i) {
        if (k_rel_gpio[i] < 0) continue;
        gpio_set_level(k_rel_gpio[i], 1);
        mask |= (1ULL << k_rel_gpio[i]);
    }
    io.pin_bit_mask = mask;
    io.mode = GPIO_MODE_OUTPUT;
    io.pull_up_en = GPIO_PULLUP_DISABLE;
    io.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io.intr_type = GPIO_INTR_DISABLE;
    gpio_config(&io);
    for (i = 0; i < 8; ++i) {
        if (k_rel_gpio[i] < 0) continue;
        gpio_set_level(k_rel_gpio[i], 1);
    }
}

static void mcp_bind(void)
{
    uint8_t addr;
    uint8_t b[2];
    s_mcp_ok = 0;
    for (addr = 0x20; addr <= 0x27; ++addr) {
        if (!i2c_probe(addr)) continue;
        b[0] = 0x00;
        b[1] = 0x00;
        if (i2c_w(addr, b, 2) != ESP_OK) continue;
        b[0] = 0x01;
        b[1] = 0xFF;
        if (i2c_w(addr, b, 2) != ESP_OK) continue;
        s_mcp_addr = addr;
        s_mcp_ok = 1;
        ESP_LOGW(TAG, "MCP23017 0x%02X ignored, relays are direct GPIO", addr);
        return;
    }
    ESP_LOGW(TAG, "MCP23017 not found");
}

static int bme_c100(const uint8_t *raw)
{
    int32_t adc = ((int32_t)raw[3] << 12) | ((int32_t)raw[4] << 4) | (raw[5] >> 4);
    int32_t v1;
    int32_t v2;
    int32_t fine;
    if (adc == 0x80000) return NO_TEMP;
    v1 = ((((adc >> 3) - ((int32_t)s_t1 << 1))) * (int32_t)s_t2) >> 11;
    v2 = (((((adc >> 4) - (int32_t)s_t1) * ((adc >> 4) - (int32_t)s_t1)) >> 12) * (int32_t)s_t3) >> 14;
    fine = v1 + v2;
    return (int)((fine * 5 + 128) >> 8);
}

static void bme_bind(void)
{
    uint8_t id = 0;
    uint8_t cal[6];
    uint8_t cmd[2];
    int i;
    s_bme_ok = 0;
    for (i = 0; i < 2; ++i) {
        uint8_t addr = i ? 0x77 : 0x76;
        if (i2c_wr(addr, 0xD0, &id, 1) != ESP_OK) continue;
        if (id != 0x60 && id != 0x58) continue;
        if (i2c_wr(addr, 0x88, cal, 6) != ESP_OK) continue;
        s_t1 = (uint16_t)(cal[0] | ((uint16_t)cal[1] << 8));
        s_t2 = (int16_t)(cal[2] | ((uint16_t)cal[3] << 8));
        s_t3 = (int16_t)(cal[4] | ((uint16_t)cal[5] << 8));
        if (id == 0x60) {
            cmd[0] = 0xF2;
            cmd[1] = 0x01;
            i2c_w(addr, cmd, 2);
        }
        cmd[0] = 0xF4;
        cmd[1] = 0x27;
        if (i2c_w(addr, cmd, 2) != ESP_OK) continue;
        s_bme_addr = addr;
        s_bme_ok = 1;
        ESP_LOGW(TAG, "BME/BMP 0x%02X id 0x%02X", addr, id);
        return;
    }
    ESP_LOGW(TAG, "BME280 not found");
}

static void bme_read(void)
{
    uint8_t raw[8];
    int t;
    if (!s_bme_ok) return;
    if (i2c_wr(s_bme_addr, 0xF7, raw, 8) != ESP_OK) {
        if (s_amb_miss < 100) s_amb_miss++;
        if (s_amb_miss >= 20) s_amb = NO_TEMP;
        return;
    }
    t = bme_c100(raw);
    if (t > -4000 && t < 8500) {
        s_amb = t;
        s_amb_miss = 0;
    }
}

static void bh_bind(void)
{
    uint8_t cmd;
    uint8_t dummy;
    int i;
    s_bh_ok = 0;
    s_bh_kind = 0;
    for (i = 0; i < 2; ++i) {
        uint8_t addr = i ? 0x5C : 0x23;
        cmd = 0x01;
        if (i2c_w(addr, &cmd, 1) != ESP_OK) continue;
        cmd = 0x10;
        if (i2c_w(addr, &cmd, 1) != ESP_OK) continue;
        s_bh_addr = addr;
        s_bh_kind = 1;
        s_bh_ok = 1;
        ESP_LOGW(TAG, "BH1750 0x%02X", addr);
        return;
    }
    if (i2c_wr(0x4A, 0x03, &dummy, 1) == ESP_OK) {
        s_bh_addr = 0x4A;
        s_bh_kind = 2;
        s_bh_ok = 1;
        ESP_LOGW(TAG, "MAX44009 0x4A");
        return;
    }
    ESP_LOGW(TAG, "light sensor not found");
}

static void bh_read(void)
{
    uint8_t raw[2];
    int lux;
    if (!s_bh_ok) {
        s_lux = -1;
        return;
    }
    if (s_bh_kind == 2) {
        int exp;
        int mant;
        if (i2c_wr(s_bh_addr, 0x03, raw, 1) != ESP_OK) {
            s_lux = -1;
            return;
        }
        if (i2c_wr(s_bh_addr, 0x04, raw + 1, 1) != ESP_OK) {
            s_lux = -1;
            return;
        }
        exp = (raw[0] >> 4) & 0x0F;
        mant = ((raw[0] & 0x0F) << 4) | (raw[1] & 0x0F);
        if (exp > 14) exp = 14;
        lux = ((1 << exp) * mant * 45) / 1000;
    } else if (i2c_master_read_from_device(I2C_PORT, s_bh_addr, raw, 2, pdMS_TO_TICKS(40)) != ESP_OK) {
        s_lux = -1;
        return;
    } else {
        lux = (((int)raw[0] << 8) | raw[1]) * 10 / 12;
    }
    if (lux < 0) lux = 0;
    if (lux > 100000) lux = 100000;
    s_lux = lux;
}

static void ina_bind(void)
{
    static const uint8_t addrs[] = {0x40, 0x41, 0x44, 0x45};
    uint8_t cfg[3] = {0x00, 0x39, 0x9F};
    uint8_t cal[3] = {0x05, 0x01, 0x9A};
    size_t i;
    s_ina_ok = 0;
    for (i = 0; i < sizeof(addrs); ++i) {
        if (i2c_w(addrs[i], cfg, 3) != ESP_OK) continue;
        if (i2c_w(addrs[i], cal, 3) != ESP_OK) continue;
        s_ina_addr = addrs[i];
        s_ina_ok = 1;
        ESP_LOGW(TAG, "INA219 0x%02X shunt 0.1 ohm, about 3 A max", addrs[i]);
        return;
    }
    ESP_LOGW(TAG, "INA219 not found");
}

static void ina_read(void)
{
    uint8_t raw[2];
    int16_t ma;
    if (!s_ina_ok) {
        s_ima = 0;
        return;
    }
    if (i2c_wr(s_ina_addr, 0x04, raw, 2) != ESP_OK) {
        s_ima = 0;
        return;
    }
    ma = (int16_t)((raw[0] << 8) | raw[1]);
    s_ima = ma;
}

static void ow_low(void) { gpio_set_level(OW_PIN, 0); }
static void ow_rel(void) { gpio_set_level(OW_PIN, 1); }
static int ow_bit(void) { return gpio_get_level(OW_PIN); }

static int ow_reset(void)
{
    int p;
    ow_low();
    esp_rom_delay_us(480);
    portDISABLE_INTERRUPTS();
    ow_rel();
    esp_rom_delay_us(70);
    p = ow_bit();
    portENABLE_INTERRUPTS();
    esp_rom_delay_us(410);
    return p == 0;
}

static void ow_write(uint8_t v)
{
    int i;
    for (i = 0; i < 8; ++i) {
        portDISABLE_INTERRUPTS();
        ow_low();
        if (v & 1) {
            esp_rom_delay_us(6);
            ow_rel();
            esp_rom_delay_us(64);
        } else {
            esp_rom_delay_us(60);
            ow_rel();
            esp_rom_delay_us(10);
        }
        portENABLE_INTERRUPTS();
        v >>= 1;
    }
}

static uint8_t ow_readb(void)
{
    uint8_t v = 0;
    int i;
    for (i = 0; i < 8; ++i) {
        int b;
        portDISABLE_INTERRUPTS();
        ow_low();
        esp_rom_delay_us(3);
        ow_rel();
        esp_rom_delay_us(9);
        b = ow_bit();
        portENABLE_INTERRUPTS();
        esp_rom_delay_us(55);
        v |= (uint8_t)(b << i);
    }
    return v;
}

static uint8_t ow_crc(const uint8_t *d, int n)
{
    uint8_t crc = 0;
    int i;
    int j;
    for (i = 0; i < n; ++i) {
        uint8_t b = d[i];
        for (j = 0; j < 8; ++j) {
            uint8_t mix = (uint8_t)((crc ^ b) & 1u);
            crc >>= 1;
            if (mix) crc ^= 0x8C;
            b >>= 1;
        }
    }
    return crc;
}

static void ow_init(void)
{
    gpio_config_t io = {
        .pin_bit_mask = 1ULL << OW_PIN,
        .mode = GPIO_MODE_INPUT_OUTPUT_OD,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io);
    gpio_set_level(OW_PIN, 1);
}

/* ------------------------------------------------------------------ */
/* Seat probe (DS18B20) and heater regulator, 3.0.79.                  */
/*                                                                     */
/* 3.0.78 sampled in the 40 ms cabin loop at 9 bit (0.5 C steps) and   */
/* regulated on the raw value: PWM jumped on quantisation noise and    */
/* followed the probe with its full thermal lag.                       */
/* Now: own task on core 1, 11 bit (0.125 C), the end of the           */
/* conversion is polled instead of guessed, a median of 3 removes      */
/* glitches, and the regulator works on the temperature the seat will  */
/* have in a few seconds (value + rate * lead), which cancels the lag. */
/* ------------------------------------------------------------------ */

#define SEAT_CFG_BYTE   0x5F   /* DS18B20 config: 11 bit, 375 ms max */
#define SEAT_MIN_WAIT   260    /* ms before the first completion poll */
#define SEAT_LEAD_MS    4000   /* lead time of the predicted value */
#define SEAT_LEAD_MAX   150    /* never lead by more than 1.5 C */
#define SEAT_MISS_MAX   8      /* failed reads in a row before "seat" fault */
#define SEAT_STALE_MS   2500   /* no good sample for this long: heater off */
#define SEAT_HIST       16

/* SEAT-LOGIC-BEGIN (plain C, covered by host_tests/test_seat.c) */
typedef struct {
    int32_t t[SEAT_HIST];
    int64_t ms[SEAT_HIST];
    int n;
    int head;
    int m[3];
    int mn;
} seat_filter_t;

static int seat_med3(int a, int b, int c)
{
    int x;
    if (a > b) { x = a; a = b; b = x; }
    if (b > c) { x = b; b = c; c = x; }
    if (a > b) { b = a; }
    return b;
}

/* Feeds one raw reading (0.01 C). Returns the filtered value. */
static int seat_filter_push(seat_filter_t *f, int raw, int64_t now_ms)
{
    int v;
    if (f->mn < 3) {
        int i;
        for (i = f->mn; i < 3; ++i) f->m[i] = raw;   /* first sample fills the window */
        f->mn = 3;
    } else {
        f->m[0] = f->m[1];
        f->m[1] = f->m[2];
        f->m[2] = raw;
    }
    v = seat_med3(f->m[0], f->m[1], f->m[2]);
    f->t[f->head] = v;
    f->ms[f->head] = now_ms;
    f->head = (f->head + 1) % SEAT_HIST;
    if (f->n < SEAT_HIST) f->n++;
    return v;
}

/* Rate in 0.01 C/s over about 2..3 s of history. */
static int seat_filter_rate(const seat_filter_t *f)
{
    int newest;
    int i;
    int pick = -1;
    int64_t age;
    if (f->n < 3) return 0;
    newest = (f->head + SEAT_HIST - 1) % SEAT_HIST;
    for (i = 1; i < f->n; ++i) {
        int k = (newest + SEAT_HIST - i) % SEAT_HIST;
        age = f->ms[newest] - f->ms[k];
        pick = k;
        if (age >= 2500) break;
    }
    if (pick < 0) return 0;
    age = f->ms[newest] - f->ms[pick];
    if (age < 800) return 0;
    return (int)(((int64_t)(f->t[newest] - f->t[pick]) * 1000) / age);
}

static int seat_lead(int rate)
{
    int lead = (int)((int64_t)rate * SEAT_LEAD_MS / 1000);
    if (lead > SEAT_LEAD_MAX) lead = SEAT_LEAD_MAX;
    if (lead < -SEAT_LEAD_MAX) lead = -SEAT_LEAD_MAX;
    return lead;
}

/* One regulator step. err and integral are in 0.01 C and 0.01 C*s.
 * 25 % duty per degree, integral worth 5 %/s per degree, capped at 30 %. */
static int seat_pid_step(int comfort, int pred, int dt_ms, int32_t *integ)
{
    int err = comfort - pred;
    int out = err / 4 + (int)(*integ / 20);
    if (!((out >= 100 && err > 0) || (out <= 0 && err < 0))) {
        *integ += (int32_t)((int64_t)err * dt_ms / 1000);
    }
    if (*integ > 600) *integ = 600;
    if (*integ < 0) *integ = 0;
    out = err / 4 + (int)(*integ / 20);
    if (out < 0) out = 0;
    if (out > 100) out = 100;
    return out;
}
/* SEAT-LOGIC-END */

static seat_filter_t s_sf;
static int s_ow_cfg_ok;

static int ow_slot(void)
{
    int b;
    portDISABLE_INTERRUPTS();
    ow_low();
    esp_rom_delay_us(3);
    ow_rel();
    esp_rom_delay_us(9);
    b = ow_bit();
    portENABLE_INTERRUPTS();
    esp_rom_delay_us(55);
    return b;
}

static void seat_glitch(void)
{
    if (s_seat_miss < 100) s_seat_miss++;
    if (s_seat_miss >= SEAT_MISS_MAX) {
        s_seat_ok = 0;
        s_seat = NO_TEMP;
        s_pid_i = 0;
        s_pid_out = 0;
        memset(&s_sf, 0, sizeof(s_sf));
    }
}

/* One full convert + read. Returns 0 and the temperature in 0.01 C. */
static int seat_read_once(int *out_c100)
{
    uint8_t sp[9];
    int i;
    int16_t raw;
    int64_t t0;

    if (!ow_reset()) return -1;
    if (!s_ow_cfg_ok) {
        ow_write(0xCC);
        ow_write(0x4E);
        ow_write(0x4B);
        ow_write(0x00);
        ow_write(SEAT_CFG_BYTE);
        if (!ow_reset()) return -1;
    }
    ow_write(0xCC);
    ow_write(0x44);

    vTaskDelay(pdMS_TO_TICKS(SEAT_MIN_WAIT));
    t0 = esp_timer_get_time();
    /* A powered DS18B20 answers 0 to a read slot while it converts and 1
     * when done. No fixed guess about the conversion time. */
    for (;;) {
        if (ow_slot()) break;
        if ((esp_timer_get_time() - t0) > 900000) return -1;
        vTaskDelay(1);
    }

    if (!ow_reset()) return -1;
    ow_write(0xCC);
    ow_write(0xBE);
    for (i = 0; i < 9; ++i) sp[i] = ow_readb();
    if (ow_crc(sp, 8) != sp[8]) return -1;

    s_ow_cfg_ok = (sp[4] == SEAT_CFG_BYTE);
    raw = (int16_t)(sp[0] | ((uint16_t)sp[1] << 8));
    /* 85.0 C is the power-on value: a read before the conversion ended. */
    if (raw == 0x0550 && !(s_seat_ok && s_seat > 7000)) return -1;
    if (s_ow_cfg_ok) raw = (int16_t)(raw & ~1);   /* bit 0 undefined at 11 bit */
    *out_c100 = (int)raw * 25 / 4;                /* 1/16 C -> 0.01 C */
    if (*out_c100 < -5500 || *out_c100 > 12500) return -1;
    return 0;
}

static void seat_task(void *arg)
{
    (void)arg;
    for (;;) {
        int c100;
        if (seat_read_once(&c100) == 0) {
            int64_t now = esp_timer_get_time() / 1000;
            int filt;
            int rate;
            int comfort;
            int dt;
            if (s_seat_ms != 0) {
                dt = (int)(now - s_seat_ms);
                if (dt < 100) dt = 100;
                if (dt > 2000) dt = 2000;
                s_seat_dt_ms = (s_seat_dt_ms * 3 + dt) / 4;
            } else {
                dt = 400;
            }
            filt = seat_filter_push(&s_sf, c100, now);
            rate = seat_filter_rate(&s_sf);
            if (s_mu) xSemaphoreTake(s_mu, portMAX_DELAY);
            comfort = s_cfg.comfort;
            if (s_mu) xSemaphoreGive(s_mu);
            s_seat_rate = rate;
            s_seat_pred = filt + seat_lead(rate);
            s_pid_out = seat_pid_step(comfort, s_seat_pred, dt, &s_pid_i);
            s_seat_miss = 0;
            s_seat = filt;
            s_seat_ms = now;
            s_seat_ok = 1;
        } else {
            seat_glitch();
            vTaskDelay(pdMS_TO_TICKS(60));
        }
    }
}

static void adc_bind(void)
{
    adc_oneshot_unit_init_cfg_t unit = {
        .unit_id = CUBE_ZVS_ADC_UNIT,
        .ulp_mode = ADC_ULP_MODE_DISABLE,
    };
    adc_oneshot_chan_cfg_t chan = {
        .atten = ADC_ATTEN_DB_12,
        .bitwidth = ADC_BITWIDTH_12,
    };
    s_zvs_ok = 0;
    if (adc_oneshot_new_unit(&unit, &s_adc) != ESP_OK) {
        ESP_LOGW(TAG, "ADC unit fail");
        return;
    }
    if (adc_oneshot_config_channel(s_adc, CUBE_ZVS_ADC_CHANNEL, &chan) != ESP_OK) {
        ESP_LOGW(TAG, "ADC channel fail");
        return;
    }
#if ADC_CALI_SCHEME_CURVE_FITTING_SUPPORTED
    {
        adc_cali_curve_fitting_config_t cal = {
            .unit_id = CUBE_ZVS_ADC_UNIT,
            .atten = ADC_ATTEN_DB_12,
            .bitwidth = ADC_BITWIDTH_12,
        };
        if (adc_cali_create_scheme_curve_fitting(&cal, &s_cal) != ESP_OK) s_cal = NULL;
    }
#endif
    s_zvs_ok = 1;
    ESP_LOGW(TAG, "ZVS sense GPIO%d", CUBE_ZVS_ADC_GPIO);
}

static int s_zvs_smooth = -1;
static int s_zvs_hi_ms = 0;

static int sample_med(int *v, int n)
{
    int a, b, t;
    for (a = 1; a < n; ++a) {
        t = v[a];
        b = a;
        while (b > 0 && v[b - 1] > t) {
            v[b] = v[b - 1];
            b--;
        }
        v[b] = t;
    }
    return v[n / 2];
}

static void adc_read(void)
{
    int i;
    int n = 0;
    int raws[31];
    int raw;
    int mv = 0;
    if (!s_zvs_ok || !s_adc) {
        s_zvs_mv = 0;
        return;
    }
    for (i = 0; i < 31; ++i) {
        int r = 0;
        if (adc_oneshot_read(s_adc, CUBE_ZVS_ADC_CHANNEL, &r) != ESP_OK) continue;
        if (r < 0) r = 0;
        if (r > 4095) r = 4095;
        raws[n++] = r;
    }
    if (n < 15) return;
    raw = sample_med(raws, n);
    if (s_cal && adc_cali_raw_to_voltage(s_cal, raw, &mv) != ESP_OK) mv = 0;
    if (mv <= 0) mv = raw * 3300 / 4095;
    if (mv < 0) mv = 0;
    mv = (int)((int64_t)mv * (CUBE_ZVS_RTOP_OHM + CUBE_ZVS_RBOT_OHM) / CUBE_ZVS_RBOT_OHM);
    mv = (int)((int64_t)mv * CUBE_ZVS_TRIM_NUM / CUBE_ZVS_TRIM_DEN);
    if (s_zvs_smooth < 0) s_zvs_smooth = mv;
    else s_zvs_smooth = (s_zvs_smooth * 15 + mv) / 16;
    s_zvs_mv = s_zvs_smooth;
}

static void pwm_bind(void)
{
    ledc_timer_config_t t = {
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .duty_resolution = LEDC_TIMER_10_BIT,
        .timer_num = LEDC_TIMER_1,
        .freq_hz = 500,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ledc_channel_config_t c = {
        .gpio_num = CUBE_HEAT_PWM_GPIO,
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LEDC_CHANNEL_1,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = LEDC_TIMER_1,
        .duty = 0,
        .hpoint = 0,
    };
    if (ledc_timer_config(&t) != ESP_OK) {
        t.freq_hz = 200;
        ledc_timer_config(&t);
    }
    ledc_channel_config(&c);
    ESP_LOGW(TAG, "heat PWM GPIO%d", CUBE_HEAT_PWM_GPIO);
}

static void pwm_set(int duty)
{
    uint32_t d;
    if (duty < 0) duty = 0;
    if (duty > 100) duty = 100;
    s_duty = duty;
    d = (uint32_t)duty * 1023u / 100u;
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1, d);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1);
}

static int station_pushing(void)
{
    cube_state_snapshot_t st;
    int a;
    app_state_snapshot(&st);
    if (!st.session_active) return 0;
    a = st.ccs_output_current_0p1a;
    if (a < 0) a = -a;
    return a > 20;
}

static void apply_out(void)
{
    cfg_t c;
    int duty = 0;
    int light_on = 0;
    uint8_t olat = 0xFF;
    int i;
    const char *fault = "";

    if (s_mu) xSemaphoreTake(s_mu, portMAX_DELAY);
    c = s_cfg;
    if (s_mu) xSemaphoreGive(s_mu);

    if (c.light == 1) light_on = 1;
    else if (c.light == 2 && s_lux >= 0) {
        if (s_lamp) {
            if (s_lux > c.lux_off) s_lamp = 0;
        } else if (s_lux < c.lux_on) {
            s_lamp = 1;
        }
        light_on = s_lamp;
    } else {
        s_lamp = 0;
    }

    {
        int64_t age = (esp_timer_get_time() / 1000) - s_seat_ms;
        int stale = s_seat_ms == 0 || age > SEAT_STALE_MS;
        if (!s_seat_ok || stale) {
            duty = 0;
            s_pid_i = 0;
            s_pid_out = 0;
            fault = "seat";
        } else if (s_seat >= c.seat_max || (s_seat_rate > 0 && s_seat_pred >= c.seat_max)) {
            duty = 0;
            s_pid_i = 0;
            s_pid_out = 0;
            fault = "hot";
        } else {
            int cold = s_bme_ok && s_amb != NO_TEMP && s_amb < c.amb_on;
            int use_auto = c.heat_mode == 1 || cold;
            if (!c.heat && !cold) {
                duty = 0;
                s_pid_i = 0;
                s_pid_out = 0;
            } else if (!use_auto) {
                duty = c.manual_duty;
            } else if (!cold && s_bme_ok && s_amb != NO_TEMP && s_amb >= c.comfort) {
                duty = 0;
                s_pid_i = 0;
                s_pid_out = 0;
            } else if (s_ina_ok && s_ima > c.amp_lim) {
                duty = 0;
                fault = "amp";
            } else {
                duty = s_pid_out;   /* updated by seat_task on every sample */
            }
        }
        if (duty > c.duty_max) duty = c.duty_max;   /* this limit was never applied before */
        if (duty > 100) duty = 100;
        if (duty < 0) duty = 0;
    }
    pwm_set(duty);

    if (light_on) olat = (uint8_t)(olat & (uint8_t)~(1u << 0));
    for (i = 1; i < 8; ++i) {
        if (k_rel_gpio[i] < 0) continue;
        if (c.rel & (1u << i)) olat = (uint8_t)(olat & (uint8_t)~(1u << i));
    }
    {
        cube_state_snapshot_t st;
        int hv;
        app_state_snapshot(&st);
        hv = st.relay_a && !st.relay_b;
        if (hv && s_zvs_mv > CUBE_ZVS_CUT_MV && s_zvs_mv < 700000) {
            if (s_zvs_hi_ms < 100000) s_zvs_hi_ms += 40;
        } else {
            s_zvs_hi_ms = 0;
        }
        if (hv && s_zvs_hi_ms >= 3000) {
            sm_hv_lockout(1);
            fault = "zvs";
        } else if (hv && station_pushing()) {
            sm_hv_lockout(1);
            fault = "pile";
        }
    }
    rel_apply(olat);
    fault_set(fault);
}

static void heat_timer(void);

static void cabin_task(void *arg)
{
    (void)arg;
    for (;;) {
        s_i2c_ticks++;
        if (!s_bme_ok && (s_i2c_ticks % 25) == 0) bme_bind();
        bme_read();
        bh_read();
        ina_read();
        adc_read();
        heat_timer();
        apply_out();
        vTaskDelay(pdMS_TO_TICKS(40));
    }
}

static void lock(void)
{
    if (s_mu) xSemaphoreTake(s_mu, portMAX_DELAY);
}

static void unlock_save(void)
{
    cfg_t c = s_cfg;
    if (s_mu) xSemaphoreGive(s_mu);
    (void)c;
    cfg_save();
}

void cabin_start(void)
{
    i2c_config_t bus = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = CUBE_CABIN_SDA_GPIO,
        .scl_io_num = CUBE_CABIN_SCL_GPIO,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = 100000,
        .clk_flags = 0,
    };
    s_mu = xSemaphoreCreateMutex();
    cfg_load();
    ow_init();
    pwm_bind();
    pwm_set(0);
    adc_bind();
    rel_gpio_init();
    rel_apply(0xFF);
    if (i2c_param_config(I2C_PORT, &bus) == ESP_OK &&
        i2c_driver_install(I2C_PORT, I2C_MODE_MASTER, 0, 0, 0) == ESP_OK) {
        bme_bind();
        bh_bind();
        ina_bind();
    } else {
        ESP_LOGW(TAG, "I2C install failed");
    }
    s_ready = 1;
    ESP_LOGW(TAG, "cabin SDA %d SCL %d seat %d heat %d zvs %d",
             CUBE_CABIN_SDA_GPIO, CUBE_CABIN_SCL_GPIO, CUBE_SEAT_OW_GPIO,
             CUBE_HEAT_PWM_GPIO, CUBE_ZVS_ADC_GPIO);
    if (xTaskCreatePinnedToCore(seat_task, "seat", 4096, NULL, 6, NULL, 1) != pdPASS) {
        ESP_LOGE(TAG, "seat task failed");
    }
    if (xTaskCreate(cabin_task, "cabin", 6144, NULL, 5, NULL) != pdPASS) {
        ESP_LOGE(TAG, "cabin task failed");
    }
}

int cabin_json(char *out, size_t cap)
{
    cfg_t c;
    int amb, seat, lux, ima, zvs, duty;
    int bme, bh, ina, seat_ok, mcp, zok;
    unsigned rel;
    char fault[8];
    if (!out || cap < 64) return -1;
    if (!s_ready) {
        return snprintf(out, cap, "{\"ok\":0}");
    }
    lock();
    c = s_cfg;
    amb = s_amb;
    seat = s_seat;
    lux = s_lux;
    ima = s_ima;
    zvs = s_zvs_mv;
    duty = s_duty;
    bme = s_bme_ok && amb != NO_TEMP;
    bh = s_bh_ok && lux >= 0;
    ina = s_ina_ok;
    seat_ok = s_seat_ok;
    mcp = s_mcp_ok;
    zok = s_zvs_ok;
    rel = s_rel_now;
    snprintf(fault, sizeof(fault), "%s", s_fault);
    if (s_mu) xSemaphoreGive(s_mu);
    return snprintf(out, cap,
        "{\"ok\":1,\"mcp\":%d,\"bme\":%d,\"bh\":%d,\"ina\":%d,\"seat_ok\":%d,\"zvs_ok\":%d,"
        "\"amb\":%d,\"seat\":%d,\"lux\":%d,\"ima\":%d,\"zvs_mv\":%d,\"duty\":%d,"
        "\"heat\":%d,\"light\":%d,\"comfort\":%d,\"seat_max\":%d,\"amp_lim\":%d,"
        "\"lux_on\":%d,\"lux_off\":%d,\"duty_max\":%d,\"mode\":%d,\"manual\":%d,\"amb_on\":%d,"
        "\"rel\":%u,\"fault\":\"%s\",\"seat_rate\":%d,\"seat_age\":%d,\"seat_sps\":%d,\"auto_off\":%d,\"heat_left\":%d}",
        mcp, bme, bh, ina, seat_ok, zok,
        amb, seat_ok ? seat : NO_TEMP, bh ? lux : -1, ina ? ima : 0, zok ? zvs : 0, duty,
        c.heat, c.light, c.comfort, c.seat_max, c.amp_lim,
        c.lux_on, c.lux_off, c.duty_max, c.heat_mode, c.manual_duty, c.amb_on, rel, fault,
        seat_ok ? s_seat_rate : 0,
        seat_ok && s_seat_ms ? (int)((esp_timer_get_time() / 1000) - s_seat_ms) : -1,
        s_seat_dt_ms > 0 ? 10000 / s_seat_dt_ms : 0,
        s_auto_off_min, s_heat_left);
}

static void c100_text(char *b, size_t n, int v)
{
    int neg;
    int a;
    if (v == NO_TEMP) {
        snprintf(b, n, "--");
        return;
    }
    neg = v < 0;
    a = neg ? -v : v;
    snprintf(b, n, "%s%d.%02d", neg ? "-" : "", a / 100, a % 100);
}

void cabin_lcd(char *out, size_t cap)
{
    char amb[16];
    char seat[16];
    const char *light;
    cfg_t c;
    if (!out || cap < 8) return;
    if (!s_ready) {
        snprintf(out, cap, "кабина ещё не встала");
        return;
    }
    lock();
    c = s_cfg;
    c100_text(amb, sizeof(amb), s_bme_ok ? s_amb : NO_TEMP);
    c100_text(seat, sizeof(seat), s_seat_ok ? s_seat : NO_TEMP);
    if (s_mu) xSemaphoreGive(s_mu);
    light = c.light == 1 ? "вкл" : (c.light == 2 ? "авто" : "выкл");
    snprintf(out, cap, "улица %s  сиденье %s\nподогрев %d%%  свет %s\nкомфорт %d",
             amb, seat, s_duty, light, c.comfort / 100);
}

static void auto_off_load(void)
{
    nvs_handle_t h;
    uint8_t v = 0;
    if (nvs_open("cabin", NVS_READONLY, &h) != ESP_OK) return;
    if (nvs_get_u8(h, "autooff", &v) == ESP_OK && v <= 240) s_auto_off_min = v;
    nvs_close(h);
}

void cabin_set_auto_off(int min)
{
    nvs_handle_t h;
    if (min < 0) min = 0;
    if (min > 240) min = 240;
    s_auto_off_min = min;
    s_heat_t0 = 0;                       /* count again from now */
    if (nvs_open("cabin", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u8(h, "autooff", (uint8_t)min);
    nvs_commit(h);
    nvs_close(h);
}

/* Called from the cabin task. The heater switch must not stay on for hours
 * because somebody forgot it. Cold-weather auto heating is not affected. */
static void heat_timer(void)
{
    int64_t now = esp_timer_get_time() / 1000;
    int on;
    lock();
    on = s_cfg.heat;
    if (s_mu) xSemaphoreGive(s_mu);
    if (!on) {
        s_heat_t0 = 0;
        s_heat_left = -1;
        return;
    }
    if (s_heat_t0 == 0) s_heat_t0 = now;
    if (s_auto_off_min <= 0) {
        s_heat_left = -1;
        return;
    }
    {
        int64_t left = (int64_t)s_auto_off_min * 60000 - (now - s_heat_t0);
        if (left <= 0) {
            lock();
            s_cfg.heat = 0;
            unlock_save();
            s_heat_t0 = 0;
            s_heat_left = -1;
            ESP_LOGW(TAG, "heater switch off by the timer (%d min)", s_auto_off_min);
        } else {
            s_heat_left = (int)((left + 59999) / 60000);
        }
    }
}

void cabin_view(cabin_view_t *v)
{
    cfg_t c;
    if (!v) return;
    memset(v, 0, sizeof(*v));
    v->seat = CABIN_NO_TEMP;
    v->amb = CABIN_NO_TEMP;
    v->lux = -1;
    if (!s_ready) return;
    lock();
    c = s_cfg;
    v->amb = (s_bme_ok && s_amb != NO_TEMP) ? s_amb : CABIN_NO_TEMP;
    v->seat = s_seat_ok ? s_seat : CABIN_NO_TEMP;
    v->lux = (s_bh_ok && s_lux >= 0) ? s_lux : -1;
    v->duty = s_duty;
    snprintf(v->fault, sizeof(v->fault), "%s", s_fault);
    if (s_mu) xSemaphoreGive(s_mu);
    v->heat = c.heat;
    v->heat_mode = c.heat_mode;
    v->comfort = c.comfort;
    v->seat_max = c.seat_max;
    v->light = c.light;
    v->rate = s_seat_ok ? s_seat_rate : 0;
    v->heat_left = s_heat_left;
    v->auto_off = s_auto_off_min;
}

void cabin_set_heat(int on)
{
    lock();
    s_cfg.heat = on ? 1 : 0;
    unlock_save();
}

void cabin_toggle_heat(void)
{
    lock();
    s_cfg.heat = s_cfg.heat ? 0 : 1;
    unlock_save();
}

void cabin_set_light(int mode)
{
    if (mode < 0) mode = 0;
    if (mode > 2) mode = 2;
    lock();
    s_cfg.light = (uint8_t)mode;
    unlock_save();
}

void cabin_cycle_light(void)
{
    lock();
    s_cfg.light = (uint8_t)((s_cfg.light + 1) % 3);
    unlock_save();
}

void cabin_set_comfort_c(int c)
{
    if (c < 0) c = 0;
    if (c > 120) c = 120;
    lock();
    s_cfg.comfort = (int16_t)(c * 100);
    unlock_save();
}

void cabin_bump_comfort(int delta_c)
{
    int c;
    lock();
    c = s_cfg.comfort / 100 + delta_c;
    if (c < 0) c = 0;
    if (c > 120) c = 120;
    s_cfg.comfort = (int16_t)(c * 100);
    unlock_save();
}

void cabin_set_seat_max_c(int c)
{
    if (c < 20) c = 20;
    if (c > 140) c = 140;
    lock();
    s_cfg.seat_max = (int16_t)(c * 100);
    unlock_save();
}

void cabin_set_amp_lim_a(int a)
{
    if (a < 1) a = 1;
    if (a > 20) a = 20;
    lock();
    s_cfg.amp_lim = (int16_t)(a * 1000);
    unlock_save();
}

void cabin_set_duty_max(int pct)
{
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;
    lock();
    s_cfg.duty_max = (uint8_t)pct;
    unlock_save();
}

void cabin_set_heat_mode(int mode)
{
    lock();
    s_cfg.heat_mode = mode ? 1 : 0;
    unlock_save();
}

void cabin_set_manual_duty(int pct)
{
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;
    lock();
    s_cfg.manual_duty = (uint8_t)pct;
    unlock_save();
}

void cabin_set_amb_on_c(int c)
{
    if (c < -40) c = -40;
    if (c > 70) c = 70;
    lock();
    s_cfg.amb_on = (int16_t)(c * 100);
    unlock_save();
}

void cabin_set_lux(int on_lux, int off_lux)
{
    if (on_lux < 0) on_lux = 0;
    if (on_lux > 2000) on_lux = 2000;
    if (off_lux < on_lux + 10) off_lux = on_lux + 10;
    if (off_lux > 5000) off_lux = 5000;
    lock();
    s_cfg.lux_on = (int16_t)on_lux;
    s_cfg.lux_off = (int16_t)off_lux;
    unlock_save();
}

void cabin_set_zvs(int on)
{
    sm_user_relay(6, on);
}

void cabin_set_relay(int channel, int on)
{
    if (channel != 2 && channel != 3 && channel != 4) return;
    lock();
    if (on) s_cfg.rel = (uint8_t)(s_cfg.rel | (uint8_t)(1u << channel));
    else s_cfg.rel = (uint8_t)(s_cfg.rel & (uint8_t)~(1u << channel));
    unlock_save();
}
