#pragma once

#include "esp_err.h"
#include <stdbool.h>
#include "lvgl.h"

esp_err_t touch_init(void);
esp_err_t touch_attach_spi(void);
bool touch_is_available(void);
void touch_lvgl_read(lv_indev_drv_t *drv, lv_indev_data_t *data);
void touch_set_gate(int z);
int touch_get_gate(void);
int touch_last_z(void);
int touch_irq_low(void);
