#pragma once
#include <stddef.h>
#include <stdint.h>

void fardriver_uart_start(void);
void fardriver_uart_arm(void);
void fardriver_uart_write(const uint8_t *data, size_t len);
void fardriver_speed_text(char *out, size_t cap);
void fardriver_set_diameter_tenths(int tenths);
int fardriver_diameter_tenths(void);
void fardriver_set_direct(int on);
int fardriver_direct(void);
void fardriver_stats(int *rpm, int *kmh_x10, int *link, int *max_rpm);
void fardriver_power(int *amps_x10, int *max_amps_x10, int *volts_x10, int *err_bits);
