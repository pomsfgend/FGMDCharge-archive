#include "ble.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "esp_log.h"
#include "esp_bt.h"
#include "esp_bt_device.h"
#include "esp_bt_main.h"
#include "esp_gap_ble_api.h"
#include "esp_gatts_api.h"
#include "esp_gatt_common_api.h"
#include "app_state.h"
#include "config.h"
#include "settings.h"
#include "fardriver_uart.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#if !defined(CONFIG_BT_BLUEDROID_ENABLED) || !CONFIG_BT_BLUEDROID_ENABLED
#error "FD_ROUND V2 BLE requires CONFIG_BT_BLUEDROID_ENABLED=y"
#endif

static const char *TAG = "BLE";
static uint16_t s_service_handle;
static uint16_t s_attr_handles[8];
static esp_gatt_if_t s_gatts_if = ESP_GATT_IF_NONE;
static uint16_t s_conn_id = 0xFFFF;
static uint16_t s_mtu = 23;
static bool s_notify_ffec;
static bool s_notify_ffe1;
static bool s_adv_ready;
static bool s_initialized;
static char s_ble_name[32] = CUBE_BLE_NAME;

/* GAP APIs consume these structures asynchronously, so keep them static. */
static esp_ble_adv_data_t s_adv_data;
static uint16_t s_primary_service_decl_uuid = ESP_GATT_UUID_PRI_SERVICE;
static uint16_t s_ffec_uuid = 0xFFEC;
static uint16_t s_ffe1_uuid = 0xFFE1;
static uint16_t s_char_decl_uuid = ESP_GATT_UUID_CHAR_DECLARE;
static uint16_t s_cccd_uuid = ESP_GATT_UUID_CHAR_CLIENT_CONFIG;
static uint16_t s_service_uuid = CUBE_BLE_SERVICE_UUID;
static uint8_t s_ffec_value[20];
static uint8_t s_ffe1_value[20];
static uint8_t s_cccd_ffec[2];
static uint8_t s_cccd_ffe1[2];
static const uint8_t s_char_prop = ESP_GATT_CHAR_PROP_BIT_READ |
                                   ESP_GATT_CHAR_PROP_BIT_WRITE |
                                   ESP_GATT_CHAR_PROP_BIT_WRITE_NR |
                                   ESP_GATT_CHAR_PROP_BIT_NOTIFY |
                                   ESP_GATT_CHAR_PROP_BIT_INDICATE;

static const esp_gatts_attr_db_t gatt_db[7] = {
    [0] = {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&s_primary_service_decl_uuid,
            ESP_GATT_PERM_READ, sizeof(uint16_t), sizeof(s_service_uuid),
            (uint8_t *)&s_service_uuid}},
    [1] = {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&s_char_decl_uuid,
            ESP_GATT_PERM_READ, sizeof(uint8_t), sizeof(s_char_prop),
            (uint8_t *)&s_char_prop}},
    [2] = {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&s_ffec_uuid,
            ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE, 512, sizeof(s_ffec_value),
            s_ffec_value}},
    [3] = {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&s_cccd_uuid,
            ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE, sizeof(s_cccd_ffec), sizeof(s_cccd_ffec),
            s_cccd_ffec}},
    [4] = {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&s_char_decl_uuid,
            ESP_GATT_PERM_READ, sizeof(uint8_t), sizeof(s_char_prop),
            (uint8_t *)&s_char_prop}},
    [5] = {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&s_ffe1_uuid,
            ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE, 512, sizeof(s_ffe1_value),
            s_ffe1_value}},
    [6] = {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&s_cccd_uuid,
            ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE, sizeof(s_cccd_ffe1), sizeof(s_cccd_ffe1),
            s_cccd_ffe1}},
};

static const uint8_t s_raw_adv[] = {
    0x02, 0x01, 0x06,
    0x03, 0x03, 0xE0, 0xFF,
    0x0A, 0x09, 'F', 'a', 'r', 'D', 'r', 'i', 'v', 'e', 'r',
};
static const uint8_t s_raw_scan[] = {
    0x0A, 0x09, 'F', 'a', 'r', 'D', 'r', 'i', 'v', 'e', 'r',
};

static esp_ble_adv_params_t s_adv_params = {
    .adv_int_min = 0x20,
    .adv_int_max = 0x40,
    .adv_type = ADV_TYPE_IND,
    .own_addr_type = BLE_ADDR_TYPE_PUBLIC,
    .channel_map = ADV_CHNL_ALL,
    .adv_filter_policy = ADV_FILTER_ALLOW_SCAN_ANY_CON_ANY,
};

static void on_write(uint16_t handle, const uint8_t *data, uint16_t len) {
    if (!data || len == 0) return;
    app_state_set_ble_rx(data, len);
    ESP_LOGI(TAG, "RX handle=%u len=%u", (unsigned)handle, (unsigned)len);
    if (!fardriver_direct()) return;
    fardriver_uart_write(data, len);
}

static void gap_cb(esp_gap_ble_cb_event_t event, esp_ble_gap_cb_param_t *param) {
    switch (event) {
        case ESP_GAP_BLE_ADV_DATA_SET_COMPLETE_EVT:
        case ESP_GAP_BLE_ADV_DATA_RAW_SET_COMPLETE_EVT: {
            s_adv_ready = true;
            esp_err_t err = esp_ble_gap_start_advertising(&s_adv_params);
            if (err != ESP_OK) ESP_LOGE(TAG, "start advertising failed: %s", esp_err_to_name(err));
            break;
        }
        case ESP_GAP_BLE_ADV_START_COMPLETE_EVT:
            if (param->adv_start_cmpl.status != ESP_BT_STATUS_SUCCESS) {
                ESP_LOGE(TAG, "advertising start failed status=%d", param->adv_start_cmpl.status);
            } else {
                ESP_LOGI(TAG, "advertising started");
            }
            break;
        case ESP_GAP_BLE_SEC_REQ_EVT:
            /* Worthless Control calls the dongle and may start Just Works.
             * Refusing here is what dropped the link (rsn 0x13 / 0x16). */
            esp_ble_gap_security_rsp(param->ble_security.ble_req.bd_addr, true);
            ESP_LOGW(TAG, "pairing accepted just-works");
            break;
        case ESP_GAP_BLE_AUTH_CMPL_EVT:
            if (param->ble_security.auth_cmpl.success) {
                ESP_LOGW(TAG, "pairing complete");
            } else {
                ESP_LOGW(TAG, "pairing result fail reason=0x%x",
                         param->ble_security.auth_cmpl.fail_reason);
            }
            break;
        default:
            break;
    }
}

static void gatts_cb(esp_gatts_cb_event_t event, esp_gatt_if_t gatts_if,
                     esp_ble_gatts_cb_param_t *param) {
    switch (event) {
        case ESP_GATTS_REG_EVT: {
            s_gatts_if = gatts_if;
            esp_err_t err = esp_ble_gap_set_device_name(s_ble_name);
            if (err != ESP_OK) {
                ESP_LOGE(TAG, "set BLE name failed: %s", esp_err_to_name(err));
                break;
            }

            err = esp_ble_gap_config_adv_data_raw((uint8_t *)s_raw_adv, sizeof(s_raw_adv));
            if (err != ESP_OK) {
                ESP_LOGE(TAG, "raw advertising failed: %s", esp_err_to_name(err));
                break;
            }
            err = esp_ble_gap_config_scan_rsp_data_raw((uint8_t *)s_raw_scan, sizeof(s_raw_scan));
            if (err != ESP_OK) {
                ESP_LOGW(TAG, "scan response failed: %s", esp_err_to_name(err));
            }
            err = esp_ble_gatts_create_attr_tab(gatt_db, gatts_if, 7, 0);
            if (err != ESP_OK) {
                ESP_LOGE(TAG, "create GATT table request failed: %s", esp_err_to_name(err));
            }
            break;
        }
        case ESP_GATTS_CREAT_ATTR_TAB_EVT:
            if (param->add_attr_tab.status == ESP_GATT_OK && param->add_attr_tab.num_handle == 7) {
                memcpy(s_attr_handles, param->add_attr_tab.handles, 7 * sizeof(uint16_t));
                s_service_handle = s_attr_handles[0];
                esp_err_t err = esp_ble_gatts_start_service(s_service_handle);
                if (err != ESP_OK) {
                    ESP_LOGE(TAG, "start GATT service failed: %s", esp_err_to_name(err));
                } else {
                    ESP_LOGI(TAG, "GATT service started, base handle=%u", (unsigned)s_service_handle);
                }
            } else {
                ESP_LOGE(TAG, "create attr table failed status=%d num=%d",
                         param->add_attr_tab.status, param->add_attr_tab.num_handle);
            }
            break;
        case ESP_GATTS_CONNECT_EVT:
            s_conn_id = param->connect.conn_id;
            s_mtu = 23;
            app_state_set_ble(true);
            ESP_LOGW(TAG, "phone connected");
            break;
        case ESP_GATTS_DISCONNECT_EVT:
            s_conn_id = 0xFFFF;
            s_notify_ffec = false;
            s_notify_ffe1 = false;
            app_state_set_ble(false);
            app_state_set_ble_cccd(false, false);
            ESP_LOGW(TAG, "phone gone reason=0x%02x", param->disconnect.reason);
            if (s_adv_ready) {
                esp_err_t err = esp_ble_gap_start_advertising(&s_adv_params);
                if (err != ESP_OK) ESP_LOGW(TAG, "restart advertising failed: %s", esp_err_to_name(err));
            }
            break;
        case ESP_GATTS_MTU_EVT:
            s_mtu = param->mtu.mtu;
            ESP_LOGW(TAG, "MTU %u", (unsigned)s_mtu);
            break;
        case ESP_GATTS_WRITE_EVT:
            if (!param->write.is_prep && param->write.len == 2 &&
                (param->write.handle == s_attr_handles[3] || param->write.handle == s_attr_handles[6])) {
                uint16_t v = (uint16_t)param->write.value[0] |
                             ((uint16_t)param->write.value[1] << 8);
                bool notify = (v & 0x0001U) != 0;
                if (param->write.handle == s_attr_handles[3]) s_notify_ffec = notify;
                else s_notify_ffe1 = notify;
                app_state_set_ble_cccd(s_notify_ffec || s_notify_ffe1, (v & 0x0002U) != 0);
                ESP_LOGI(TAG, "CCCD ffec=%d ffe1=%d", s_notify_ffec, s_notify_ffe1);
            } else if (!param->write.is_prep) {
                on_write(param->write.handle, param->write.value, param->write.len);
            }
            break;
        default:
            break;
    }
}

esp_err_t cube_ble_init(void) {
    if (s_initialized) return ESP_OK;

    esp_err_t err = esp_bt_controller_mem_release(ESP_BT_MODE_CLASSIC_BT);
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
        ESP_LOGW(TAG, "release classic BT memory: %s", esp_err_to_name(err));
    }

    esp_bt_controller_config_t bt_cfg = BT_CONTROLLER_INIT_CONFIG_DEFAULT();
    err = esp_bt_controller_init(&bt_cfg);
    if (err != ESP_OK) return err;

    err = esp_bt_controller_enable(ESP_BT_MODE_BLE);
    if (err != ESP_OK) goto fail_controller;

    (void)settings_get_ble_name(s_ble_name, sizeof(s_ble_name));

    err = esp_bluedroid_init();
    if (err != ESP_OK) goto fail_controller_enabled;

    err = esp_bluedroid_enable();
    if (err != ESP_OK) goto fail_bluedroid;

    err = esp_ble_gap_register_callback(gap_cb);
    if (err != ESP_OK) goto fail_bluedroid_enabled;

    err = esp_ble_gatts_register_callback(gatts_cb);
    if (err != ESP_OK) goto fail_bluedroid_enabled;

    err = esp_ble_gatts_app_register(0x55);
    if (err != ESP_OK) goto fail_bluedroid_enabled;

    /* Just Works. The dongle does not ask for a code. Accept the phone's
     * request so the link stays up; refusing was the immediate app error. */
    esp_ble_auth_req_t auth = ESP_LE_AUTH_NO_BOND;
    esp_ble_io_cap_t iocap = ESP_IO_CAP_NONE;
    uint8_t key_size = 16;
    uint8_t init_key = ESP_BLE_ENC_KEY_MASK | ESP_BLE_ID_KEY_MASK;
    uint8_t rsp_key = ESP_BLE_ENC_KEY_MASK | ESP_BLE_ID_KEY_MASK;
    (void)esp_ble_gap_set_security_param(ESP_BLE_SM_AUTHEN_REQ_MODE, &auth, sizeof(auth));
    (void)esp_ble_gap_set_security_param(ESP_BLE_SM_IOCAP_MODE, &iocap, sizeof(iocap));
    (void)esp_ble_gap_set_security_param(ESP_BLE_SM_MAX_KEY_SIZE, &key_size, sizeof(key_size));
    (void)esp_ble_gap_set_security_param(ESP_BLE_SM_SET_INIT_KEY, &init_key, sizeof(init_key));
    (void)esp_ble_gap_set_security_param(ESP_BLE_SM_SET_RSP_KEY, &rsp_key, sizeof(rsp_key));
    (void)esp_ble_gatt_set_local_mtu(247);

    s_initialized = true;
    ESP_LOGI(TAG, "BLE initialized: name=%s service=0xFFE0 char=0xFFEC", s_ble_name);
    return ESP_OK;

fail_bluedroid_enabled:
    (void)esp_bluedroid_disable();
fail_bluedroid:
    (void)esp_bluedroid_deinit();
fail_controller_enabled:
    (void)esp_bt_controller_disable();
fail_controller:
    (void)esp_bt_controller_deinit();
    return err;
}

esp_err_t cube_ble_send_status(const char *text) {
    if (!text || s_conn_id == 0xFFFF || s_gatts_if == ESP_GATT_IF_NONE || s_attr_handles[2] == 0) {
        return ESP_ERR_INVALID_STATE;
    }
    if (!s_notify_ffec && !s_notify_ffe1) return ESP_ERR_INVALID_STATE;

    size_t n = strlen(text);
    if (n > 20) n = 20;
    uint16_t handle = s_notify_ffec ? s_attr_handles[2] : s_attr_handles[5];
    return esp_ble_gatts_send_indicate(s_gatts_if, s_conn_id, handle,
                                       (uint16_t)n, (uint8_t *)text, false);
}

bool cube_ble_is_connected(void) { return s_conn_id != 0xFFFF; }

esp_err_t cube_ble_rearm(void)
{
    esp_err_t err;
    if (!s_initialized) return cube_ble_init();
    (void)esp_ble_gap_stop_advertising();
    err = esp_ble_gap_start_advertising(&s_adv_params);
    ESP_LOGW(TAG, "rearm %s", esp_err_to_name(err));
    return err;
}

esp_err_t cube_ble_notify(const uint8_t *data, uint16_t len)
{
    uint16_t maxp;
    uint16_t off = 0;
    if (!data || len == 0 || s_conn_id == 0xFFFF || s_gatts_if == ESP_GATT_IF_NONE) {
        return ESP_ERR_INVALID_STATE;
    }
    if (!s_notify_ffec && !s_notify_ffe1) return ESP_ERR_INVALID_STATE;
    maxp = s_mtu > 3 ? (uint16_t)(s_mtu - 3) : 20;
    if (maxp > 240) maxp = 240;
    while (off < len) {
        uint16_t n = (uint16_t)(len - off);
        esp_err_t err;
        if (n > maxp) n = maxp;
        if (s_notify_ffec) {
            err = esp_ble_gatts_send_indicate(s_gatts_if, s_conn_id, s_attr_handles[2],
                                              n, (uint8_t *)data + off, false);
            if (err != ESP_OK) return err;
        }
        if (s_notify_ffe1) {
            err = esp_ble_gatts_send_indicate(s_gatts_if, s_conn_id, s_attr_handles[5],
                                              n, (uint8_t *)data + off, false);
            if (err != ESP_OK) return err;
        }
        off = (uint16_t)(off + n);
    }
    return ESP_OK;
}

void cube_ble_task(void *arg)
{
    (void)arg;
    for (;;) vTaskDelay(pdMS_TO_TICKS(1000));
}
