#include "ui_dash.h"

#include "app_state.h"
#include "ble.h"
#include "can_gbt.h"
#include "config.h"
#include "bms_uart.h"
#include "display.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "fardriver_uart.h"
#include "sm_relay.h"
#include "touch_cst816s.h"
#include "web.h"
#include <stdio.h>
#include <string.h>

extern const lv_font_t lv_font_ru_14;
extern const lv_font_t lv_font_montserrat_28;

static lv_obj_t *s_page[5];
static lv_obj_t *s_nav[5];
static lv_obj_t *s_time;
static lv_obj_t *s_relay;
static lv_obj_t *s_proto;
static lv_obj_t *s_can_line;
static lv_obj_t *s_req_v;
static lv_obj_t *s_req_a;
static lv_obj_t *s_watt;
static lv_obj_t *s_out_v;
static lv_obj_t *s_out_a;
static int s_pack;
static lv_obj_t *s_bms_tab[2];
static lv_obj_t *s_bms_info;
static lv_obj_t *s_cell_box[18];
static lv_obj_t *s_cell_lbl[18];
static lv_obj_t *s_fd_link;
static lv_obj_t *s_fd_i;
static lv_obj_t *s_fd_imax;
static lv_obj_t *s_fd_v;
static lv_obj_t *s_fd_err;
static lv_obj_t *s_fd_rpm;
static lv_obj_t *s_fd_kmh;
static lv_obj_t *s_direct_lbl;
static lv_obj_t *s_msg;
static lv_obj_t *s_ssid;
static lv_obj_t *s_ap_pass;
static lv_obj_t *s_sta_pass;
static lv_obj_t *s_net[4];
static int s_net_i = -1;
static lv_obj_t *s_kb;
static lv_obj_t *s_touch_lbl;
static lv_obj_t *s_diam_lbl;
static int s_ap_filled;

static lv_obj_t *caption(lv_obj_t *p, const char *t, int y)
{
    lv_obj_t *l = lv_label_create(p);
    lv_label_set_text(l, t);
    lv_obj_set_style_text_font(l, &lv_font_ru_14, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(0xE8EEF4), 0);
    lv_obj_set_pos(l, 6, y);
    return l;
}

static lv_obj_t *btn(lv_obj_t *p, int x, int y, int w, int h, const char *t, lv_event_cb_t cb, void *ud)
{
    lv_obj_t *b = lv_btn_create(p);
    lv_obj_t *l;
    lv_obj_set_pos(b, x, y);
    lv_obj_set_size(b, w, h);
    lv_obj_set_style_bg_color(b, lv_color_hex(0x1F6F5B), 0);
    lv_obj_set_style_radius(b, 6, 0);
    lv_obj_set_style_shadow_width(b, 0, 0);
    lv_obj_set_style_pad_all(b, 0, 0);
    if (cb) lv_obj_add_event_cb(b, cb, LV_EVENT_CLICKED, ud);
    l = lv_label_create(b);
    lv_label_set_text(l, t);
    lv_obj_set_style_text_font(l, &lv_font_ru_14, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(0xF4F7FB), 0);
    lv_obj_center(l);
    return b;
}

static void show_page(int n)
{
    int i;
    if (n < 0) n = 0;
    if (n > 4) n = 4;
    for (i = 0; i < 5; ++i) {
        if (!s_page[i] || !s_nav[i]) continue;
        if (i == n) lv_obj_clear_flag(s_page[i], LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(s_page[i], LV_OBJ_FLAG_HIDDEN);
        lv_obj_set_style_bg_color(s_nav[i], lv_color_hex(i == n ? 0x1F6F5B : 0x12202A), 0);
    }
    if (s_kb) lv_obj_add_flag(s_kb, LV_OBJ_FLAG_HIDDEN);
}

static void nav_cb(lv_event_t *e)
{
    show_page((int)(intptr_t)lv_event_get_user_data(e));
}

static void relay_cb(lv_event_t *e)
{
    (void)e;
    sm_request_relay_test();
}

static void key_cb(lv_event_t *e)
{
    display_open_keypad((int)(intptr_t)lv_event_get_user_data(e));
}

static void pack_cb(lv_event_t *e)
{
    s_pack = (int)(intptr_t)lv_event_get_user_data(e);
    if (s_pack < 0) s_pack = 0;
    if (s_pack > 1) s_pack = 1;
}

static void proto_cb(lv_event_t *e)
{
    app_state_set_protocol((uint8_t)(intptr_t)lv_event_get_user_data(e));
}

static void direct_cb(lv_event_t *e)
{
    int on = lv_obj_has_state(lv_event_get_target(e), LV_STATE_CHECKED);
    fardriver_set_direct(on);
}

static void note(const char *t)
{
    if (s_msg) lv_label_set_text(s_msg, t);
}

static void act_cb(lv_event_t *e)
{
    int id = (int)(intptr_t)lv_event_get_user_data(e);
    if (id == 1) {
        note(web_wifi_restart() == ESP_OK ? "Wi-Fi перезапущен" : "Wi-Fi не поднялся");
    } else if (id == 2) {
        note(cube_ble_rearm() == ESP_OK ? "BLE снова в эфире" : "BLE не перезапустился");
    } else if (id == 3) {
        note("перезагрузка");
        esp_restart();
    } else if (id == 4) {
        const char *ssid = s_ssid ? lv_textarea_get_text(s_ssid) : "";
        const char *pass = s_ap_pass ? lv_textarea_get_text(s_ap_pass) : "";
        note(web_set_ap(ssid, pass) == ESP_OK ? "точка сохранена" : "имя 1-32, пароль от 8");
    } else if (id == 5) {
        int n;
        int i;
        if (web_scan_now() != ESP_OK) {
            note("скан не удался");
            return;
        }
        n = web_scan_count();
        s_net_i = -1;
        for (i = 0; i < 4; ++i) {
            if (!s_net[i]) continue;
            if (i < n && web_scan_ssid(i)[0]) {
                lv_obj_t *l = lv_obj_get_child(s_net[i], 0);
                if (l) lv_label_set_text(l, web_scan_ssid(i));
                lv_obj_clear_flag(s_net[i], LV_OBJ_FLAG_HIDDEN);
            } else {
                lv_obj_add_flag(s_net[i], LV_OBJ_FLAG_HIDDEN);
            }
        }
        note(n ? "сеть выбрана кнопкой" : "сетей нет");
    } else if (id == 6) {
        const char *pass = s_sta_pass ? lv_textarea_get_text(s_sta_pass) : "";
        const char *ssid;
        if (s_net_i < 0 || s_net_i >= web_scan_count()) {
            note("сначала выбери сеть");
            return;
        }
        ssid = web_scan_ssid(s_net_i);
        note(web_sta_join(ssid, pass) == ESP_OK ? "подключаюсь" : "не подключился");
    } else if (id == 7) {
        sm_stop_session();
        note("сессия остановлена");
    } else if (id == 8 || id == 9) {
        int t = fardriver_diameter_tenths();
        t += (id == 8) ? -1 : 1;
        fardriver_set_diameter_tenths(t);
    }
}

static void net_cb(lv_event_t *e)
{
    s_net_i = (int)(intptr_t)lv_event_get_user_data(e);
    note(web_scan_ssid(s_net_i));
}

static void kb_hide_cb(lv_event_t *e)
{
    lv_event_code_t c = lv_event_get_code(e);
    if ((c == LV_EVENT_READY || c == LV_EVENT_CANCEL) && s_kb)
        lv_obj_add_flag(s_kb, LV_OBJ_FLAG_HIDDEN);
}

static void ta_cb(lv_event_t *e)
{
    if (!s_kb) return;
    lv_keyboard_set_textarea(s_kb, lv_event_get_target(e));
    lv_obj_clear_flag(s_kb, LV_OBJ_FLAG_HIDDEN);
    lv_obj_move_foreground(s_kb);
}

static void wire_cb(lv_event_t *e)
{
    gbt_can_wire_test();
    (void)e;
    if (s_can_line) lv_label_set_text(s_can_line, gbt_can_wire_result());
}

static void bus_cb(lv_event_t *e)
{
    (void)e;
    gbt_can_bus_test();
    if (s_can_line) lv_label_set_text(s_can_line, gbt_can_wire_result());
}

static void br_cb(lv_event_t *e)
{
    display_set_brightness(lv_slider_get_value(lv_event_get_target(e)));
}

static void gate_cb(lv_event_t *e)
{
    int z = lv_slider_get_value(lv_event_get_target(e));
    char b[40];
    touch_set_gate(z);
    if (s_touch_lbl) {
        snprintf(b, sizeof(b), "порог нажатия %d", z);
        lv_label_set_text(s_touch_lbl, b);
    }
}

static lv_obj_t *tile(lv_obj_t *p, int x, int y, int w, int h, uint32_t bg, uint32_t fg, const char *cap, lv_obj_t **value, const char *init, const lv_font_t *font)
{
    lv_obj_t *c = lv_obj_create(p);
    lv_obj_t *v;
    lv_obj_t *k;
    lv_obj_set_pos(c, x, y);
    lv_obj_set_size(c, w, h);
    lv_obj_set_style_bg_color(c, lv_color_hex(bg), 0);
    lv_obj_set_style_bg_opa(c, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(c, 8, 0);
    lv_obj_set_style_border_width(c, 0, 0);
    lv_obj_set_style_pad_all(c, 0, 0);
    lv_obj_clear_flag(c, LV_OBJ_FLAG_SCROLLABLE);
    v = lv_label_create(c);
    lv_label_set_text(v, init);
    lv_obj_set_style_text_font(v, font, 0);
    lv_obj_set_style_text_color(v, lv_color_hex(fg), 0);
    lv_obj_align(v, LV_ALIGN_CENTER, 0, -8);
    lv_obj_add_flag(v, LV_OBJ_FLAG_EVENT_BUBBLE);
    k = lv_label_create(c);
    lv_label_set_text(k, cap);
    lv_obj_set_style_text_font(k, &lv_font_ru_14, 0);
    lv_obj_set_style_text_color(k, lv_color_hex(bg == 0x101418 ? 0xE6C84A : 0xD6F4FF), 0);
    lv_obj_align(k, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_obj_add_flag(k, LV_OBJ_FLAG_EVENT_BUBBLE);
    if (value) *value = v;
    return c;
}

static lv_obj_t *field(lv_obj_t *p, int x, int y, int w, const char *init)
{
    lv_obj_t *t = lv_textarea_create(p);
    lv_obj_set_pos(t, x, y);
    lv_obj_set_size(t, w, 32);
    lv_textarea_set_one_line(t, true);
    lv_textarea_set_text(t, init);
    lv_obj_set_style_text_font(t, &lv_font_ru_14, 0);
    lv_obj_add_event_cb(t, ta_cb, LV_EVENT_FOCUSED, NULL);
    return t;
}

static void page_bg(lv_obj_t *p)
{
    lv_obj_set_style_bg_opa(p, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(p, 0, 0);
    lv_obj_set_style_pad_all(p, 0, 0);
    lv_obj_clear_flag(p, LV_OBJ_FLAG_SCROLLABLE);
}

void ui_dash_build(lv_obj_t *scr)
{
    int i;
    lv_obj_t *c;
    const char *nav[] = {"СТАН", "АКБ", "МОТОР", "КУБ", "ОТЛ"};

    for (i = 0; i < 5; ++i) {
        s_page[i] = lv_obj_create(scr);
        lv_obj_set_pos(s_page[i], 0, 0);
        lv_obj_set_size(s_page[i], 240, 284);
        page_bg(s_page[i]);
    }
    lv_obj_add_flag(s_page[2], LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_scroll_dir(s_page[2], LV_DIR_VER);
    lv_obj_add_flag(s_page[3], LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_scroll_dir(s_page[3], LV_DIR_VER);

    c = tile(s_page[0], 2, 2, 76, 78, 0x127E9A, 0xFFFFFF, "время", &s_time, "00:00:00", &lv_font_ru_14);
    (void)c;
    c = tile(s_page[0], 80, 2, 78, 78, 0x2AD4EA, 0x042428, "запрос В", &s_req_v, "240", &lv_font_montserrat_28);
    lv_obj_add_flag(c, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(c, key_cb, LV_EVENT_CLICKED, (void *)(intptr_t)3);
    c = tile(s_page[0], 160, 2, 78, 112, 0x101418, 0xFFFFFF, "выход В", &s_out_v, "0", &lv_font_montserrat_28);
    (void)c;
    c = tile(s_page[0], 2, 82, 76, 78, 0x127E9A, 0xFFFFFF, "выход", &s_relay, "OFF", &lv_font_montserrat_28);
    lv_obj_add_flag(c, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(c, relay_cb, LV_EVENT_CLICKED, NULL);
    c = tile(s_page[0], 80, 82, 78, 78, 0x2AD4EA, 0x042428, "запрос А", &s_req_a, "50", &lv_font_montserrat_28);
    lv_obj_add_flag(c, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(c, key_cb, LV_EVENT_CLICKED, (void *)(intptr_t)4);
    c = tile(s_page[0], 160, 116, 78, 112, 0x101418, 0xFFFFFF, "выход А", &s_out_a, "0", &lv_font_montserrat_28);
    (void)c;
    c = tile(s_page[0], 2, 162, 76, 66, 0x127E9A, 0xFFFFFF, "протокол", &s_proto, "авто", &lv_font_ru_14);
    (void)c;
    c = tile(s_page[0], 80, 162, 78, 66, 0x2AD4EA, 0x042428, "ватт", &s_watt, "0", &lv_font_montserrat_28);
    (void)c;
    s_can_line = caption(s_page[0], "пин 18 пустой, пока не нажато", 228);
    btn(s_page[0], 2, 248, 116, 32, "до модуля", wire_cb, NULL);
    btn(s_page[0], 122, 248, 116, 32, "кабель CAN", bus_cb, NULL);

    s_bms_tab[0] = btn(s_page[1], 6, 4, 110, 28, "АКБ 1", pack_cb, (void *)(intptr_t)0);
    s_bms_tab[1] = btn(s_page[1], 122, 4, 110, 28, "АКБ 2", pack_cb, (void *)(intptr_t)1);
    s_bms_info = caption(s_page[1], "нет связи", 36);
    lv_label_set_long_mode(s_bms_info, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(s_bms_info, 228);
    for (i = 0; i < 18; ++i) {
        int x = 4 + (i % 6) * 39;
        int y = 128 + (i / 6) * 36;
        lv_obj_t *l;
        s_cell_box[i] = lv_obj_create(s_page[1]);
        lv_obj_set_pos(s_cell_box[i], x, y);
        lv_obj_set_size(s_cell_box[i], 37, 34);
        lv_obj_set_style_bg_color(s_cell_box[i], lv_color_hex(0x12181C), 0);
        lv_obj_set_style_bg_opa(s_cell_box[i], LV_OPA_COVER, 0);
        lv_obj_set_style_radius(s_cell_box[i], 4, 0);
        lv_obj_set_style_border_width(s_cell_box[i], 0, 0);
        lv_obj_set_style_pad_all(s_cell_box[i], 0, 0);
        lv_obj_clear_flag(s_cell_box[i], LV_OBJ_FLAG_SCROLLABLE);
        l = lv_label_create(s_cell_box[i]);
        lv_label_set_text(l, "--");
        lv_obj_set_style_text_font(l, &lv_font_ru_14, 0);
        lv_obj_set_style_text_color(l, lv_color_hex(0xF4F7FB), 0);
        lv_obj_center(l);
        s_cell_lbl[i] = l;
    }

    s_fd_kmh = caption(s_page[2], "0.0 км/ч", 8);
    lv_obj_set_style_text_color(s_fd_kmh, lv_color_hex(0x7DFFB2), 0);
    s_fd_link = caption(s_page[2], "нет связи", 32);
    s_fd_i = caption(s_page[2], "ток 0.0 А", 56);
    s_fd_imax = caption(s_page[2], "макс ток сессии 0.0 А", 78);
    s_fd_v = caption(s_page[2], "напряжение 0.0 В", 100);
    s_fd_rpm = caption(s_page[2], "обороты 0", 122);
    s_fd_err = caption(s_page[2], "ошибки нет", 144);
    lv_label_set_long_mode(s_fd_err, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(s_fd_err, 228);
    caption(s_page[2], "колесо 16.3 дюйма, пока нет кадра — нули", 190);

    caption(s_page[3], "яркость", 4);
    {
        lv_obj_t *sl = lv_slider_create(s_page[3]);
        lv_obj_set_pos(sl, 8, 24);
        lv_obj_set_width(sl, 220);
        lv_slider_set_range(sl, 5, 100);
        lv_slider_set_value(sl, display_get_brightness(), LV_ANIM_OFF);
        lv_obj_add_event_cb(sl, br_cb, LV_EVENT_VALUE_CHANGED, NULL);
    }
    s_touch_lbl = caption(s_page[3], "порог нажатия 80", 48);
    {
        lv_obj_t *sl = lv_slider_create(s_page[3]);
        lv_obj_set_pos(sl, 8, 70);
        lv_obj_set_width(sl, 220);
        lv_slider_set_range(sl, 40, 400);
        lv_slider_set_value(sl, touch_get_gate(), LV_ANIM_OFF);
        lv_obj_add_event_cb(sl, gate_cb, LV_EVENT_VALUE_CHANGED, NULL);
    }
    caption(s_page[3], "выше порог — меньше ложных касаний", 96);
    btn(s_page[3], 6, 118, 110, 28, "Wi-Fi заново", act_cb, (void *)(intptr_t)1);
    btn(s_page[3], 122, 118, 110, 28, "BLE заново", act_cb, (void *)(intptr_t)2);
    btn(s_page[3], 6, 150, 110, 28, "куб заново", act_cb, (void *)(intptr_t)3);
    btn(s_page[3], 122, 150, 110, 28, "стоп сессии", act_cb, (void *)(intptr_t)7);
    caption(s_page[3], "имя точки", 186);
    s_ssid = field(s_page[3], 8, 206, 220, "Cube");
    caption(s_page[3], "пароль точки, от 8 цифр или букв", 242);
    s_ap_pass = field(s_page[3], 8, 262, 220, "12345678");
    btn(s_page[3], 6, 300, 220, 28, "сохранить точку", act_cb, (void *)(intptr_t)4);
    caption(s_page[3], "домашняя сеть, для скачивания файла", 336);
    btn(s_page[3], 6, 356, 100, 28, "скан", act_cb, (void *)(intptr_t)5);
    btn(s_page[3], 112, 356, 114, 28, "подключить", act_cb, (void *)(intptr_t)6);
    for (i = 0; i < 4; ++i) {
        s_net[i] = btn(s_page[3], 6, 390 + i * 32, 220, 28, "—", net_cb, (void *)(intptr_t)i);
        lv_obj_add_flag(s_net[i], LV_OBJ_FLAG_HIDDEN);
    }
    s_sta_pass = field(s_page[3], 8, 522, 220, "");
    caption(s_page[3], "пароль домашней сети над этой строкой", 556);
    caption(s_page[3], "15/A = 2015 и 2023-A, один провод", 580);
    btn(s_page[3], 6, 600, 54, 28, "авто", proto_cb, (void *)(intptr_t)0);
    btn(s_page[3], 64, 600, 54, 28, "15/A", proto_cb, (void *)(intptr_t)1);
    btn(s_page[3], 122, 600, 54, 28, "2011", proto_cb, (void *)(intptr_t)2);
    btn(s_page[3], 180, 600, 54, 28, "23B", proto_cb, (void *)(intptr_t)3);
    s_diam_lbl = caption(s_page[3], "колесо 16.3", 636);
    btn(s_page[3], 6, 658, 54, 28, "-", act_cb, (void *)(intptr_t)8);
    btn(s_page[3], 64, 658, 54, 28, "+", act_cb, (void *)(intptr_t)9);
    s_msg = caption(s_page[3], "", 696);
    lv_label_set_long_mode(s_msg, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(s_msg, 228);
    lv_obj_set_height(s_page[3], 284);

    caption(s_page[4], "Прямой BLE только на фарик", 8);
    caption(s_page[4], "Выкл: куб слушает UART сам.", 32);
    caption(s_page[4], "Телефон байты не получает.", 52);
    caption(s_page[4], "Вкл: телефон и фарик напрямую.", 76);
    caption(s_page[4], "Кубик кадры не разбирает.", 96);
    {
        lv_obj_t *sw = lv_switch_create(s_page[4]);
        lv_obj_set_pos(sw, 8, 130);
        lv_obj_add_event_cb(sw, direct_cb, LV_EVENT_VALUE_CHANGED, NULL);
    }
    s_direct_lbl = caption(s_page[4], "мост выключен", 168);

    for (i = 0; i < 5; ++i) {
        s_nav[i] = btn(scr, 2 + i * 47, 286, 46, 32, nav[i], nav_cb, (void *)(intptr_t)i);
    }
    s_kb = lv_keyboard_create(scr);
    lv_obj_set_size(s_kb, 240, 140);
    lv_obj_align(s_kb, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_obj_add_event_cb(s_kb, kb_hide_cb, LV_EVENT_READY, NULL);
    lv_obj_add_event_cb(s_kb, kb_hide_cb, LV_EVENT_CANCEL, NULL);
    lv_obj_add_flag(s_kb, LV_OBJ_FLAG_HIDDEN);
    show_page(0);
}

static const char *proto_name(uint8_t p)
{
    if (p == 1) return "2015/A";
    if (p == 2) return "2011";
    if (p == 3) return "2023-B";
    return "авто";
}

static void paint_pack(const bms_link_t *L)
{
    char b[160];
    int i;
    int n;
    int bad = -1;
    if (!s_bms_info) return;
    if (s_bms_tab[0]) lv_obj_set_style_bg_color(s_bms_tab[0], lv_color_hex(s_pack == 0 ? 0x1F6F5B : 0x24485C), 0);
    if (s_bms_tab[1]) lv_obj_set_style_bg_color(s_bms_tab[1], lv_color_hex(s_pack == 1 ? 0x1F6F5B : 0x24485C), 0);
    if (!L->ok) {
        snprintf(b, sizeof(b), "нет связи\nпик %d.%02d Ач",
                 L->peak_mah / 1000, (L->peak_mah / 10) % 100);
    } else {
        int dlt = (L->ncell > 0) ? (L->cell_max_mv - L->cell_min_mv) : 0;
        snprintf(b, sizeof(b),
                 "ёмкость %d.%02d Ач\nпик %d.%02d Ач\n%d.%02d В   %d.%02d А\nразброс %d мВ   %d%%",
                 L->remain_mah / 1000, (L->remain_mah / 10) % 100,
                 L->peak_mah / 1000, (L->peak_mah / 10) % 100,
                 L->mv / 1000, (L->mv / 10) % 100,
                 L->ma / 1000, (L->ma < 0 ? -L->ma : L->ma) / 10 % 100,
                 dlt, L->soc < 0 ? 0 : L->soc);
        if (L->ncell > 0 && (L->cell_max_mv - L->cell_min_mv) >= 20)
            bad = L->cell_max_mv - 20;
    }
    lv_label_set_text(s_bms_info, b);
    n = L->ncell;
    if (n > 18) n = 18;
    for (i = 0; i < 18; ++i) {
        int low;
        if (!s_cell_lbl[i] || !s_cell_box[i]) continue;
        if (!L->ok || i >= n || L->cells[i] <= 0) {
            lv_label_set_text(s_cell_lbl[i], "--");
            lv_obj_set_style_bg_color(s_cell_box[i], lv_color_hex(0x12181C), 0);
            continue;
        }
        snprintf(b, sizeof(b), "%d.%02d", L->cells[i] / 1000, (L->cells[i] / 10) % 100);
        lv_label_set_text(s_cell_lbl[i], b);
        low = bad >= 0 && L->cells[i] <= bad;
        lv_obj_set_style_bg_color(s_cell_box[i], lv_color_hex(low ? 0x7A3030 : 0x12181C), 0);
        lv_obj_set_style_text_color(s_cell_lbl[i], lv_color_hex(0xF4F7FB), 0);
    }
}

void ui_dash_tick(void)
{
    cube_state_snapshot_t st;
    bms_link_t A, B;
    char b[64];
    uint32_t now;
    uint32_t sec;
    int rpm = 0;
    int kmh = 0;
    int link = 0;
    int max_rpm = 0;
    int amps_x10 = 0;
    int max_amps = 0;
    int volts_x10 = 0;
    int err_bits = 0;
    float uv;
    float ia;
    int live;

    app_state_snapshot(&st);
    gbt_can_probe_poll();
    now = (uint32_t)(esp_timer_get_time() / 1000ULL);
    if (st.session_active && now >= st.session_start_ms) sec = (now - st.session_start_ms) / 1000u;
    else sec = 0;
    if (s_time) {
        snprintf(b, sizeof(b), "%02u:%02u:%02u",
                 (unsigned)(sec / 3600u), (unsigned)((sec / 60u) % 60u), (unsigned)(sec % 60u));
        lv_label_set_text(s_time, b);
    }
    if (s_relay) lv_label_set_text(s_relay, st.relay_b ? "ON" : "OFF");
    if (s_proto) lv_label_set_text(s_proto, proto_name(st.protocol));
    if (s_can_line) {
        const char *wire = gbt_can_wire_result();
        if (wire[0]) lv_label_set_text(s_can_line, wire);
        else {
            const char *fault = gbt_can_fault();
            snprintf(b, sizeof(b), "%s rx %lu tx %lu %s",
                     CUBE_FW_VERSION,
                     (unsigned long)st.rx_count, (unsigned long)st.tx_count,
                     fault[0] ? fault : "");
            lv_label_set_text(s_can_line, b);
        }
    }
    if (s_req_v) {
        int v = st.bcl_requested_voltage_raw / 10;
        if (v < 1) v = 240;
        snprintf(b, sizeof(b), "%d", v);
        lv_label_set_text(s_req_v, b);
    }
    if (s_req_a) {
        int a = st.bcl_requested_current_0p1a;
        if (a < 0) a = -a;
        a /= 10;
        if (a < 1) a = 50;
        snprintf(b, sizeof(b), "%d", a);
        lv_label_set_text(s_req_a, b);
    }
    live = st.ccs_output_voltage_raw > 0;
    uv = live ? st.ccs_output_voltage_raw / 10.0f : 0;
    ia = st.ccs_output_current_0p1a / 10.0f;
    if (ia < 0) ia = -ia;
    if (s_out_v) {
        snprintf(b, sizeof(b), "%.0f", (double)uv);
        lv_label_set_text(s_out_v, b);
    }
    if (s_out_a) {
        snprintf(b, sizeof(b), "%.0f", (double)ia);
        lv_label_set_text(s_out_a, b);
    }
    if (s_watt) {
        snprintf(b, sizeof(b), "%.0f", (double)(uv * ia));
        lv_label_set_text(s_watt, b);
    }

    bms_link_get(0, &A);
    bms_link_get(1, &B);
    paint_pack(s_pack ? &B : &A);

    fardriver_stats(&rpm, &kmh, &link, &max_rpm);
    fardriver_power(&amps_x10, &max_amps, &volts_x10, &err_bits);
    if (s_fd_kmh) {
        if (fardriver_direct()) lv_label_set_text(s_fd_kmh, "прямой BLE");
        else if (!link) lv_label_set_text(s_fd_kmh, "0.0 км/ч");
        else {
            snprintf(b, sizeof(b), "%d.%d км/ч", kmh / 10, kmh % 10);
            lv_label_set_text(s_fd_kmh, b);
        }
    }
    if (s_fd_link) lv_label_set_text(s_fd_link, fardriver_direct() ? "мост, разбор выключен" : (link ? "кадр есть" : "нет связи"));
    if (s_fd_i) {
        snprintf(b, sizeof(b), "ток %d.%d А", amps_x10 / 10, amps_x10 % 10);
        lv_label_set_text(s_fd_i, b);
    }
    if (s_fd_imax) {
        snprintf(b, sizeof(b), "макс ток сессии %d.%d А", max_amps / 10, max_amps % 10);
        lv_label_set_text(s_fd_imax, b);
    }
    if (s_fd_v) {
        snprintf(b, sizeof(b), "напряжение %d.%d В", volts_x10 / 10, volts_x10 % 10);
        lv_label_set_text(s_fd_v, b);
    }
    if (s_fd_rpm) {
        snprintf(b, sizeof(b), "обороты %d", link && !fardriver_direct() ? rpm : 0);
        lv_label_set_text(s_fd_rpm, b);
    }
    if (s_fd_err) {
        if (!link || fardriver_direct() || err_bits == 0) lv_label_set_text(s_fd_err, "ошибки нет");
        else {
            snprintf(b, sizeof(b), "ошибка %04x", err_bits & 0xFFFF);
            lv_label_set_text(s_fd_err, b);
        }
    }
    if (s_direct_lbl) lv_label_set_text(s_direct_lbl, fardriver_direct() ? "мост включен" : "мост выключен");
    if (s_diam_lbl) {
        int t = fardriver_diameter_tenths();
        snprintf(b, sizeof(b), "колесо %d.%d", t / 10, t % 10);
        lv_label_set_text(s_diam_lbl, b);
    }
    if (!s_ap_filled && s_ssid && web_ap_ssid()[0]) {
        lv_textarea_set_text(s_ssid, web_ap_ssid());
        if (s_ap_pass) lv_textarea_set_text(s_ap_pass, web_ap_pass());
        s_ap_filled = 1;
    }
}
