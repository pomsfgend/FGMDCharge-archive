#include "can_gbt.h"
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "driver/gpio.h"
#include "esp_rom_sys.h"
#include "config.h"
#include "gbt_tp.h"
#include "gbt_b.h"
#include "app_state.h"

static const char *TAG = "GBT_CAN";
static SemaphoreHandle_t s_lock;
static cube_can_frame_t s_history[CUBE_CAN_HISTORY];
static size_t s_head;
static size_t s_count;
static bool s_running;
static bool s_tx_enabled;
static int s_last_tx_err;
static int s_bus_off;
static volatile int s_hold;
static char s_wire[64];
static int s_probe;
static int64_t s_probe_end;
static int s_saw_low;
static int s_saw_high;
static int s_float;
static gbt_can_diag_t s_diag;
static gbt_tp_rx_t s_tp_chg;
static gbt_tp_rx_t s_tp_bat;

static uint32_t now_ms(void)
{
    return (uint32_t)(esp_timer_get_time() / 1000ULL);
}

static uint16_t le16(const uint8_t *p)
{
    return (uint16_t)((uint16_t)p[0] | ((uint16_t)p[1] << 8));
}

static int16_t decode_current_0p1a(uint16_t raw)
{
    int32_t value = (int32_t)raw - 4000;
    if (value > INT16_MAX) value = INT16_MAX;
    if (value < INT16_MIN) value = INT16_MIN;
    return (int16_t)value;
}

static bool is_b_secc(uint32_t id)
{
    uint32_t body = id & 0x00FFFFFFu;
    uint8_t sa = (uint8_t)(body & 0xFFu);
    uint8_t ps = (uint8_t)((body >> 8) & 0xFFu);
    uint8_t pf = (uint8_t)((body >> 16) & 0xFFu);
    return sa == 0x5Fu && ps == 0x25u && (pf == 0x38u || (pf >= 0x34u && pf <= 0x37u));
}

static bool is_charger_id(uint32_t id)
{
    if (is_b_secc(id)) return true;
    switch (id) {
        case GBT_ID_CTS:
        case GBT_ID_CRM:
        case GBT_ID_CHM:
        case GBT_ID_CRO:
        case GBT_ID_CST:
        case GBT_ID_CSD:
        case GBT_ID_CEM:
        case GBT_ID_CML:
        case GBT_ID_CCS:
        case GBT_ID_TP_CM_CHG:
        case GBT_ID_TP_DT_CHG:
            return true;
        default:
            return false;
    }
}

static void decode_known(const twai_message_t *rx)
{
    const uint8_t *d = rx->data;
    switch (rx->identifier) {
        case GBT_ID_CHM:
            app_state_set_charger_stage(CUBE_STAGE_HANDSHAKE);
            if (rx->data_length_code >= 3U) {
                char m[48];
                snprintf(m, sizeof(m), "CHM ver %u.%u.%u", d[0], d[1], d[2]);
                app_state_log(m);
            }
            break;
        case GBT_ID_CRM:
            app_state_set_charger_stage(CUBE_STAGE_HANDSHAKE);
            break;
        case GBT_ID_CML:
            if (rx->data_length_code >= 6U) {
                /* 2015/2023-A: 8 bytes. 2011: 6 bytes, no minimum current. */
                uint16_t max_v = le16(&d[0]);
                uint16_t min_v = le16(&d[2]);
                int16_t max_i = decode_current_0p1a(le16(&d[4]));
                int16_t min_i = 0;
                if (rx->data_length_code >= 8U) min_i = decode_current_0p1a(le16(&d[6]));
                app_state_set_cml(max_v, min_v, max_i, min_i);
            }
            break;
        case GBT_ID_CRO:
            if (rx->data_length_code >= 1U) app_state_set_cro(d[0]);
            break;
        case GBT_ID_CCS:
            if (rx->data_length_code >= 6U) {
                uint16_t out_v = le16(&d[0]);
                int16_t out_i = decode_current_0p1a(le16(&d[2]));
                uint16_t charge_time = le16(&d[4]);
                /* 2011 CCS is 6 bytes and has no permit bit. 2015/2023-A adds it. */
                uint8_t permit = (rx->data_length_code >= 7U) ? d[6] : 0x01u;
                app_state_set_ccs(out_v, out_i, charge_time, permit);
            }
            break;
        case GBT_ID_CST:
            if (rx->data_length_code >= 1U) app_state_set_cst(d[0]);
            break;
        case GBT_ID_CSD:
            if (rx->data_length_code >= 4U) {
                app_state_set_csd(le16(&d[0]), le16(&d[2]));
            }
            break;
        case GBT_ID_CEM:
            if (rx->data_length_code >= 1U) app_state_set_cem(d, rx->data_length_code);
            break;
        case GBT_ID_BCL:
            if (rx->data_length_code >= 5U) {
                app_state_set_bcl(le16(&d[0]), decode_current_0p1a(le16(&d[2])), d[4]);
            }
            break;
        default:
            break;
    }
}

static int s_tec;
static int s_rec;
static char s_fault[64];

static void update_bus_state(void)
{
    twai_status_info_t info = {0};
    if (!s_running) {
        app_state_set_can(false);
        return;
    }
    if (twai_get_status_info(&info) != ESP_OK) return;
    s_tec = (int)info.tx_error_counter;
    s_rec = (int)info.rx_error_counter;

    if (info.state == TWAI_STATE_BUS_OFF) {
        s_bus_off = 1;
        app_state_set_can(false);
        (void)twai_initiate_recovery();
    } else if (info.state == TWAI_STATE_STOPPED) {
        if (twai_start() == ESP_OK) {
            s_bus_off = 0;
            app_state_set_can(true);
        }
    } else if (info.state == TWAI_STATE_RUNNING) {
        s_bus_off = 0;
        app_state_set_can(true);
    }
}

esp_err_t gbt_can_init(void)
{
    if (s_running) return ESP_OK;
    if (!s_lock) s_lock = xSemaphoreCreateMutex();
    if (!s_lock) return ESP_ERR_NO_MEM;

    twai_general_config_t g = TWAI_GENERAL_CONFIG_DEFAULT(CUBE_CAN_TX_GPIO, CUBE_CAN_RX_GPIO, TWAI_MODE_NORMAL);
    g.tx_queue_len = CUBE_CAN_TX_QUEUE;
    g.rx_queue_len = CUBE_CAN_RX_QUEUE;
    twai_timing_config_t t = TWAI_TIMING_CONFIG_250KBITS();
    twai_filter_config_t f = TWAI_FILTER_CONFIG_ACCEPT_ALL();

    esp_err_t err = twai_driver_install(&g, &t, &f);
    if (err == ESP_ERR_INVALID_STATE) {
        (void)twai_stop();
        (void)twai_driver_uninstall();
        err = twai_driver_install(&g, &t, &f);
    }
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "CAN install %s", esp_err_to_name(err));
        return err;
    }
    err = twai_start();
    if (err != ESP_OK) {
        (void)twai_driver_uninstall();
        return err;
    }

    s_running = true;
    s_tx_enabled = CUBE_TX_DEFAULT_ENABLED != 0;
    memset(s_history, 0, sizeof(s_history));
    memset(&s_diag, 0, sizeof(s_diag));
    s_head = 0;
    s_count = 0;
    gbt_tp_init(&s_tp_chg);
    gbt_tp_init(&s_tp_bat);
    app_state_set_can(true);
    app_state_set_tx_enabled(s_tx_enabled);
    ESP_LOGI(TAG, "CAN/TWAI up: TX=%d RX=%d bitrate=%d", CUBE_CAN_TX_GPIO, CUBE_CAN_RX_GPIO, CUBE_CAN_BITRATE);
    return ESP_OK;
}

void gbt_can_set_tx_enabled(bool enabled)
{
#if CUBE_TX_COMPILED_ENABLE
    if (s_lock) (void)xSemaphoreTake(s_lock, portMAX_DELAY);
    s_tx_enabled = enabled;
    if (s_lock) (void)xSemaphoreGive(s_lock);
    app_state_set_tx_enabled(enabled);
#else
    (void)enabled;
    if (s_lock) (void)xSemaphoreTake(s_lock, portMAX_DELAY);
    s_tx_enabled = false;
    if (s_lock) (void)xSemaphoreGive(s_lock);
    app_state_set_tx_enabled(false);
#endif
}

bool gbt_can_get_tx_enabled(void)
{
    bool enabled = false;
    if (s_lock) (void)xSemaphoreTake(s_lock, portMAX_DELAY);
    enabled = s_tx_enabled;
    if (s_lock) (void)xSemaphoreGive(s_lock);
    return enabled;
}

esp_err_t gbt_can_send(uint32_t id, const uint8_t *data, uint8_t dlc)
{
    twai_status_info_t before = {0};
    twai_status_info_t after = {0};
    esp_err_t err;
    if (!s_running || !data || dlc > 8U || id > 0x1FFFFFFFu) {
        if (!s_hold && !s_running) (void)gbt_can_init();
        if (!s_running) {
            snprintf(s_fault, sizeof(s_fault), s_hold ? "тест пинов" : "CAN не стартовал");
            s_last_tx_err = (int)ESP_ERR_INVALID_STATE;
            return ESP_ERR_INVALID_STATE;
        }
        if (!data || dlc > 8U || id > 0x1FFFFFFFu) return ESP_ERR_INVALID_ARG;
    }

    bool tx_enabled = false;
    if (s_lock) (void)xSemaphoreTake(s_lock, portMAX_DELAY);
    tx_enabled = s_tx_enabled;
    if (s_lock) (void)xSemaphoreGive(s_lock);
    if (!tx_enabled) {
        snprintf(s_fault, sizeof(s_fault), "передача выкл");
        s_last_tx_err = (int)ESP_ERR_INVALID_STATE;
        app_state_can_tx_drop();
        return ESP_ERR_INVALID_STATE;
    }

    if (twai_get_status_info(&before) != ESP_OK) {
        snprintf(s_fault, sizeof(s_fault), "нет статуса");
        s_last_tx_err = (int)ESP_ERR_INVALID_STATE;
        return ESP_ERR_INVALID_STATE;
    }
    s_tec = (int)before.tx_error_counter;
    s_rec = (int)before.rx_error_counter;
    if (before.state == TWAI_STATE_BUS_OFF) {
        update_bus_state();
        snprintf(s_fault, sizeof(s_fault), "bus-off t%d r%d", s_tec, s_rec);
        s_last_tx_err = (int)ESP_ERR_INVALID_STATE;
        app_state_can_tx_drop();
        return ESP_ERR_INVALID_STATE;
    }
    if (before.state != TWAI_STATE_RUNNING) {
        update_bus_state();
        if (twai_get_status_info(&before) != ESP_OK || before.state != TWAI_STATE_RUNNING) {
            snprintf(s_fault, sizeof(s_fault), "не запущен st=%d t%d r%d",
                     (int)before.state, s_tec, s_rec);
            s_last_tx_err = (int)ESP_ERR_INVALID_STATE;
            app_state_can_tx_drop();
            return ESP_ERR_INVALID_STATE;
        }
    }
    /* r>0 means the station is on the wire. Stopping the controller here
     * throws away its frames. Reset only when we are alone and about to bus-off. */
    if (before.tx_error_counter > 112 && before.rx_error_counter == 0) {
        (void)twai_stop();
        (void)twai_start();
        if (twai_get_status_info(&before) != ESP_OK || before.state != TWAI_STATE_RUNNING) {
            snprintf(s_fault, sizeof(s_fault), "не запущен st=%d", (int)before.state);
            s_last_tx_err = (int)ESP_ERR_INVALID_STATE;
            return ESP_ERR_INVALID_STATE;
        }
    }

    twai_message_t tx = {0};
    tx.identifier = id;
    tx.data_length_code = dlc;
    tx.flags = TWAI_MSG_FLAG_SS;
    if (id > 0x7FFu) tx.flags |= TWAI_MSG_FLAG_EXTD;
    memcpy(tx.data, data, dlc);

    err = twai_transmit(&tx, pdMS_TO_TICKS(30));
    if (err != ESP_OK) {
        (void)twai_get_status_info(&after);
        s_tec = (int)after.tx_error_counter;
        s_rec = (int)after.rx_error_counter;
        s_last_tx_err = (int)err;
        snprintf(s_fault, sizeof(s_fault), "%s st=%d t%d r%d",
                 esp_err_to_name(err), (int)after.state, s_tec, s_rec);
        app_state_can_tx_drop();
        update_bus_state();
        return err;
    }

    vTaskDelay(pdMS_TO_TICKS(20));
    if (twai_get_status_info(&after) != ESP_OK) {
        snprintf(s_fault, sizeof(s_fault), "нет статуса после TX");
        s_last_tx_err = (int)ESP_ERR_INVALID_STATE;
        return ESP_ERR_INVALID_STATE;
    }
    s_tec = (int)after.tx_error_counter;
    s_rec = (int)after.rx_error_counter;
    s_bus_off = after.state == TWAI_STATE_BUS_OFF;
    if (after.state == TWAI_STATE_RUNNING && after.msgs_to_tx == 0 &&
        after.tx_failed_count == before.tx_failed_count &&
        after.tx_error_counter == before.tx_error_counter) {
        s_last_tx_err = 0;
        s_fault[0] = 0;
        s_bus_off = 0;
        app_state_can_tx_ok();
        return ESP_OK;
    }
    s_last_tx_err = (int)ESP_ERR_TIMEOUT;
    snprintf(s_fault, sizeof(s_fault), "нет ACK t%d r%d", s_tec, s_rec);
    app_state_can_tx_drop();
    update_bus_state();
    return ESP_ERR_TIMEOUT;
}

const char *gbt_can_fault(void)
{
    return s_fault;
}

static void can_pins_take(void)
{
    s_hold = 1;
    if (s_running) {
        (void)twai_stop();
        vTaskDelay(pdMS_TO_TICKS(30));
        (void)twai_driver_uninstall();
        s_running = false;
    }
    gpio_reset_pin(CUBE_CAN_TX_GPIO);
    gpio_reset_pin(CUBE_CAN_RX_GPIO);
    gpio_set_direction(CUBE_CAN_TX_GPIO, GPIO_MODE_OUTPUT);
    gpio_set_direction(CUBE_CAN_RX_GPIO, GPIO_MODE_INPUT);
}

static void can_pins_give(void)
{
    gpio_set_level(CUBE_CAN_TX_GPIO, 1);
    (void)gbt_can_init();
    s_hold = 0;
}

/* A floating pad follows the pull. A driven CRX pin does not. */
static int rx_is(int want)
{
    int i;
    gpio_set_pull_mode(CUBE_CAN_RX_GPIO, want ? GPIO_PULLDOWN_ONLY : GPIO_PULLUP_ONLY);
    esp_rom_delay_us(1500);
    for (i = 0; i < 6; ++i) {
        if (gpio_get_level(CUBE_CAN_RX_GPIO) != want) return 0;
        esp_rom_delay_us(200);
    }
    return 1;
}

const char *gbt_can_wire_result(void)
{
    return s_wire;
}

void gbt_can_wire_test(void)
{
    int hi;
    int lo;
    can_pins_take();
    gpio_set_level(CUBE_CAN_TX_GPIO, 1);
    hi = rx_is(1);
    gpio_set_level(CUBE_CAN_TX_GPIO, 0);
    lo = rx_is(0);
    can_pins_give();
    if (hi && lo) snprintf(s_wire, sizeof(s_wire), "17-18 целые");
    else snprintf(s_wire, sizeof(s_wire), "17-18 нет связи");
    app_state_log(s_wire);
    ESP_LOGW(TAG, "%s hi=%d lo=%d", s_wire, hi, lo);
}

/* Open CRX with a pull-up used to look like a bus short. A real CRX
 * beats the opposite pull. A short keeps CRX high on a dominant request. */
void gbt_can_bus_test(void)
{
    if (s_probe) return;
    can_pins_take();
    s_saw_low = 0;
    s_saw_high = 0;
    s_float = 0;
    s_probe_end = esp_timer_get_time() + 3000000LL;
    s_probe = 1;
    snprintf(s_wire, sizeof(s_wire), "замкни сейчас");
}

void gbt_can_probe_poll(void)
{
    int64_t now;
    int low;
    int rx;
    if (!s_probe) return;
    now = esp_timer_get_time();
    low = ((now / 250000LL) & 1LL) == 0;
    gpio_set_level(CUBE_CAN_TX_GPIO, low ? 0 : 1);
    gpio_set_pull_mode(CUBE_CAN_RX_GPIO, low ? GPIO_PULLUP_ONLY : GPIO_PULLDOWN_ONLY);
    esp_rom_delay_us(400);
    rx = gpio_get_level(CUBE_CAN_RX_GPIO);
    if (low && rx == 0) s_saw_low = 1;
    if (low && rx == 1) s_saw_high = 1;
    if (!low && rx == 0) s_float = 1;
    if (now < s_probe_end) {
        snprintf(s_wire, sizeof(s_wire), "CRX=%d %s", rx, low ? "ДОМ" : "РЕЦ");
        return;
    }
    s_probe = 0;
    can_pins_give();
    if (s_float && !s_saw_low) snprintf(s_wire, sizeof(s_wire), "пин 18 пустой");
    else if (s_saw_low && s_saw_high) snprintf(s_wire, sizeof(s_wire), "КЗ видно");
    else if (s_saw_high && !s_saw_low) snprintf(s_wire, sizeof(s_wire), "КЗ есть");
    else snprintf(s_wire, sizeof(s_wire), "КЗ не видно");
}

void gbt_can_task(void *arg)
{
    (void)arg;
    twai_message_t rx;

    for (;;) {
        if (s_hold || !s_running) {
            if (!s_hold && !s_running) (void)gbt_can_init();
            vTaskDelay(pdMS_TO_TICKS(200));
            continue;
        }

        memset(&rx, 0, sizeof(rx));
        esp_err_t err = twai_receive(&rx, pdMS_TO_TICKS(1000));
        if (err == ESP_OK) {
            cube_can_frame_t f = {0};
            f.id = rx.identifier;
            f.dlc = rx.data_length_code > 8U ? 8U : rx.data_length_code;
            f.flags = rx.flags;
            f.timestamp_ms = now_ms();
            memcpy(f.data, rx.data, f.dlc);

            if (s_lock) (void)xSemaphoreTake(s_lock, portMAX_DELAY);
            s_history[s_head] = f;
            s_head = (s_head + 1U) % CUBE_CAN_HISTORY;
            if (s_count < CUBE_CAN_HISTORY) s_count++;
            s_diag.rx_frames++;
            s_diag.last_id = f.id;
            s_diag.last_dlc = f.dlc;
            memcpy(s_diag.last_data, f.data, sizeof(s_diag.last_data));
            if (s_lock) (void)xSemaphoreGive(s_lock);

            app_state_can_rx(&f, is_charger_id(f.id));
            {
                char line[96];
                snprintf(line, sizeof(line),
                         "RX %08lX %u %02X %02X %02X %02X %02X %02X %02X %02X",
                         (unsigned long)f.id, (unsigned)f.dlc,
                         f.data[0], f.data[1], f.data[2], f.data[3],
                         f.data[4], f.data[5], f.data[6], f.data[7]);
                app_state_log(line);
            }
            decode_known(&rx);
            gbt_b_on_rx(f.id, f.data, f.dlc);

            gbt_tp_rx_t *tp = NULL;
            if (f.id == GBT_ID_TP_CM_CHG || f.id == GBT_ID_TP_DT_CHG) {
                tp = &s_tp_chg;
            } else if (f.id == GBT_ID_TP_CM_BAT || f.id == GBT_ID_TP_DT_BAT) {
                tp = &s_tp_bat;
            }

            if (tp) {
                const uint8_t *payload = NULL;
                size_t payload_len = 0;
                if (gbt_tp_consume(tp, f.id, f.data, f.dlc, &payload, &payload_len)) {
                    ESP_LOGI(TAG, "GB/T TP payload complete: %u bytes", (unsigned)payload_len);
                    if (payload_len >= 4U && f.id == GBT_ID_TP_DT_BAT) {
                        /* BCP/BCS/etc. are retained as raw TP payload until their exact
                           original dispatch mapping is fully proven from the dump. */
                    }
                    (void)payload;
                }
            }
            app_state_set_can(true);
        } else {
            update_bus_state();
        }
    }
}

esp_err_t gbt_can_get_last(cube_can_frame_t *out)
{
    if (!out) return ESP_ERR_INVALID_ARG;
    cube_state_snapshot_t st;
    app_state_snapshot(&st);
    *out = st.last;
    return ESP_OK;
}

esp_err_t gbt_can_get_history(cube_can_frame_t *out, size_t max_count, size_t *actual_count)
{
    if (!out || !actual_count || max_count == 0U) return ESP_ERR_INVALID_ARG;
    if (s_lock) (void)xSemaphoreTake(s_lock, portMAX_DELAY);
    size_t n = s_count < max_count ? s_count : max_count;
    size_t start = (s_head + CUBE_CAN_HISTORY - n) % CUBE_CAN_HISTORY;
    for (size_t i = 0; i < n; ++i) {
        out[i] = s_history[(start + i) % CUBE_CAN_HISTORY];
    }
    if (s_lock) (void)xSemaphoreGive(s_lock);
    *actual_count = n;
    return ESP_OK;
}

void gbt_can_get_diag(gbt_can_diag_t *out)
{
    if (!out) return;
    if (s_lock) (void)xSemaphoreTake(s_lock, portMAX_DELAY);
    *out = s_diag;
    if (s_lock) (void)xSemaphoreGive(s_lock);
}
