#pragma once
#include "lvgl.h"

void ui_dash_build(lv_obj_t *scr);
void ui_dash_tick(void);
