#pragma once
#include "lvgl.h"
#include <stdint.h>

void ui_dash_build(lv_obj_t *scr);
void ui_dash_tick(void);
void ui_dash_fit(void);
void ui_dash_load(void);
void ui_dash_set_cycle(int on);
void ui_dash_set_dwell(int sec);
void ui_dash_set_page(int n);
int ui_dash_get_cycle(void);
int ui_dash_get_dwell(void);
int ui_dash_get_page(void);
int ui_dash_get_skin(void);
void ui_dash_set_skin(int skin);
/* "id:x,y,w,h;..." плюс свои плитки "u0:x,y,w,h,страница,источник" и вкладки "#5:ИМЯ". Пусто — заводской экран. */
void ui_dash_set_layout(const char *lay);
/* km/h x10 from the phone. -1 means no fix. Stale after 3 s. */
void ui_dash_set_gps10(int kmh_x10);
void ui_dash_trip(int *gps10, int *peak_bms_ma, int *peak_kmh10,
                  uint32_t *ses_rpm_m, uint32_t *ses_gps_m,
                  uint32_t *tot_rpm_m, uint32_t *tot_gps_m);
