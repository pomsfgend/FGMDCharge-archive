#include "touch_cst816s.h"
#include "config.h"
#include "app_state.h"
#include "driver/gpio.h"
#include "driver/spi_master.h"
#include "esp_log.h"
#include "esp_timer.h"

static const char *TAG = "TOUCH";
static spi_device_handle_t s_dev;
static bool s_ok;
static int s_logs;
static int s_z_gate = 80;
static int s_last_z;
static int s_last_x;
static int s_last_y;
static int s_irq_low;

int touch_last_z(void) { return s_last_z; }
int touch_last_x(void) { return s_last_x; }
int touch_last_y(void) { return s_last_y; }
int touch_irq_low(void) { return s_irq_low; }

void touch_set_gate(int z)
{
    if (z < 40) z = 40;
    if (z > 400) z = 400;
    s_z_gate = z;
}

int touch_get_gate(void)
{
    return s_z_gate;
}

static int pen_down(void)
{
#if CUBE_XPT_IRQ_GPIO >= 0
    return gpio_get_level(CUBE_XPT_IRQ_GPIO) == 0;
#else
    return 1;
#endif
}

/* Full-duplex 24 clocks. Half-duplex on the shared bus shifted the bits and looked like noise. */
static int xpt_raw(uint8_t cmd)
{
    uint8_t tx[3] = {cmd, 0x00, 0x00};
    uint8_t rx[3] = {0, 0, 0};
    spi_transaction_t tr = {
        .length = 24,
        .rxlength = 24,
        .tx_buffer = tx,
        .rx_buffer = rx,
    };
    if (!s_dev || spi_device_polling_transmit(s_dev, &tr) != ESP_OK) return -1;
    return (((int)rx[1] << 8 | rx[2]) >> 3) & 0x0FFF;
}

static int med3(int a, int b, int c)
{
    if (a > b) { int t = a; a = b; b = t; }
    if (b > c) { int t = b; b = c; c = t; }
    if (a > b) { int t = a; a = b; b = t; }
    return b;
}

static int spread3(int a, int b, int c)
{
    int lo = a;
    int hi = a;
    if (b < lo) lo = b;
    if (b > hi) hi = b;
    if (c < lo) lo = c;
    if (c > hi) hi = c;
    return hi - lo;
}

static int xpt_stable(uint8_t cmd, int *spread)
{
    int a = xpt_raw(cmd);
    int b = xpt_raw(cmd);
    int c = xpt_raw(cmd);
    if (a < 0 || b < 0 || c < 0) {
        *spread = 9999;
        return -1;
    }
    *spread = spread3(a, b, c);
    return med3(a, b, c);
}

static int map_raw(int raw, int lo, int hi, int span)
{
    if (raw < lo) raw = lo;
    if (raw > hi) raw = hi;
    return (raw - lo) * (span - 1) / (hi - lo);
}

esp_err_t touch_init(void)
{
    if (s_ok && s_dev) {
        ESP_LOGW(TAG, "XPT2046 already on SPI CS=%d", CUBE_XPT_CS_GPIO);
        return ESP_OK;
    }
    app_state_set_touch(false, false);
    ESP_LOGW(TAG, "XPT2046 not on the bus yet");
    return ESP_OK;
}

esp_err_t touch_attach_spi(void)
{
    spi_device_interface_config_t dev = {
        .clock_speed_hz = 2000000,
        .mode = 0,
        .spics_io_num = CUBE_XPT_CS_GPIO,
        .queue_size = 1,
        .cs_ena_pretrans = 2,
        .cs_ena_posttrans = 2,
    };
    esp_err_t err = spi_bus_add_device(SPI2_HOST, &dev, &s_dev);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "XPT2046 add failed: %s", esp_err_to_name(err));
        return err;
    }
    s_ok = true;
    app_state_set_touch(true, false);
#if CUBE_XPT_IRQ_GPIO >= 0
    gpio_config_t io = {
        .pin_bit_mask = 1ULL << CUBE_XPT_IRQ_GPIO,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io);
#endif
    ESP_LOGW(TAG, "XPT2046 CS=%d IRQ=%d MISO=%d только T_DO", CUBE_XPT_CS_GPIO, CUBE_XPT_IRQ_GPIO, CUBE_LCD_MISO_GPIO);
    return ESP_OK;
}

bool touch_is_available(void) { return s_ok; }

void touch_lvgl_read(lv_indev_drv_t *drv, lv_indev_data_t *data)
{
    (void)drv;
    static int16_t last_x;
    static int16_t last_y;
    static int good;
    static int bad;
    static int pressed;
    static int16_t arm_x;
    static int16_t arm_y;
    int zs = 9999;
    int xs = 9999;
    int ys = 9999;
    int z = -1;
    int z2 = -1;
    int xraw = -1;
    int yraw = -1;
    if (!s_ok) {
        data->state = LV_INDEV_STATE_REL;
        data->point.x = last_x;
        data->point.y = last_y;
        return;
    }
    s_irq_low = pen_down();
    if (spi_device_acquire_bus(s_dev, pdMS_TO_TICKS(30)) == ESP_OK) {
        z = xpt_stable(0xB1, &zs);
        z2 = xpt_raw(0xC1);
        xraw = xpt_stable(0xD0, &xs);
        yraw = xpt_stable(0x90, &ys);
        (void)xpt_raw(0x80);
        spi_device_release_bus(s_dev);
    }
    s_last_z = z;
    /* A low IRQ by itself is not a finger. That was the tap into empty space. */
    bool hit = z > s_z_gate && z < 3900 && z2 > 30 && z2 < 4050
        && zs < 400 && xs < 400 && ys < 400
        && xraw > 180 && yraw > 180 && xraw < 3950 && yraw < 3950;
    int x = map_raw(xraw < 0 ? 0 : xraw, 300, 3800, CUBE_LCD_H_RES);
    int y = map_raw(yraw < 0 ? 0 : yraw, 300, 3800, CUBE_LCD_V_RES);
#if CUBE_TOUCH_INVERT_X
    x = CUBE_LCD_H_RES - 1 - x;
#endif
#if CUBE_TOUCH_INVERT_Y
    y = CUBE_LCD_V_RES - 1 - y;
#endif
    s_last_x = x;
    s_last_y = y;
    {
        static int64_t s_log_us;
        int64_t now = esp_timer_get_time();
        if (now - s_log_us > 15000000) {
            s_log_us = now;
            ESP_LOGW(TAG, "тач z=%d x=%d y=%d irq=%d", z, xraw, yraw, s_irq_low);
        }
    }
    if (hit && s_logs < 8) {
        ESP_LOGI(TAG, "raw x=%d y=%d z=%d -> %d,%d", xraw, yraw, z, x, y);
        s_logs++;
    }
    if (hit) {
        int dx = x - last_x;
        int dy = y - last_y;
        if (dx < 0) dx = -dx;
        if (dy < 0) dy = -dy;
        bad = 0;
        if (!pressed) {
            int ax = x - arm_x;
            int ay = y - arm_y;
            if (ax < 0) ax = -ax;
            if (ay < 0) ay = -ay;
            if (good > 0 && (ax > 20 || ay > 24)) good = 0;
            if (good < 4) good++;
            arm_x = (int16_t)x;
            arm_y = (int16_t)y;
            if (good >= 2) {
                pressed = 1;
                last_x = (int16_t)x;
                last_y = (int16_t)y;
            }
        } else if (dx <= 36 && dy <= 48) {
            good = 2;
            last_x = (int16_t)x;
            last_y = (int16_t)y;
        }
    } else {
        good = 0;
        if (bad < 6) bad++;
        if (bad >= 3) pressed = 0;
    }
    data->point.x = last_x;
    data->point.y = last_y;
    data->state = pressed ? LV_INDEV_STATE_PR : LV_INDEV_STATE_REL;
    app_state_set_touch(true, pressed);
}
