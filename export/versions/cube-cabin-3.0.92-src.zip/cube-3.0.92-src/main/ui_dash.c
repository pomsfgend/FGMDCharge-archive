#include "ui_dash.h"

#include "app_state.h"
#include "bms_uart.h"
#include "cabin.h"
#include "can_gbt.h"
#include "config.h"
#include "display.h"
#include "driver/gpio.h"
#include "esp_timer.h"
#include "fardriver_uart.h"
#include "nvs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern const lv_font_t lv_font_ru_14;
extern const lv_font_t lv_font_montserrat_28;

#define PAGE_MAX 8
#define USER_N 8
#define NAV_H 34
#define REL_N 5

#ifdef CUBE_RELAY_PAR_GPIO
#define REL_PAR_GPIO CUBE_RELAY_PAR_GPIO
#else
#define REL_PAR_GPIO (-1)
#endif

static const int k_rel_gpio[REL_N] = {
    42, 40, CUBE_RELAY_A_GPIO, CUBE_RELAY_B_GPIO, REL_PAR_GPIO
};
static const char *k_rel_name[REL_N] = {"фара", "лента", "имит", "акб", "пар"};

static lv_obj_t *s_page[PAGE_MAX];
static lv_obj_t *s_nav[PAGE_MAX];
static lv_obj_t *s_seat_box;
static lv_obj_t *s_amb_box;
static lv_obj_t *s_pwm_box;
static lv_obj_t *s_seat;
static lv_obj_t *s_amb;
static lv_obj_t *s_pwm;
static lv_obj_t *s_v_box;
static lv_obj_t *s_a_box;
static lv_obj_t *s_time_box;
static lv_obj_t *s_proto_box;
static lv_obj_t *s_watt_box;
static lv_obj_t *s_reqv_box;
static lv_obj_t *s_reqa_box;
static lv_obj_t *s_rel_box;
static lv_obj_t *s_time;
static lv_obj_t *s_relay;
static lv_obj_t *s_proto;
static lv_obj_t *s_can_line;
static lv_obj_t *s_req_v;
static lv_obj_t *s_req_a;
static lv_obj_t *s_watt;
static lv_obj_t *s_out_v;
static lv_obj_t *s_out_a;
static lv_obj_t *s_arc;
static lv_obj_t *s_spd_num;
static lv_obj_t *s_spd_cap;
static lv_obj_t *s_rpm_box;
static lv_obj_t *s_gps_box;
static lv_obj_t *s_rpm_v;
static lv_obj_t *s_gps_v;
static lv_obj_t *s_cpu_box;
static lv_obj_t *s_cpu;
static lv_obj_t *s_cell[REL_N];
static lv_obj_t *s_ln[6];
static lv_obj_t *s_bat[6];
static lv_obj_t *s_user_box[USER_N];
static lv_obj_t *s_user_val[USER_N];
static char s_user_src[USER_N][8];
static char s_nav_name[PAGE_MAX][16];
static int s_user_page[USER_N];
static int s_user_used[USER_N];
static int s_pages = 5;
static int s_hor = 240;
static int s_ver = 320;
static int s_vmin_mv;
static int s_vmax_mv;
static int s_after_mah;

static int s_cycle = 1;
static int s_dwell = 5;
static int s_cur;
static int64_t s_turn_us;

static volatile int s_gps10 = -1;
static volatile int64_t s_gps_us;
static uint32_t s_ses_rpm;
static uint32_t s_ses_gps;
static uint32_t s_tot_rpm;
static uint32_t s_tot_gps;
static uint32_t s_rem_rpm;
static uint32_t s_rem_gps;
static int s_peak_ma;
static int s_peak_kmh10;
static int s_odo_dirty;
static int64_t s_odo_us;
static int64_t s_odo_save_us;
static int s_skin;
static char s_lay[1600];

static uint32_t sk_bg(void) { return s_skin == 2 ? 0xF4EFE4u : s_skin == 1 ? 0x2A3140u : 0x090C12u; }
static uint32_t sk_card(void) { return s_skin == 2 ? 0xFFFDF8u : s_skin == 1 ? 0x3A4458u : 0x131925u; }
static uint32_t sk_fg(void) { return s_skin == 2 ? 0x1C1914u : 0xF1F4FAu; }
static uint32_t sk_muted(void) { return s_skin == 2 ? 0x5C564Cu : s_skin == 1 ? 0xC5CEDAu : 0x8E99AEu; }
static uint32_t sk_on(void) { return s_skin == 2 ? 0xC4840Du : s_skin == 1 ? 0xF0C14Bu : 0xFFB02Eu; }
static uint32_t sk_line(void) { return s_skin == 2 ? 0xD9CBB3u : s_skin == 1 ? 0x5C6B82u : 0x283142u; }
static uint32_t sk_ink(void) { return 0x1A1408u; }
static void dash_chrome(void);

static void box_at(lv_obj_t *o, int x, int y, int w, int h)
{
    if (!o) return;
    if (w < 8) w = 8;
    if (h < 8) h = 8;
    lv_obj_set_pos(o, x, y);
    lv_obj_set_size(o, w, h);
}

static void line_at(lv_obj_t *o, int x, int y, int w)
{
    if (!o) return;
    lv_obj_set_pos(o, x, y);
    lv_obj_set_width(o, w);
}

static lv_obj_t *tile(lv_obj_t *p, uint32_t bg, uint32_t fg, const char *cap, lv_obj_t **value, const char *init, const lv_font_t *font)
{
    lv_obj_t *c = lv_obj_create(p);
    lv_obj_t *v;
    lv_obj_t *k;
    lv_obj_set_style_bg_color(c, lv_color_hex(bg), 0);
    lv_obj_set_style_bg_opa(c, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(c, 14, 0);
    lv_obj_set_style_border_width(c, 1, 0);
    lv_obj_set_style_border_color(c, lv_color_hex(bg == 0xFFB02E ? 0xFFB02E : 0x283142), 0);
    lv_obj_set_style_pad_all(c, 0, 0);
    lv_obj_clear_flag(c, LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_CLICKABLE);
    v = lv_label_create(c);
    lv_label_set_text(v, init);
    lv_obj_set_width(v, lv_pct(92));
    lv_label_set_long_mode(v, LV_LABEL_LONG_DOT);
    lv_obj_set_style_text_font(v, font, 0);
    lv_obj_set_style_text_color(v, lv_color_hex(fg), 0);
    lv_obj_set_style_text_align(v, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(v, LV_ALIGN_CENTER, 0, -6);
    k = lv_label_create(c);
    lv_label_set_text(k, cap);
    lv_obj_set_width(k, lv_pct(92));
    lv_label_set_long_mode(k, LV_LABEL_LONG_DOT);
    lv_obj_set_style_text_font(k, &lv_font_ru_14, 0);
    lv_obj_set_style_text_color(k, lv_color_hex(bg == 0xFFB02E ? 0x1A1205 : 0xFFB02E), 0);
    lv_obj_set_style_text_align(k, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(k, LV_ALIGN_BOTTOM_MID, 0, -2);
    if (value) *value = v;
    return c;
}

static lv_obj_t *nav_btn(lv_obj_t *p, const char *t)
{
    lv_obj_t *b = lv_btn_create(p);
    lv_obj_t *l;
    lv_obj_clear_flag(b, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(b, lv_color_hex(0x131925), 0);
    lv_obj_set_style_radius(b, 10, 0);
    lv_obj_set_style_border_width(b, 1, 0);
    lv_obj_set_style_border_color(b, lv_color_hex(0x283142), 0);
    lv_obj_set_style_shadow_width(b, 0, 0);
    lv_obj_set_style_pad_all(b, 0, 0);
    l = lv_label_create(b);
    lv_label_set_text(l, t);
    lv_obj_set_width(l, lv_pct(100));
    lv_label_set_long_mode(l, LV_LABEL_LONG_DOT);
    lv_obj_set_style_text_align(l, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_style_text_font(l, &lv_font_ru_14, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(0xF1F4FA), 0);
    lv_obj_center(l);
    return b;
}

static lv_obj_t *info_line(lv_obj_t *p, const char *t)
{
    lv_obj_t *l = lv_label_create(p);
    lv_label_set_text(l, t);
    lv_obj_set_style_text_font(l, &lv_font_ru_14, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(0xF1F4FA), 0);
    lv_label_set_long_mode(l, LV_LABEL_LONG_DOT);
    return l;
}

static void page_bg(lv_obj_t *p)
{
    lv_obj_set_style_bg_opa(p, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(p, 0, 0);
    lv_obj_set_style_pad_all(p, 0, 0);
    lv_obj_set_scrollbar_mode(p, LV_SCROLLBAR_MODE_OFF);
    lv_obj_clear_flag(p, LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_CLICKABLE);
}

static void show_page(int n)
{
    int i;
    if (s_pages < 1) s_pages = 1;
    if (n < 0) n = 0;
    if (n >= s_pages) n = s_pages - 1;
    for (i = 0; i < PAGE_MAX; ++i) {
        if (i >= s_pages) {
            if (s_page[i]) lv_obj_add_flag(s_page[i], LV_OBJ_FLAG_HIDDEN);
            if (s_nav[i]) lv_obj_add_flag(s_nav[i], LV_OBJ_FLAG_HIDDEN);
            continue;
        }
        if (s_nav[i]) lv_obj_clear_flag(s_nav[i], LV_OBJ_FLAG_HIDDEN);
        if (!s_page[i] || !s_nav[i]) continue;
        if (i == n) lv_obj_clear_flag(s_page[i], LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(s_page[i], LV_OBJ_FLAG_HIDDEN);
        lv_obj_set_style_bg_color(s_nav[i], lv_color_hex(i == n ? sk_on() : sk_card()), 0);
        lv_obj_set_style_border_color(s_nav[i], lv_color_hex(i == n ? sk_on() : sk_line()), 0);
        if (lv_obj_get_child_cnt(s_nav[i]) > 0) {
            lv_obj_set_style_text_color(lv_obj_get_child(s_nav[i], 0),
                                        lv_color_hex(i == n ? sk_ink() : sk_fg()), 0);
        }
    }
    dash_chrome();
}

static void scr_save(void)
{
    nvs_handle_t h;
    if (nvs_open("storage", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u8(h, "scr_cyc", (uint8_t)(s_cycle ? 1 : 0));
    nvs_set_u8(h, "scr_dwell", (uint8_t)s_dwell);
    nvs_set_u8(h, "pg4", (uint8_t)s_cur);
    nvs_commit(h);
    nvs_close(h);
}

static void odo_load(void)
{
    nvs_handle_t h;
    uint32_t v = 0;
    if (nvs_open("storage", NVS_READONLY, &h) != ESP_OK) return;
    if (nvs_get_u32(h, "od_rpm", &v) == ESP_OK) s_tot_rpm = v;
    if (nvs_get_u32(h, "od_gps", &v) == ESP_OK) s_tot_gps = v;
    nvs_close(h);
}

static void odo_save(void)
{
    nvs_handle_t h;
    if (!s_odo_dirty) return;
    if (nvs_open("storage", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u32(h, "od_rpm", s_tot_rpm);
    nvs_set_u32(h, "od_gps", s_tot_gps);
    nvs_commit(h);
    nvs_close(h);
    s_odo_dirty = 0;
}

void ui_dash_load(void)
{
    nvs_handle_t h;
    uint8_t v = 0;
    if (nvs_open("storage", NVS_READONLY, &h) == ESP_OK) {
        if (nvs_get_u8(h, "scr_cyc", &v) == ESP_OK) s_cycle = v ? 1 : 0;
        if (nvs_get_u8(h, "scr_dwell", &v) == ESP_OK && v >= 2 && v <= 60) s_dwell = (int)v;
        if (nvs_get_u8(h, "pg4", &v) == ESP_OK && v < PAGE_MAX) s_cur = (int)v;
        if (nvs_get_u8(h, "scr_skin", &v) == ESP_OK && v <= 2) s_skin = (int)v;
        {
            size_t n = sizeof(s_lay) - 1;
            s_lay[0] = 0;
            if (nvs_get_blob(h, "scr_lay", s_lay, &n) == ESP_OK && n < sizeof(s_lay)) s_lay[n] = 0;
        }
        nvs_close(h);
    }
    odo_load();
    s_turn_us = esp_timer_get_time();
    s_odo_us = s_turn_us;
    s_odo_save_us = s_turn_us;
    if (s_page[0]) ui_dash_fit();
    if (s_cur >= s_pages) s_cur = s_pages - 1;
    show_page(s_cur);
}

void ui_dash_set_cycle(int on)
{
    s_cycle = on ? 1 : 0;
    s_turn_us = esp_timer_get_time();
    scr_save();
}

void ui_dash_set_dwell(int sec)
{
    if (sec < 2) sec = 2;
    if (sec > 60) sec = 60;
    s_dwell = sec;
    scr_save();
}

void ui_dash_set_page(int n)
{
    bool locked;
    if (n < 0) n = 0;
    if (n >= s_pages) n = s_pages - 1;
    s_cur = n;
    s_cycle = 0;
    s_turn_us = esp_timer_get_time();
    locked = display_lock();
    show_page(n);
    if (locked) display_unlock();
    scr_save();
}

int ui_dash_get_skin(void) { return s_skin; }

void ui_dash_set_skin(int skin)
{
    nvs_handle_t h;
    bool locked;
    if (skin < 0) skin = 0;
    if (skin > 2) skin = 2;
    s_skin = skin;
    if (nvs_open("storage", NVS_READWRITE, &h) == ESP_OK) {
        nvs_set_u8(h, "scr_skin", (uint8_t)s_skin);
        nvs_commit(h);
        nvs_close(h);
    }
    locked = display_lock();
    show_page(s_cur);
    if (locked) display_unlock();
}

void ui_dash_set_layout(const char *lay)
{
    nvs_handle_t h;
    bool locked;
    if (!lay) lay = "";
    strncpy(s_lay, lay, sizeof(s_lay) - 1);
    s_lay[sizeof(s_lay) - 1] = 0;
    if (nvs_open("storage", NVS_READWRITE, &h) == ESP_OK) {
        if (s_lay[0]) nvs_set_blob(h, "scr_lay", s_lay, strlen(s_lay));
        else nvs_erase_key(h, "scr_lay");
        nvs_commit(h);
        nvs_close(h);
    }
    locked = display_lock();
    ui_dash_fit();
    show_page(s_cur);
    if (locked) display_unlock();
}

int ui_dash_get_cycle(void) { return s_cycle; }
int ui_dash_get_dwell(void) { return s_dwell; }
int ui_dash_get_page(void) { return s_cur; }

void ui_dash_set_gps10(int kmh_x10)
{
    if (kmh_x10 > 2500) kmh_x10 = 2500;
    s_gps10 = kmh_x10;
    s_gps_us = esp_timer_get_time();
}

static int gps_now(void)
{
    int v = s_gps10;
    int64_t t = s_gps_us;
    if (v < 0) return -1;
    if (t == 0 || esp_timer_get_time() - t > 3000000) return -1;
    return v;
}

void ui_dash_trip(int *gps10, int *peak_bms_ma, int *peak_kmh10,
                  uint32_t *ses_rpm_m, uint32_t *ses_gps_m,
                  uint32_t *tot_rpm_m, uint32_t *tot_gps_m)
{
    if (gps10) *gps10 = gps_now();
    if (peak_bms_ma) *peak_bms_ma = s_peak_ma;
    if (peak_kmh10) *peak_kmh10 = s_peak_kmh10;
    if (ses_rpm_m) *ses_rpm_m = s_ses_rpm;
    if (ses_gps_m) *ses_gps_m = s_ses_gps;
    if (tot_rpm_m) *tot_rpm_m = s_tot_rpm;
    if (tot_gps_m) *tot_gps_m = s_tot_gps;
}

static void paint_tile(lv_obj_t *c, int accent)
{
    uint32_t bg = accent ? sk_on() : sk_card();
    if (!c) return;
    lv_obj_set_style_bg_color(c, lv_color_hex(bg), 0);
    lv_obj_set_style_border_color(c, lv_color_hex(accent ? sk_on() : sk_line()), 0);
    if (lv_obj_get_child_cnt(c) > 0)
        lv_obj_set_style_text_color(lv_obj_get_child(c, 0), lv_color_hex(accent ? sk_ink() : sk_fg()), 0);
    if (lv_obj_get_child_cnt(c) > 1)
        lv_obj_set_style_text_color(lv_obj_get_child(c, 1), lv_color_hex(accent ? sk_ink() : sk_on()), 0);
}

static void paint_ink(lv_obj_t *l)
{
    if (l) lv_obj_set_style_text_color(l, lv_color_hex(sk_fg()), 0);
}

static void dash_chrome(void)
{
    lv_obj_t *scr;
    int i;
    if (!s_page[0]) return;
    scr = lv_obj_get_parent(s_page[0]);
    if (scr) lv_obj_set_style_bg_color(scr, lv_color_hex(sk_bg()), 0);
    paint_tile(s_seat_box, 0);
    paint_tile(s_amb_box, 0);
    paint_tile(s_pwm_box, 1);
    paint_tile(s_v_box, 0);
    paint_tile(s_a_box, 0);
    paint_tile(s_time_box, 0);
    paint_tile(s_proto_box, 1);
    paint_tile(s_watt_box, 0);
    paint_tile(s_reqv_box, 1);
    paint_tile(s_reqa_box, 1);
    paint_tile(s_rel_box, 0);
    paint_tile(s_rpm_box, 0);
    paint_tile(s_gps_box, 0);
    paint_tile(s_cpu_box, 0);
    for (i = 0; i < USER_N; ++i) if (s_user_used[i]) paint_tile(s_user_box[i], 0);
    paint_ink(s_can_line);
    paint_ink(s_spd_num);
    if (s_spd_cap) lv_obj_set_style_text_color(s_spd_cap, lv_color_hex(sk_on()), 0);
    for (i = 0; i < 6; ++i) {
        paint_ink(s_ln[i]);
        paint_ink(s_bat[i]);
    }
    if (s_arc) {
        lv_obj_set_style_arc_color(s_arc, lv_color_hex(sk_line()), LV_PART_MAIN);
        lv_obj_set_style_arc_color(s_arc, lv_color_hex(sk_on()), LV_PART_INDICATOR);
    }
}

static int lay_line(const char *id)
{
    return !strcmp(id, "can") || !strcmp(id, "cap") || !strcmp(id, "spd")
        || id[0] == 'l' || id[0] == 'b';
}

static lv_obj_t *lay_find(const char *id)
{
    if (!strcmp(id, "seat")) return s_seat_box;
    if (!strcmp(id, "amb")) return s_amb_box;
    if (!strcmp(id, "pwm")) return s_pwm_box;
    if (!strcmp(id, "v")) return s_v_box;
    if (!strcmp(id, "a")) return s_a_box;
    if (!strcmp(id, "time")) return s_time_box;
    if (!strcmp(id, "proto")) return s_proto_box;
    if (!strcmp(id, "watt")) return s_watt_box;
    if (!strcmp(id, "reqv")) return s_reqv_box;
    if (!strcmp(id, "reqa")) return s_reqa_box;
    if (!strcmp(id, "rel")) return s_rel_box;
    if (!strcmp(id, "can")) return s_can_line;
    if (!strcmp(id, "arc")) return s_arc;
    if (!strcmp(id, "spd")) return s_spd_num;
    if (!strcmp(id, "cap")) return s_spd_cap;
    if (!strcmp(id, "rpm")) return s_rpm_box;
    if (!strcmp(id, "gps")) return s_gps_box;
    if (!strcmp(id, "cpu")) return s_cpu_box;
    if (id[0] == 'c' && id[1] >= '0' && id[1] <= '4' && id[2] == 0) return s_cell[id[1] - '0'];
    if (id[0] == 'l' && id[1] >= '0' && id[1] <= '5' && id[2] == 0) return s_ln[id[1] - '0'];
    if (id[0] == 'b' && id[1] >= '0' && id[1] <= '5' && id[2] == 0) return s_bat[id[1] - '0'];
    return NULL;
}


static void place_nav(void)
{
    int i;
    int bw;
    int hor = s_hor;
    int ver = s_ver;
    int n = s_pages < 1 ? 1 : s_pages;
    if (hor < 80 || ver < 80) return;
    bw = (hor - 6) / n;
    if (bw < 18) bw = 18;
    for (i = 0; i < PAGE_MAX; ++i) {
        if (!s_nav[i]) continue;
        if (i >= s_pages) {
            lv_obj_add_flag(s_nav[i], LV_OBJ_FLAG_HIDDEN);
            continue;
        }
        lv_obj_clear_flag(s_nav[i], LV_OBJ_FLAG_HIDDEN);
        lv_obj_set_pos(s_nav[i], 2 + i * bw, ver - NAV_H + 1);
        lv_obj_set_size(s_nav[i], bw - 2, NAV_H - 3);
    }
}

static void lay_reset_custom(void)
{
    static const char *stock[] = {"КАБ", "СТАН", "СКОР", "ПУТЬ", "АКБ"};
    int i;
    s_pages = 5;
    for (i = 0; i < 5; ++i) {
        strncpy(s_nav_name[i], stock[i], sizeof(s_nav_name[i]) - 1);
        s_nav_name[i][sizeof(s_nav_name[i]) - 1] = 0;
        if (s_nav[i] && lv_obj_get_child_cnt(s_nav[i]) > 0)
            lv_label_set_text(lv_obj_get_child(s_nav[i], 0), s_nav_name[i]);
    }
    for (i = 5; i < PAGE_MAX; ++i) {
        s_nav_name[i][0] = 0;
        if (s_nav[i]) lv_obj_add_flag(s_nav[i], LV_OBJ_FLAG_HIDDEN);
    }
    for (i = 0; i < USER_N; ++i) {
        s_user_used[i] = 0;
        s_user_src[i][0] = 0;
        s_user_page[i] = 0;
        if (s_user_box[i]) lv_obj_add_flag(s_user_box[i], LV_OBJ_FLAG_HIDDEN);
    }
}

static void lay_set_name(int idx, const char *name)
{
    if (idx < 5 || idx >= PAGE_MAX || !name || !name[0]) return;
    strncpy(s_nav_name[idx], name, sizeof(s_nav_name[idx]) - 1);
    s_nav_name[idx][sizeof(s_nav_name[idx]) - 1] = 0;
    if (idx + 1 > s_pages) s_pages = idx + 1;
    if (s_nav[idx] && lv_obj_get_child_cnt(s_nav[idx]) > 0)
        lv_label_set_text(lv_obj_get_child(s_nav[idx], 0), s_nav_name[idx]);
}

static lv_obj_t *src_label(const char *id)
{
    if (!id || !id[0]) return NULL;
    if (!strcmp(id, "v")) return s_out_v;
    if (!strcmp(id, "a")) return s_out_a;
    if (!strcmp(id, "time")) return s_time;
    if (!strcmp(id, "proto")) return s_proto;
    if (!strcmp(id, "watt")) return s_watt;
    if (!strcmp(id, "reqv")) return s_req_v;
    if (!strcmp(id, "reqa")) return s_req_a;
    if (!strcmp(id, "rel")) return s_relay;
    if (!strcmp(id, "seat")) return s_seat;
    if (!strcmp(id, "amb")) return s_amb;
    if (!strcmp(id, "pwm")) return s_pwm;
    if (!strcmp(id, "rpm")) return s_rpm_v;
    if (!strcmp(id, "gps")) return s_gps_v;
    if (!strcmp(id, "cpu")) return s_cpu;
    if (!strcmp(id, "spd")) return s_spd_num;
    if (!strcmp(id, "can")) return s_can_line;
    if (id[0] == 'l' && id[1] >= '0' && id[1] <= '5' && id[2] == 0) return s_ln[id[1] - '0'];
    if (id[0] == 'b' && id[1] >= '0' && id[1] <= '5' && id[2] == 0) return s_bat[id[1] - '0'];
    return NULL;
}

static const char *src_cap(const char *id)
{
    if (!id) return "";
    if (!strcmp(id, "v")) return "выход В";
    if (!strcmp(id, "a")) return "выход А";
    if (!strcmp(id, "time")) return "время";
    if (!strcmp(id, "proto")) return "протокол";
    if (!strcmp(id, "watt")) return "ватт";
    if (!strcmp(id, "reqv")) return "запрос В";
    if (!strcmp(id, "reqa")) return "запрос А";
    if (!strcmp(id, "rel")) return "реле";
    if (!strcmp(id, "seat")) return "коврик";
    if (!strcmp(id, "amb")) return "улица";
    if (!strcmp(id, "pwm")) return "ШИМ";
    if (!strcmp(id, "rpm")) return "обороты";
    if (!strcmp(id, "gps")) return "GPS";
    if (!strcmp(id, "cpu")) return "процессор";
    if (!strcmp(id, "spd")) return "скорость";
    if (!strcmp(id, "can")) return "CAN";
    if (!strcmp(id, "l0")) return "пик АКБ";
    if (!strcmp(id, "l1")) return "пик мотора";
    if (!strcmp(id, "l2")) return "макс км/ч";
    if (!strcmp(id, "l3")) return "сессия";
    if (!strcmp(id, "l4")) return "GPS путь";
    if (!strcmp(id, "l5")) return "всего";
    if (!strcmp(id, "b0")) return "сейчас";
    if (!strcmp(id, "b1")) return "ток";
    if (!strcmp(id, "b2")) return "пик";
    if (!strcmp(id, "b3")) return "макс";
    if (!strcmp(id, "b4")) return "мин";
    if (!strcmp(id, "b5")) return "осталось";
    if (id[0] == 'l') return "путь";
    return id;
}

static void paint_users(void)
{
    int i;
    for (i = 0; i < USER_N; ++i) {
        lv_obj_t *src;
        if (!s_user_used[i] || !s_user_val[i]) continue;
        src = src_label(s_user_src[i]);
        if (src) lv_label_set_text(s_user_val[i], lv_label_get_text(src));
    }
}

static void lay_override(void)
{
    const char *p;
    lay_reset_custom();
    if (!s_lay[0]) {
        place_nav();
        return;
    }
    p = s_lay;
    while (*p) {
        char id[12];
        int x = 0, y = 0, w = 0, h = 0, n = 0, i = 0;
        lv_obj_t *o;
        while (*p && *p != ':' && *p != ';' && i < 11) id[i++] = *p++;
        id[i] = 0;
        if (*p == ':') p++;
        if (id[0] == '#' && id[1]) {
            char name[16];
            int k = 0;
            int idx = atoi(id + 1);
            while (*p && *p != ';' && k < 15) name[k++] = *p++;
            name[k] = 0;
            lay_set_name(idx, name);
            if (*p == ';') p++;
            continue;
        }
        if (sscanf(p, "%d,%d,%d,%d%n", &x, &y, &w, &h, &n) >= 4 && n > 0) {
            p += n;
            if (id[0] == 'u' && id[1] >= '0' && id[1] <= '7' && id[2] == 0) {
                int ui = id[1] - '0';
                int pg = 0;
                char src[8];
                int si = 0;
                src[0] = 0;
                if (*p == ',') {
                    p++;
                    pg = atoi(p);
                    while (*p && *p != ',' && *p != ';') p++;
                }
                if (*p == ',') {
                    p++;
                    while (*p && *p != ';' && *p != ',' && si < 7) src[si++] = *p++;
                    src[si] = 0;
                }
                if (pg < 0) pg = 0;
                if (pg >= PAGE_MAX) pg = PAGE_MAX - 1;
                if (pg >= 5 && pg + 1 > s_pages && s_nav_name[pg][0] == 0) {
                    snprintf(s_nav_name[pg], sizeof(s_nav_name[pg]), "%d", pg + 1);
                    if (s_nav[pg] && lv_obj_get_child_cnt(s_nav[pg]) > 0)
                        lv_label_set_text(lv_obj_get_child(s_nav[pg], 0), s_nav_name[pg]);
                }
                if (pg + 1 > s_pages) s_pages = pg + 1;
                s_user_used[ui] = 1;
                s_user_page[ui] = pg;
                strncpy(s_user_src[ui], src, sizeof(s_user_src[ui]) - 1);
                s_user_src[ui][sizeof(s_user_src[ui]) - 1] = 0;
                if (s_user_box[ui] && s_page[pg]) {
                    lv_obj_set_parent(s_user_box[ui], s_page[pg]);
                    lv_obj_clear_flag(s_user_box[ui], LV_OBJ_FLAG_HIDDEN);
                    box_at(s_user_box[ui], x, y, w, h);
                    if (lv_obj_get_child_cnt(s_user_box[ui]) > 1)
                        lv_label_set_text(lv_obj_get_child(s_user_box[ui], 1), src_cap(src));
                    paint_tile(s_user_box[ui], 0);
                }
            } else {
                o = lay_find(id);
                if (o && x >= 0 && y >= 0 && w >= 8 && w <= 400 && h >= 8 && h <= 400) {
                    if (lay_line(id)) line_at(o, x, y, w);
                    else box_at(o, x, y, w, h);
                }
            }
        }
        while (*p && *p != ';') p++;
        if (*p == ';') p++;
    }
    place_nav();
    if (s_cur >= s_pages) s_cur = s_pages - 1;
}


static void place_cells(int x, int y, int w, int h)
{
    int i;
    int gap = 3;
    int cw = (w - gap * (REL_N - 1)) / REL_N;
    if (cw < 28) cw = 28;
    for (i = 0; i < REL_N; ++i) box_at(s_cell[i], x + i * (cw + gap), y, cw, h);
}

static void layout(int hor, int ver)
{
    int ch = ver - NAV_H;
    int land = hor > ver;
    int i;
    int y;
    int gap = 4;
    if (ch < 100) ch = 100;
    s_hor = hor;
    s_ver = ver;
    for (i = 0; i < PAGE_MAX; ++i) {
        if (!s_page[i]) continue;
        lv_obj_set_pos(s_page[i], 0, 0);
        lv_obj_set_size(s_page[i], hor, ch);
        lv_obj_clear_flag(s_page[i], LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_scrollbar_mode(s_page[i], LV_SCROLLBAR_MODE_OFF);
    }
    place_nav();
    if (!land) {
        int th = (ch - gap * 4) / 3;
        if (th > 92) th = 92;
        if (th < 64) th = 64;
        box_at(s_seat_box, 4, 4, hor - 8, th);
        box_at(s_amb_box, 4, 8 + th, hor - 8, th);
        box_at(s_pwm_box, 4, 12 + th * 2, hor - 8, th);
    } else {
        int tw = (hor - 16) / 3;
        box_at(s_seat_box, 4, 4, tw, ch - 8);
        box_at(s_amb_box, 8 + tw, 4, tw, ch - 8);
        box_at(s_pwm_box, 12 + tw * 2, 4, tw, ch - 8);
    }
    if (!land) {
        int vw = (hor - 12) / 2;
        int vh = ch > 260 ? 104 : 86;
        int rw = (hor - 16) / 3;
        int rh = 46;
        y = 4 + vh + 4;
        box_at(s_v_box, 4, 4, vw, vh);
        box_at(s_a_box, 8 + vw, 4, vw, vh);
        box_at(s_time_box, 4, y, rw, rh);
        box_at(s_proto_box, 8 + rw, y, rw, rh);
        box_at(s_watt_box, 12 + rw * 2, y, rw, rh);
        y += rh + 4;
        box_at(s_reqv_box, 4, y, rw, rh);
        box_at(s_reqa_box, 8 + rw, y, rw, rh);
        box_at(s_rel_box, 12 + rw * 2, y, rw, rh);
        y += rh + 4;
        line_at(s_can_line, 6, y, hor - 12);
    } else {
        int vw = (hor - 12) / 2;
        int vh = 70;
        int rw = (hor - 16) / 3;
        int rh = 40;
        y = 4 + vh + 3;
        box_at(s_v_box, 4, 3, vw, vh);
        box_at(s_a_box, 8 + vw, 3, vw, vh);
        box_at(s_time_box, 4, y, rw, rh);
        box_at(s_proto_box, 8 + rw, y, rw, rh);
        box_at(s_watt_box, 12 + rw * 2, y, rw, rh);
        y += rh + 3;
        box_at(s_reqv_box, 4, y, rw, rh);
        box_at(s_reqa_box, 8 + rw, y, rw, rh);
        box_at(s_rel_box, 12 + rw * 2, y, rw, rh);
        y += rh + 2;
        line_at(s_can_line, 6, y, hor - 12);
    }
    if (!land) {
        int arc = 156;
        int tw;
        int ty;
        if (arc > hor - 16) arc = hor - 16;
        if (arc > ch - 96) arc = ch - 96;
        box_at(s_arc, (hor - arc) / 2, 2, arc, arc);
        if (s_spd_num) {
            lv_obj_set_width(s_spd_num, arc - 24);
            lv_obj_set_pos(s_spd_num, (hor - (arc - 24)) / 2, 2 + arc / 2 - 22);
        }
        if (s_spd_cap) {
            lv_obj_set_width(s_spd_cap, arc - 16);
            lv_obj_set_pos(s_spd_cap, (hor - (arc - 16)) / 2, 2 + arc / 2 + 8);
        }
        ty = 8 + arc;
        tw = (hor - 12) / 2;
        box_at(s_rpm_box, 4, ty, tw, ch - ty - 4);
        box_at(s_gps_box, 8 + tw, ty, tw, ch - ty - 4);
    } else {
        int arc = ch - 8;
        int x;
        int th;
        if (arc > 188) arc = 188;
        box_at(s_arc, 4, 4, arc, arc);
        if (s_spd_num) {
            lv_obj_set_width(s_spd_num, arc - 28);
            lv_obj_set_pos(s_spd_num, 4 + 14, 4 + arc / 2 - 22);
        }
        if (s_spd_cap) {
            lv_obj_set_width(s_spd_cap, arc - 20);
            lv_obj_set_pos(s_spd_cap, 4 + 10, 4 + arc / 2 + 8);
        }
        x = 12 + arc;
        th = (ch - 12) / 2;
        box_at(s_rpm_box, x, 4, hor - x - 4, th);
        box_at(s_gps_box, x, 8 + th, hor - x - 4, th);
    }
    if (!land) {
        int top = 72;
        int step;
        box_at(s_cpu_box, 4, 4, hor - 8, top - 8);
        place_cells(4, top, hor - 8, 40);
        y = top + 46;
        step = (ch - y - 4) / 6;
        if (step > 26) step = 26;
        if (step < 16) step = 16;
        for (i = 0; i < 6; ++i) line_at(s_ln[i], 6, y + i * step, hor - 12);
    } else {
        int col = (hor - 16) / 2;
        int step;
        box_at(s_cpu_box, 4, 2, hor - 8, 44);
        place_cells(4, 50, hor - 8, 34);
        y = 90;
        step = (ch - y - 2) / 3;
        if (step > 28) step = 28;
        if (step < 16) step = 16;
        for (i = 0; i < 3; ++i) {
            line_at(s_ln[i], 6, y + i * step, col);
            line_at(s_ln[i + 3], 10 + col, y + i * step, col);
        }
    }
    {
        int by = 8;
        int bstep = (ch - 16) / 6;
        if (bstep > 40) bstep = 40;
        if (bstep < 18) bstep = 18;
        for (i = 0; i < 6; ++i) line_at(s_bat[i], 8, by + i * bstep, hor - 16);
    }
    lay_override();
}

void ui_dash_fit(void)
{
    lv_disp_t *d = lv_disp_get_default();
    lv_coord_t hor;
    lv_coord_t ver;
    lv_obj_t *scr;
    if (!d || !s_page[0] || !s_nav[0]) return;
    hor = lv_disp_get_hor_res(d);
    ver = lv_disp_get_ver_res(d);
    if (hor < 80 || ver < 80) return;
    scr = lv_obj_get_parent(s_page[0]);
    if (scr) {
        lv_obj_clear_flag(scr, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_scrollbar_mode(scr, LV_SCROLLBAR_MODE_OFF);
    }
    layout((int)hor, (int)ver);
}

void ui_dash_build(lv_obj_t *scr)
{
    int i;
    const char *nav[] = {"КАБ", "СТАН", "СКОР", "ПУТЬ", "АКБ"};
    lv_obj_set_style_bg_color(scr, lv_color_hex(0x090C12), 0);
    lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, 0);
    lv_obj_clear_flag(scr, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_scrollbar_mode(scr, LV_SCROLLBAR_MODE_OFF);
    for (i = 0; i < PAGE_MAX; ++i) {
        s_page[i] = lv_obj_create(scr);
        page_bg(s_page[i]);
        if (i >= 5) lv_obj_add_flag(s_page[i], LV_OBJ_FLAG_HIDDEN);
    }
    s_seat_box = tile(s_page[0], 0x131925, 0xF1F4FA, "коврик C", &s_seat, "--", &lv_font_montserrat_28);
    s_amb_box = tile(s_page[0], 0x131925, 0xF1F4FA, "улица C", &s_amb, "--", &lv_font_montserrat_28);
    s_pwm_box = tile(s_page[0], 0xFFB02E, 0x1A1205, "ШИМ %", &s_pwm, "0", &lv_font_montserrat_28);

    s_v_box = tile(s_page[1], 0x131925, 0xF1F4FA, "выход В", &s_out_v, "0", &lv_font_montserrat_28);
    s_a_box = tile(s_page[1], 0x131925, 0xF1F4FA, "выход А", &s_out_a, "0", &lv_font_montserrat_28);
    s_time_box = tile(s_page[1], 0x131925, 0xF1F4FA, "время", &s_time, "00:00", &lv_font_ru_14);
    s_proto_box = tile(s_page[1], 0xFFB02E, 0x1A1205, "протокол", &s_proto, "авто", &lv_font_ru_14);
    s_watt_box = tile(s_page[1], 0x131925, 0xF1F4FA, "ватт", &s_watt, "0", &lv_font_ru_14);
    s_reqv_box = tile(s_page[1], 0xFFB02E, 0x1A1205, "запрос В", &s_req_v, "240", &lv_font_ru_14);
    s_reqa_box = tile(s_page[1], 0xFFB02E, 0x1A1205, "запрос А", &s_req_a, "50", &lv_font_ru_14);
    s_rel_box = tile(s_page[1], 0x131925, 0xF1F4FA, "реле", &s_relay, "выкл", &lv_font_ru_14);
    s_can_line = info_line(s_page[1], "CAN: жду станцию");

    s_arc = lv_arc_create(s_page[2]);
    lv_arc_set_rotation(s_arc, 135);
    lv_arc_set_bg_angles(s_arc, 0, 270);
    lv_arc_set_range(s_arc, 0, 100);
    lv_arc_set_value(s_arc, 0);
    lv_obj_remove_style(s_arc, NULL, LV_PART_KNOB);
    lv_obj_clear_flag(s_arc, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_style_arc_width(s_arc, 12, LV_PART_MAIN);
    lv_obj_set_style_arc_width(s_arc, 12, LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(s_arc, lv_color_hex(0x1B2332), LV_PART_MAIN);
    lv_obj_set_style_arc_color(s_arc, lv_color_hex(0xFFB02E), LV_PART_INDICATOR);
    lv_obj_set_style_arc_rounded(s_arc, true, LV_PART_MAIN);
    lv_obj_set_style_arc_rounded(s_arc, true, LV_PART_INDICATOR);
    lv_obj_set_style_bg_opa(s_arc, LV_OPA_TRANSP, 0);
    lv_obj_set_style_pad_all(s_arc, 0, 0);
    s_spd_num = lv_label_create(s_page[2]);
    lv_label_set_text(s_spd_num, "0.0");
    lv_obj_set_style_text_font(s_spd_num, &lv_font_montserrat_28, 0);
    lv_obj_set_style_text_color(s_spd_num, lv_color_hex(0xF1F4FA), 0);
    lv_obj_set_style_text_align(s_spd_num, LV_TEXT_ALIGN_CENTER, 0);
    s_spd_cap = info_line(s_page[2], "обороты");
    lv_obj_set_style_text_align(s_spd_cap, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_style_text_color(s_spd_cap, lv_color_hex(0xFFB02E), 0);
    s_rpm_box = tile(s_page[2], 0x131925, 0xF1F4FA, "обороты", &s_rpm_v, "0.0", &lv_font_montserrat_28);
    s_gps_box = tile(s_page[2], 0x131925, 0xF1F4FA, "GPS нет", &s_gps_v, "--", &lv_font_montserrat_28);

    s_cpu_box = tile(s_page[3], 0x131925, 0xF1F4FA, "процессор C", &s_cpu, "--", &lv_font_montserrat_28);
    for (i = 0; i < REL_N; ++i) {
        lv_obj_t *l;
        s_cell[i] = lv_obj_create(s_page[3]);
        lv_obj_set_style_bg_color(s_cell[i], lv_color_hex(0x131925), 0);
        lv_obj_set_style_bg_opa(s_cell[i], LV_OPA_COVER, 0);
        lv_obj_set_style_radius(s_cell[i], 8, 0);
        lv_obj_set_style_border_width(s_cell[i], 1, 0);
        lv_obj_set_style_border_color(s_cell[i], lv_color_hex(0x283142), 0);
        lv_obj_set_style_pad_all(s_cell[i], 0, 0);
        lv_obj_clear_flag(s_cell[i], LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_CLICKABLE);
        l = lv_label_create(s_cell[i]);
        lv_label_set_text(l, k_rel_name[i]);
        lv_obj_set_width(l, lv_pct(100));
        lv_label_set_long_mode(l, LV_LABEL_LONG_DOT);
        lv_obj_set_style_text_align(l, LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_set_style_text_font(l, &lv_font_ru_14, 0);
        lv_obj_set_style_text_color(l, lv_color_hex(0x8E99AE), 0);
        lv_obj_center(l);
    }
    s_ln[0] = info_line(s_page[3], "пик АКБ 0.0 А");
    s_ln[1] = info_line(s_page[3], "пик мотора 0.0 А");
    s_ln[2] = info_line(s_page[3], "макс 0.0 км/ч");
    s_ln[3] = info_line(s_page[3], "сессия об 0.00 км");
    s_ln[4] = info_line(s_page[3], "сессия GPS 0.00 км");
    s_ln[5] = info_line(s_page[3], "всего 0.00 / 0.00");
    s_bat[0] = info_line(s_page[4], "сейчас 0.0 В");
    s_bat[1] = info_line(s_page[4], "ток 0.00 А");
    s_bat[2] = info_line(s_page[4], "пик сессии 0.00 А");
    s_bat[3] = info_line(s_page[4], "макс 0.0 В");
    s_bat[4] = info_line(s_page[4], "мин 0.0 В");
    s_bat[5] = info_line(s_page[4], "осталось 0.00 / после 0.00 Ач");
    for (i = 0; i < 5; ++i) s_nav[i] = nav_btn(scr, nav[i]);
    for (i = 5; i < PAGE_MAX; ++i) {
        s_nav[i] = nav_btn(scr, "•");
        lv_obj_add_flag(s_nav[i], LV_OBJ_FLAG_HIDDEN);
    }
    for (i = 0; i < USER_N; ++i) {
        s_user_box[i] = tile(s_page[0], 0x131925, 0xF1F4FA, " ", &s_user_val[i], "--", &lv_font_ru_14);
        lv_obj_add_flag(s_user_box[i], LV_OBJ_FLAG_HIDDEN);
    }
    show_page(0);
    ui_dash_fit();
    ui_dash_load();
}

static const char *proto_name(uint8_t p)
{
    if (p == 1) return "2015/A";
    if (p == 2) return "2011";
    if (p == 3) return "2023-B";
    return "авто";
}

static void km_txt(char *out, size_t cap, uint32_t meters)
{
    unsigned whole = meters / 1000u;
    unsigned frac = (meters % 1000u) / 10u;
    snprintf(out, cap, "%u.%02u", whole, frac);
}

static void add_m(uint32_t *ses, uint32_t *tot, uint32_t *rem, int kmh10, int64_t dt)
{
    uint64_t num;
    uint32_t add;
    if (kmh10 <= 0 || dt <= 0 || dt > 2000000) return;
    num = (uint64_t)kmh10 * (uint64_t)dt + *rem;
    add = (uint32_t)(num / 36000000ULL);
    *rem = (uint32_t)(num % 36000000ULL);
    if (!add) return;
    *ses += add;
    *tot += add;
    s_odo_dirty = 1;
}

static void temp_txt(char *b, size_t n, lv_obj_t *lab, int c01)
{
    int v;
    int neg;
    if (!lab) return;
    if (c01 == CABIN_NO_TEMP) {
        lv_obj_set_style_text_font(lab, &lv_font_montserrat_28, 0);
        lv_label_set_text(lab, "--");
        return;
    }
    neg = c01 < 0;
    v = neg ? -c01 : c01;
    lv_obj_set_style_text_font(lab, &lv_font_montserrat_28, 0);
    if (neg) snprintf(b, n, "-%d.%d", v / 100, (v / 10) % 10);
    else snprintf(b, n, "%d.%d", v / 100, (v / 10) % 10);
    lv_label_set_text(lab, b);
}

static int x10_txt(char *b, size_t n, int v)
{
    int neg = v < 0;
    if (neg) v = -v;
    snprintf(b, n, "%s%d.%d", neg ? "-" : "", v / 10, v % 10);
    return v;
}

static void paint_relays(const cube_state_snapshot_t *st)
{
    int i;
    for (i = 0; i < REL_N; ++i) {
        int on = 0;
        int logical;
        lv_obj_t *l;
        if (!s_cell[i]) continue;
        logical = cabin_gpio_on(k_rel_gpio[i]);
        if (logical >= 0) on = logical;
        else if (k_rel_gpio[i] == CUBE_RELAY_A_GPIO) on = st && st->relay_a;
        else if (k_rel_gpio[i] == CUBE_RELAY_B_GPIO || k_rel_gpio[i] == REL_PAR_GPIO) on = st && st->relay_b;
        else if (k_rel_gpio[i] >= 0 && gpio_get_level(k_rel_gpio[i]) == 0) on = 1;
        lv_obj_set_style_bg_color(s_cell[i], lv_color_hex(on ? sk_on() : sk_card()), 0);
        lv_obj_set_style_border_color(s_cell[i], lv_color_hex(on ? sk_on() : sk_line()), 0);
        if (lv_obj_get_child_cnt(s_cell[i]) > 0) {
            l = lv_obj_get_child(s_cell[i], 0);
            lv_obj_set_style_text_color(l, lv_color_hex(on ? sk_ink() : sk_muted()), 0);
        }
    }
}

static void paint_trip(int max_amps)
{
    char km[16];
    char b[48];
    int ma = s_peak_ma < 0 ? -s_peak_ma : s_peak_ma;
    if (s_ln[0]) {
        snprintf(b, sizeof(b), "пик АКБ %d.%02d А", ma / 1000, (ma / 10) % 100);
        lv_label_set_text(s_ln[0], b);
    }
    if (s_ln[1]) {
        int a = max_amps < 0 ? -max_amps : max_amps;
        snprintf(b, sizeof(b), "пик мотора %d.%d А", a / 10, a % 10);
        lv_label_set_text(s_ln[1], b);
    }
    if (s_ln[2]) {
        x10_txt(km, sizeof(km), s_peak_kmh10);
        snprintf(b, sizeof(b), "макс %s км/ч", km);
        lv_label_set_text(s_ln[2], b);
    }
    if (s_ln[3]) {
        km_txt(km, sizeof(km), s_ses_rpm);
        snprintf(b, sizeof(b), "сессия об %s км", km);
        lv_label_set_text(s_ln[3], b);
    }
    if (s_ln[4]) {
        km_txt(km, sizeof(km), s_ses_gps);
        snprintf(b, sizeof(b), "сессия GPS %s км", km);
        lv_label_set_text(s_ln[4], b);
    }
    if (s_ln[5]) {
        char g[16];
        km_txt(km, sizeof(km), s_tot_rpm);
        km_txt(g, sizeof(g), s_tot_gps);
        snprintf(b, sizeof(b), "всего %s / %s", km, g);
        lv_label_set_text(s_ln[5], b);
    }
}

void ui_dash_tick(void)
{
    cube_state_snapshot_t st;
    bms_link_t A;
    cabin_view_t cab;
    char b[64];
    uint32_t now;
    uint32_t sec;
    int rpm = 0;
    int kmh = 0;
    int link = 0;
    int max_rpm = 0;
    int amps_x10 = 0;
    int max_amps = 0;
    int volts_x10 = 0;
    int err_bits = 0;
    int gps;
    int show;
    int arc;
    int64_t tnow;
    int64_t dt;
    float uv;
    float ia;
    int live;

    app_state_snapshot(&st);
    gbt_can_probe_poll();
    now = (uint32_t)(esp_timer_get_time() / 1000ULL);
    if (st.session_active && now >= st.session_start_ms) sec = (now - st.session_start_ms) / 1000u;
    else sec = 0;
    if (s_time) {
        snprintf(b, sizeof(b), "%02u:%02u:%02u",
                 (unsigned)(sec / 3600u), (unsigned)((sec / 60u) % 60u), (unsigned)(sec % 60u));
        lv_label_set_text(s_time, b);
    }
    if (s_relay) {
        const char *r = "выкл";
        if (st.relay_a && !st.relay_b) r = "имит";
        else if (st.relay_b) r = "акб";
        lv_label_set_text(s_relay, r);
    }
    if (s_proto) lv_label_set_text(s_proto, proto_name(st.protocol));
    if (s_can_line) {
        const char *wire = gbt_can_wire_result();
        const char *m = "жду станцию";
        int talk = st.last_charger_rx_ms != 0 && (now - st.last_charger_rx_ms) < 1500u;
        if (wire[0]) m = wire;
        else if (st.main_state == ST_CHARGING) m = "идёт заряд";
        else if (st.main_state == ST_READY_WAIT_CRO) m = "ждём готовность станции";
        else if (st.main_state == ST_PARAM_CONFIG) m = "согласуем заряд";
        else if (st.crm_status == 0xAA && st.last_crm_ms != 0 && (now - st.last_crm_ms) < 5000u) m = "батарея узнана";
        else if (st.last_crm_ms != 0 && (now - st.last_crm_ms) < 5000u)
            m = st.relay_a ? "поиск, имитация вкл" : "станция ищет батарею";
        else if (talk && st.relay_a) m = "имитация включена";
        else if (talk && st.tx_count == 0) m = "кадр куба не принят";
        else if (talk) m = "куб отвечает станции";
        snprintf(b, sizeof(b), "CAN: %s", m);
        lv_label_set_text(s_can_line, b);
    }
    if (s_req_v) {
        int v = st.bcl_requested_voltage_raw / 10;
        if (v < 1) v = 240;
        snprintf(b, sizeof(b), "%d", v);
        lv_label_set_text(s_req_v, b);
    }
    if (s_req_a) {
        int a = st.bcl_requested_current_0p1a;
        if (a < 0) a = -a;
        a /= 10;
        if (a < 1) a = 50;
        snprintf(b, sizeof(b), "%d", a);
        lv_label_set_text(s_req_a, b);
    }
    live = st.ccs_output_voltage_raw > 0;
    uv = live ? st.ccs_output_voltage_raw / 10.0f : 0;
    ia = st.ccs_output_current_0p1a / 10.0f;
    if (ia < 0) ia = -ia;
    if (s_out_v) {
        snprintf(b, sizeof(b), "%.0f", (double)uv);
        lv_label_set_text(s_out_v, b);
    }
    if (s_out_a) {
        snprintf(b, sizeof(b), "%.0f", (double)ia);
        lv_label_set_text(s_out_a, b);
    }
    if (s_watt) {
        snprintf(b, sizeof(b), "%.0f", (double)(uv * ia));
        lv_label_set_text(s_watt, b);
    }

    cabin_view(&cab);
    temp_txt(b, sizeof(b), s_seat, cab.seat);
    temp_txt(b, sizeof(b), s_amb, cab.amb);
    if (s_pwm) {
        snprintf(b, sizeof(b), "%d", cab.duty < 0 ? 0 : cab.duty);
        lv_label_set_text(s_pwm, b);
    }

    fardriver_stats(&rpm, &kmh, &link, &max_rpm);
    fardriver_power(&amps_x10, &max_amps, &volts_x10, &err_bits);
    (void)rpm;
    (void)max_rpm;
    (void)amps_x10;
    (void)volts_x10;
    (void)err_bits;
    show = 0;
    if (link) show = kmh < 0 ? -kmh : kmh;
    x10_txt(b, sizeof(b), show);
    if (s_spd_num) lv_label_set_text(s_spd_num, b);
    if (s_rpm_v) lv_label_set_text(s_rpm_v, b);
    arc = show / 8;
    if (arc > 100) arc = 100;
    if (s_arc) {
        lv_arc_set_value(s_arc, arc);
        lv_obj_set_style_arc_color(s_arc, lv_color_hex(show > 0 ? 0xFFB02E : 0x3A4458), LV_PART_INDICATOR);
    }
    gps = gps_now();
    if (s_gps_v) {
        if (gps < 0) lv_label_set_text(s_gps_v, "--");
        else {
            x10_txt(b, sizeof(b), gps);
            lv_label_set_text(s_gps_v, b);
        }
    }
    if (s_gps_box && lv_obj_get_child_cnt(s_gps_box) > 1) {
        lv_label_set_text(lv_obj_get_child(s_gps_box, 1), gps < 0 ? "GPS нет" : "GPS");
    }

    bms_link_get(0, &A);
    if (A.ok) {
        int a = A.ma < 0 ? -A.ma : A.ma;
        if (a > s_peak_ma) s_peak_ma = a;
    }
    if (show > s_peak_kmh10) s_peak_kmh10 = show;
    if (gps > s_peak_kmh10) s_peak_kmh10 = gps;

    tnow = esp_timer_get_time();
    dt = s_odo_us ? tnow - s_odo_us : 0;
    s_odo_us = tnow;
    add_m(&s_ses_rpm, &s_tot_rpm, &s_rem_rpm, link ? show : 0, dt);
    add_m(&s_ses_gps, &s_tot_gps, &s_rem_gps, gps > 0 ? gps : 0, dt);
    if (s_odo_dirty && tnow - s_odo_save_us > 30000000LL) {
        odo_save();
        s_odo_save_us = tnow;
    }

    if (s_cpu) {
        int c = display_cpu_c();
        if (c < -40) lv_label_set_text(s_cpu, "--");
        else {
            snprintf(b, sizeof(b), "%d", c);
            lv_label_set_text(s_cpu, b);
        }
    }
    if (A.ok) {
        int aabs = A.ma < 0 ? -A.ma : A.ma;
        int mah = A.remain_mah > 0 ? A.remain_mah : (A.full_mah > 0 && A.soc > 0 ? A.full_mah * A.soc / 100 : 0);
        if (s_vmax_mv == 0 || A.mv > s_vmax_mv) s_vmax_mv = A.mv;
        if (s_vmin_mv == 0 || A.mv < s_vmin_mv) s_vmin_mv = A.mv;
        if (A.ma < -200) s_after_mah = mah;
        if (s_bat[0]) { snprintf(b, sizeof(b), "сейчас %d.%d В", A.mv / 1000, (A.mv / 100) % 10); lv_label_set_text(s_bat[0], b); }
        if (s_bat[1]) { snprintf(b, sizeof(b), "ток %s%d.%02d А", A.ma < 0 ? "-" : "", aabs / 1000, (aabs / 10) % 100); lv_label_set_text(s_bat[1], b); }
        if (s_bat[2]) { snprintf(b, sizeof(b), "пик сессии %d.%02d А", s_peak_ma / 1000, (s_peak_ma / 10) % 100); lv_label_set_text(s_bat[2], b); }
        if (s_bat[3]) { snprintf(b, sizeof(b), "макс %d.%d В", s_vmax_mv / 1000, (s_vmax_mv / 100) % 10); lv_label_set_text(s_bat[3], b); }
        if (s_bat[4]) { snprintf(b, sizeof(b), "мин %d.%d В", s_vmin_mv / 1000, (s_vmin_mv / 100) % 10); lv_label_set_text(s_bat[4], b); }
        if (s_bat[5]) { snprintf(b, sizeof(b), "осталось %d.%02d / после %d.%02d Ач", mah / 1000, (mah / 10) % 100, s_after_mah / 1000, (s_after_mah / 10) % 100); lv_label_set_text(s_bat[5], b); }
    } else if (s_bat[0] && s_vmax_mv == 0) {
        lv_label_set_text(s_bat[0], "нет связи с АКБ");
    }
    paint_relays(&st);
    paint_trip(max_amps);
    paint_users();

    if (s_cycle) {
        if (s_turn_us == 0) s_turn_us = tnow;
        if (tnow - s_turn_us >= (int64_t)s_dwell * 1000000LL) {
            s_turn_us = tnow;
            s_cur = (s_cur + 1) % (s_pages > 0 ? s_pages : 1);
            show_page(s_cur);
        }
    }
}
