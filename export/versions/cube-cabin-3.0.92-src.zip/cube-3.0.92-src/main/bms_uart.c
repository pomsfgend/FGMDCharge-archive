#include "bms_uart.h"
#include "app_state.h"
#include "ble.h"
#include "settings.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "esp_rom_sys.h"
#include "esp_timer.h"
#include "nvs.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>

static const char *TAG = "BMS";

typedef struct {
    int ok;
    int mv;
    int ma;
    int soc;
    int remain_mah;
    int full_mah;
    int fet;
    int cell_min_mv;
    int cell_max_mv;
    int ncell;
    int peak_mah;
    int peak_ma;
    uint32_t balance;
    int cells[24];
    uint8_t cfg[192];
    int cfg_len;
    int cfg_writable;
    int reg_v[16];
    uint8_t reg_ok[16];
    int regs_n;
    char hw[32];
} link_t;

static link_t s_link[2];
static SemaphoreHandle_t s_bus;
static int s_cap_src;
static int s_man_ah_x100;
static int s_man_wh;
static int s_full_wh;
static int s_remain_wh;
static int s_need_cap;

static void cap_save(void)
{
    nvs_handle_t h;
    if (nvs_open("storage", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u8(h, "cap_src", (uint8_t)(s_cap_src ? 1 : 0));
    nvs_set_u32(h, "cap_ah", (uint32_t)s_man_ah_x100);
    nvs_set_u32(h, "cap_wh", (uint32_t)s_man_wh);
    nvs_commit(h);
    nvs_close(h);
}

static void cap_load(void)
{
    nvs_handle_t h;
    uint8_t src = 0;
    uint32_t ah = 0;
    uint32_t wh = 0;
    if (nvs_open("storage", NVS_READONLY, &h) != ESP_OK) return;
    if (nvs_get_u8(h, "cap_src", &src) == ESP_OK) s_cap_src = src ? 1 : 0;
    if (nvs_get_u32(h, "cap_ah", &ah) == ESP_OK) s_man_ah_x100 = (int)ah;
    if (nvs_get_u32(h, "cap_wh", &wh) == ESP_OK) s_man_wh = (int)wh;
    nvs_close(h);
}

static void cap_apply(void)
{
    const link_t *L = &s_link[0];
    int full = 0;
    int remain = 0;
    int need = 0;
    if (s_cap_src == 0 && L->ok && L->full_mah > 0 && L->mv > 1000) {
        full = (int)(((int64_t)L->full_mah * L->mv) / 1000000);
    } else if (s_man_wh > 0) {
        full = s_man_wh;
    } else if (s_man_ah_x100 > 0 && L->ok && L->mv > 1000) {
        full = (int)(((int64_t)s_man_ah_x100 * L->mv) / 100000);
    } else {
        need = 1;
    }
    if (s_cap_src == 0 && !(L->ok && L->full_mah > 0)) need = 1;
    if (L->ok && L->remain_mah > 0 && L->mv > 1000)
        remain = (int)(((int64_t)L->remain_mah * L->mv) / 1000000);
    else if (full > 0 && L->ok && L->soc >= 0 && L->soc <= 100)
        remain = full * L->soc / 100;
    s_full_wh = full;
    s_remain_wh = remain;
    s_need_cap = need || full <= 0;
    if (full > 0) app_state_set_cap_kwh((float)full / 1000.0f);
    if (s_cap_src == 0 && L->ok && L->soc >= 0 && L->soc <= 100)
        app_state_set_soc_live((uint8_t)L->soc);
}

void bms_set_cap(int src, int ah_x100, int wh, int set_ah, int set_wh)
{
    if (src == 0 || src == 1) s_cap_src = src;
    if (set_ah) {
        if (ah_x100 < 0) ah_x100 = 0;
        if (ah_x100 > 100000) ah_x100 = 100000;
        s_man_ah_x100 = ah_x100;
    }
    if (set_wh) {
        if (wh < 0) wh = 0;
        if (wh > 200000) wh = 200000;
        s_man_wh = wh;
    }
    cap_save();
    cap_apply();
}

int bms_cap_src(void) { return s_cap_src; }
int bms_need_cap(void) { return s_need_cap; }
int bms_full_wh(void) { return s_full_wh; }
int bms_remain_wh(void) { return s_remain_wh; }

#define BR_QN 4
#define BR_QMAX 220
static int s_cfg_force[2];
static int s_hold;
static uint8_t s_brq[BR_QN][BR_QMAX];
static uint8_t s_brl[BR_QN];
static int s_brr, s_brw, s_brn;
static portMUX_TYPE s_brm = portMUX_INITIALIZER_UNLOCKED;
static uint8_t s_asm[BR_QMAX];
static int s_asm_n;

static int cfg_u16(const link_t *link, int off)
{
    if (!link || off < 0 || off + 1 >= link->cfg_len) return -1;
    return ((int)link->cfg[off] << 8) | link->cfg[off + 1];
}

static int frame(uint8_t *dst, uint8_t dir, uint8_t cmd, const uint8_t *data, int len)
{
    int sum = cmd + len;
    dst[0] = 0xDD;
    dst[1] = dir;
    dst[2] = cmd;
    dst[3] = (uint8_t)len;
    for (int i = 0; i < len; ++i) {
        dst[4 + i] = data[i];
        sum += data[i];
    }
    sum = (-sum) & 0xFFFF;
    dst[4 + len] = (uint8_t)(sum >> 8);
    dst[5 + len] = (uint8_t)sum;
    dst[6 + len] = 0x77;
    return 7 + len;
}

/* Одна АКБ, аппаратный UART2 9600 на GPIO1/GPIO2.
 * Битовый приём держал прерывания выключенными на весь кадр. На помехе от
 * зарядок это растягивалось до сторожа и куб перезагружался, а битые байты
 * без контрольной суммы уходили на экран. UART1 занят фардрайвером. */

#define BMS_UART UART_NUM_2
#define BMSA_TX 1
#define BMSA_RX 2

static int s_bad_run;
static int64_t s_good_us;

static int jbd_sum_ok(const uint8_t *rx, int n)
{
    int len;
    int i;
    int sum;
    int got;
    int alt;
    if (!rx || n < 7 || rx[0] != 0xDD) return 0;
    len = rx[3];
    if (len < 0 || len > 180 || n < 7 + len) return 0;
    if (rx[6 + len] != 0x77) return 0;
    sum = 0;
    for (i = 2; i < 4 + len; ++i) sum += rx[i];
    got = ((int)rx[4 + len] << 8) | rx[5 + len];
    if (got == ((-sum) & 0xFFFF)) return 1;
    alt = 0;
    for (i = 1; i < 4 + len; ++i) alt += rx[i];
    return got == ((-alt) & 0xFFFF);
}

static void bms_uart_install(void)
{
    uart_config_t cfg = {
        .baud_rate = 9600,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    if (uart_is_driver_installed(BMS_UART)) uart_driver_delete(BMS_UART);
    if (uart_driver_install(BMS_UART, 512, 0, 0, NULL, 0) != ESP_OK) {
        ESP_LOGE(TAG, "UART2 install failed");
        return;
    }
    uart_param_config(BMS_UART, &cfg);
    uart_set_pin(BMS_UART, BMSA_TX, BMSA_RX, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    uart_set_rx_timeout(BMS_UART, 8);
    uart_flush_input(BMS_UART);
    gpio_set_pull_mode(BMSA_RX, GPIO_PULLUP_ONLY);
}

static void bus_flush(int index)
{
    if (index != 0) return;
    uart_flush_input(BMS_UART);
}

static void bus_tx(int index, const uint8_t *data, int n)
{
    if (index != 0 || !data || n <= 0) return;
    uart_write_bytes(BMS_UART, data, n);
    uart_wait_tx_done(BMS_UART, pdMS_TO_TICKS(40));
}

static int frame_complete(const uint8_t *d, int n)
{
    int i = 0;
    int len;
    while (i < n && d[i] != 0xDD) i++;
    if (n - i < 4) return 0;
    len = d[i + 3];
    if (len < 0 || len > 180) return 0;
    return (n - i) >= 7 + len;
}

static int bus_rx(int index, uint8_t *data, int cap, int timeout_ms)
{
    int n = 0;
    int64_t limit;
    if (index != 0 || !data || cap <= 0) return 0;
    limit = esp_timer_get_time() + (int64_t)timeout_ms * 1000;
    while (n < cap && esp_timer_get_time() < limit) {
        int left = (int)((limit - esp_timer_get_time()) / 1000);
        int r;
        if (left < 1) left = 1;
        if (left > 20) left = 20;
        r = uart_read_bytes(BMS_UART, data + n, (uint32_t)(cap - n), pdMS_TO_TICKS(left));
        if (r > 0) n += r;
        /* A noise byte must not end the read: the real frame often follows it. */
        if (frame_complete(data, n)) break;
    }
    return n;
}

static int xfer_ms(int index, const uint8_t *tx, int txlen, uint8_t *rx, int rxcap, int ms)
{
    bus_flush(index);
    bus_tx(index, tx, txlen);
    return bus_rx(index, rx, rxcap, ms);
}

static int xfer(int index, const uint8_t *tx, int txlen, uint8_t *rx, int rxcap)
{
    return xfer_ms(index, tx, txlen, rx, rxcap, 250);
}

/* +13 В с разъёма BMS на ESP не подавать. Здесь только TX и RX, 9600 8N1. */

static void arm(uart_port_t port, int tx, int rx)
{
    uart_config_t cfg = {
        .baud_rate = 9600,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_APB,
    };
    uart_driver_install(port, 512, 0, 0, NULL, 0);
    uart_param_config(port, &cfg);
    uart_set_pin(port, tx, rx, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    /* Без этого uart_read_bytes ждёт полный буфер или все 250 мс.
     * 3 времени байта: кадр 9600 отдаётся сразу после тишины. */
    uart_set_rx_timeout(port, 3);
}

static int sync_dd(uint8_t *rx, int n);

static void bms_miss(link_t *link)
{
    int64_t age;
    s_bad_run++;
    age = s_good_us == 0 ? 10000000 : (esp_timer_get_time() - s_good_us);
    uart_flush_input(BMS_UART);
    /* One noisy frame must not blank the screen. Drop the link only after
     * several failures and a few seconds without a good checksum. */
    if (s_bad_run >= 6 && age > 3000000) link->ok = 0;
}

static int bms_plausible(const link_t *link, int mv, int ma)
{
    int d;
    if (mv < 15000 || mv > 120000) return 0;
    if (ma > 250000 || ma < -250000) return 0;
    if (!link->ok || link->mv < 1000) return 1;
    d = mv - link->mv;
    if (d < 0) d = -d;
    if (d > 6000) return 0;
    d = ma - link->ma;
    if (d < 0) d = -d;
    if (d > 120000) return 0;
    return 1;
}

static void ask(int index, link_t *link, const char *name)
{
    static const uint8_t req[] = {0xDD, 0xA5, 0x03, 0x00, 0xFF, 0xFD, 0x77};
    uint8_t rx[80];
    int n;
    int len;
    int mv;
    int ma;
    bus_flush(index);
    bus_tx(index, req, sizeof(req));
    n = bus_rx(index, rx, sizeof(rx), 120);
    n = sync_dd(rx, n);
    if (!jbd_sum_ok(rx, n) || rx[1] != 0x03 || rx[2] != 0x00) {
        bms_miss(link);
        if (s_bad_run == 1 || (s_bad_run % 8) == 0)
            ESP_LOGI(TAG, "%s нет кадра %d", name, n);
        return;
    }
    len = rx[3];
    if (len < 4) {
        bms_miss(link);
        return;
    }
    mv = (((int)rx[4] << 8) | rx[5]) * 10;
    ma = (int)(int16_t)(((int)rx[6] << 8) | rx[7]) * 10;
    if (!bms_plausible(link, mv, ma)) {
        bms_miss(link);
        ESP_LOGI(TAG, "%s скачок %d мВ отброшен", name, mv);
        return;
    }
    link->ok = 1;
    s_bad_run = 0;
    s_good_us = esp_timer_get_time();
    link->mv = mv;
    link->ma = ma;
    {
        int absma = link->ma < 0 ? -link->ma : link->ma;
        if (absma > link->peak_ma) link->peak_ma = absma;
    }
    link->remain_mah = len > 5 ? ((((int)rx[8] << 8) | rx[9]) * 10) : 0;
    link->full_mah = len > 7 ? ((((int)rx[10] << 8) | rx[11]) * 10) : 0;
    if (link->full_mah < 0 || link->full_mah > 500000) link->full_mah = 0;
    if (link->remain_mah > link->peak_mah) link->peak_mah = link->remain_mah;
    link->balance = 0;
    if (len >= 16) {
        uint16_t lo = ((uint16_t)rx[16] << 8) | rx[17];
        uint16_t hi = ((uint16_t)rx[18] << 8) | rx[19];
        link->balance = ((uint32_t)hi << 16) | lo;
    }
    link->soc = len > 19 ? rx[23] : -1;
    link->fet = len > 20 ? rx[24] : 0;
    app_state_set_battery_vi((uint16_t)(link->mv / 100), (int16_t)(link->ma / 100));
    cap_apply();
}

static void cells(int index, link_t *link)
{
    static const uint8_t req[] = {0xDD, 0xA5, 0x04, 0x00, 0xFF, 0xFC, 0x77};
    uint8_t rx[128];
    int n;
    int len;
    int i;
    int min_mv = 10000;
    int max_mv = 0;
    bus_flush(index);
    bus_tx(index, req, sizeof(req));
    n = bus_rx(index, rx, sizeof(rx), 160);
    n = sync_dd(rx, n);
    if (!jbd_sum_ok(rx, n) || rx[1] != 0x04) return;
    len = rx[3];
    if (len < 2 || n < 4 + len) return;
    {
        int nc = len / 2;
        int tmp[24];
        int bad = 0;
        if (nc > 24) nc = 24;
        if (nc < 1) return;
        for (i = 0; i < nc; ++i) {
            int cmv = ((int)rx[4 + i * 2] << 8) | rx[5 + i * 2];
            if (cmv < 1500 || cmv > 4500) bad = 1;
            tmp[i] = cmv;
        }
        if (bad) return;
        link->ncell = nc;
        min_mv = 10000;
        max_mv = 0;
        for (i = 0; i < nc; ++i) {
            link->cells[i] = tmp[i];
            if (tmp[i] < min_mv) min_mv = tmp[i];
            if (tmp[i] > max_mv) max_mv = tmp[i];
        }
        link->cell_min_mv = min_mv;
        link->cell_max_mv = max_mv;
    }
}

static const uint8_t k_reg[] = {
    0x10, 0x11, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2D, 0x2F
};
#define REG_N ((int)(sizeof(k_reg)))

static int frame_ok(const uint8_t *rx, int n);

static int sync_dd(uint8_t *rx, int n)
{
    int i = 0;
    while (i < n && rx[i] != 0xDD) i++;
    if (i > 0 && i < n) {
        memmove(rx, rx + i, (size_t)(n - i));
        n -= i;
    }
    return n;
}

static int reg_slot(int reg)
{
    int i;
    for (i = 0; i < REG_N; ++i) if (k_reg[i] == (uint8_t)reg) return i;
    return -1;
}

static int amp_div_of(const link_t *L)
{
    int slot = reg_slot(0x2D);
    if (!L || slot < 0 || !L->reg_ok[slot]) return 0;
    return (L->reg_v[slot] & 0x1000) ? 10 : 100;
}

/* 0x06 is the 6-digit app password. Factory key 5678 alone is ignored on
 * newer SP boards, so a write looks like it landed and the old number stays. */
static void enter_factory(int index)
{
    static const uint8_t data[2] = {0x56, 0x78};
    uint8_t tx[16];
    uint8_t rx[24];
    int nlen = frame(tx, 0x5A, 0x00, data, 2);
    (void)xfer_ms(index, tx, nlen, rx, sizeof(rx), 150);
}

static void enter_factory_pw(int index, int alt)
{
    static const uint8_t pw_a[7] = {0x06, '1', '2', '3', '4', '5', '6'};
    static const uint8_t pw_b[7] = {0x06, '0', '0', '0', '0', '0', '0'};
    uint8_t tx[24];
    uint8_t rx[24];
    int nlen = frame(tx, 0x5A, 0x06, alt ? pw_b : pw_a, 7);
    (void)xfer_ms(index, tx, nlen, rx, sizeof(rx), 180);
    vTaskDelay(pdMS_TO_TICKS(40));
    enter_factory(index);
}

static void exit_factory(int index, int save)
{
    uint8_t data[2];
    uint8_t tx[16];
    uint8_t rx[24];
    int nlen;
    data[0] = data[1] = save ? 0x28 : 0x00;
    nlen = frame(tx, 0x5A, 0x01, data, 2);
    (void)xfer_ms(index, tx, nlen, rx, sizeof(rx), 160);
}

static int read_reg(int index, int reg, int *value)
{
    uint8_t tx[8];
    uint8_t rx[24];
    int nlen = frame(tx, 0xA5, (uint8_t)reg, NULL, 0);
    int n = xfer_ms(index, tx, nlen, rx, sizeof(rx), 120);
    int v;
    n = sync_dd(rx, n);
    if (!frame_ok(rx, n) || rx[3] < 2) return 0;
    if (rx[1] != (uint8_t)reg) return 0;
    v = ((int)rx[4] << 8) | rx[5];
    if ((reg == 0x28 || reg == 0x29) && v >= 0x8000) v -= 0x10000;
    *value = v;
    return 1;
}

static void read_regs(int index, link_t *link)
{
    int i;
    int any = 0;
    enter_factory(index);
    vTaskDelay(pdMS_TO_TICKS(40));
    for (i = 0; i < REG_N; ++i) {
        int v = 0;
        if (s_hold) break;
        if (read_reg(index, k_reg[i], &v)) {
            link->reg_v[i] = v;
            link->reg_ok[i] = 1;
        }
    }
    exit_factory(index, 0);
    for (i = 0; i < REG_N; ++i) if (link->reg_ok[i]) any++;
    link->regs_n = any;
    if (any) ESP_LOGW(TAG, "regs %d/%d", any, REG_N);
}

static int unlock_cfg(int index)
{
    static const uint8_t data[2] = {0x56, 0x78};
    uint8_t tx[16];
    uint8_t rx[16];
    int nlen = frame(tx, 0x5A, 0x00, data, 2);
    int n = xfer(index, tx, nlen, rx, sizeof(rx));
    return n >= 4 && rx[0] == 0xDD && rx[2] == 0x00;
}

static int frame_ok(const uint8_t *rx, int n)
{
    int len;
    if (n < 7 || rx[0] != 0xDD) return 0;
    len = rx[3];
    if (len < 0 || len > 160 || n < 7 + len) return 0;
    if (!jbd_sum_ok(rx, n) || rx[2] != 0x00) return 0;
    return 1;
}

static int read_cfg_once(int index, link_t *link)
{
    uint8_t tx[8];
    uint8_t rx[220];
    int nlen = frame(tx, 0xA5, 0xFA, NULL, 0);
    int n;
    int declared;
    int i;
    n = xfer(index, tx, nlen, rx, sizeof(rx));
    i = 0;
    while (i + 7 < n && rx[i] != 0xDD) i++;
    if (i) {
        memmove(rx, rx + i, (size_t)(n - i));
        n -= i;
    }
    if (!frame_ok(rx, n)) {
        ESP_LOGW(TAG, "cfg n=%d %02x %02x %02x %02x %02x",
                 n, n > 0 ? rx[0] : 0, n > 1 ? rx[1] : 0, n > 2 ? rx[2] : 0, n > 3 ? rx[3] : 0,
                 n > 4 ? rx[4] : 0);
        return 0;
    }
    declared = rx[3];
    if (declared < 18) return 0;
    if (declared > (int)sizeof(link->cfg)) declared = (int)sizeof(link->cfg);
    memcpy(link->cfg, rx + 4, (size_t)declared);
    link->cfg_len = declared;
    link->cfg_writable = 1;
    ESP_LOGW(TAG, "cfg заряд %d А пауза %d разряд %d А пауза %d короткое %d пауза %d",
             cfg_u16(link, 16), cfg_u16(link, 18), cfg_u16(link, 20),
             cfg_u16(link, 22), cfg_u16(link, 24), cfg_u16(link, 26));
    return 1;
}

static void read_cfg(int index, link_t *link, const char *name)
{
    if (read_cfg_once(index, link)) return;
    if (unlock_cfg(index)) vTaskDelay(pdMS_TO_TICKS(40));
    if (!read_cfg_once(index, link)) {
        ESP_LOGW(TAG, "%s настройки не прочитаны", name);
    }
}

static void read_hw(int index, link_t *link)
{
    static const uint8_t req[] = {0xDD, 0xA5, 0x05, 0x00, 0xFF, 0xFB, 0x77};
    uint8_t rx[48];
    int n;
    int len;
    int i;
    if (link->hw[0]) return;
    n = xfer(index, req, sizeof(req), rx, sizeof(rx));
    if (!frame_ok(rx, n)) return;
    len = rx[3];
    if (len <= 0 || len > 31) return;
    for (i = 0; i < len; ++i) {
        uint8_t c = rx[4 + i];
        if (c < 32 || c > 126 || c == '"' || c == '\\') c = ' ';
        link->hw[i] = (char)c;
    }
    link->hw[len] = 0;
}

static void task(void *arg)
{
    int tickn = 0;
    (void)arg;
    for (;;) {
        int bridged = 0;
        if (s_bus) xSemaphoreTake(s_bus, portMAX_DELAY);
        if (s_hold || s_brn) {
            uint8_t tx[BR_QMAX];
            uint8_t rx[240];
            int tn = 0;
            taskENTER_CRITICAL(&s_brm);
            if (s_brn > 0) {
                tn = s_brl[s_brr];
                if (tn > BR_QMAX) tn = BR_QMAX;
                memcpy(tx, s_brq[s_brr], (size_t)tn);
                s_brr = (s_brr + 1) % BR_QN;
                s_brn--;
            }
            taskEXIT_CRITICAL(&s_brm);
            if (tn > 0) {
                int rn = xfer(0, tx, tn, rx, sizeof(rx));
                if (s_bus) xSemaphoreGive(s_bus);
                if (rn > 0) (void)cube_ble_notify(rx, (uint16_t)rn);
            } else if (s_bus) {
                xSemaphoreGive(s_bus);
            }
            bridged = 1;
        }
        if (bridged) {
            vTaskDelay(pdMS_TO_TICKS(8));
            continue;
        }
        ask(0, &s_link[0], "JBD-A");
        if (s_hold) { if (s_bus) xSemaphoreGive(s_bus); vTaskDelay(pdMS_TO_TICKS(8)); continue; }
        if ((tickn % 2) == 0) cells(0, &s_link[0]);
        if (!s_link[0].hw[0] && (tickn % 5) == 0) read_hw(0, &s_link[0]);
        /* Register and config dumps take seconds. While the chargers are
         * noisy they used to run on every loop, so voltage froze and the
         * next basic frame was lost. Live voltage stays on the fast path.
         * The slow read is at most once every ~20 s, and never on a bad run. */
        if (tickn > 0 && s_bad_run == 0 && s_link[0].ok && (tickn % 40) == 0 &&
            (s_link[0].regs_n < 8 || s_link[0].cfg_len < 18 || s_cfg_force[0])) {
            if (s_link[0].regs_n < 8 || s_cfg_force[0]) read_regs(0, &s_link[0]);
            if (!s_hold && s_link[0].cfg_len < 18) read_cfg(0, &s_link[0], "JBD-A");
            s_cfg_force[0] = 0;
        }
        tickn++;
        if (s_bus) xSemaphoreGive(s_bus);
        vTaskDelay(pdMS_TO_TICKS(200));
    }
}

void bms_link_get(int index, bms_link_t *out)
{
    const link_t *link;
    if (!out) return;
    if (index < 0 || index > 1) {
        out->ok = 0;
        return;
    }
    link = &s_link[index];
    memset(out, 0, sizeof(*out));
    out->chg = out->chgd = out->dsg = out->dsgd = out->sc = out->scd = -1;
    out->ok = link->ok;
    out->mv = link->mv;
    out->ma = link->ma;
    out->peak_ma = link->peak_ma;
    out->soc = link->soc;
    out->remain_mah = link->remain_mah;
    out->full_mah = link->full_mah;
    out->fet = link->fet;
    out->cell_min_mv = link->cell_min_mv;
    out->cell_max_mv = link->cell_max_mv;
    out->ncell = link->ncell;
    out->peak_mah = link->peak_mah;
    out->balance = link->balance;
    out->cfg_ok = (link->cfg_len >= 18) || (link->regs_n > 0);
    out->cfg_writable = link->cfg_writable || link->regs_n > 0;
    out->regs_ok = link->regs_n;
    out->chg = cfg_u16(link, 16);
    out->chgd = cfg_u16(link, 18);
    out->dsg = cfg_u16(link, 20);
    out->dsgd = cfg_u16(link, 22);
    out->sc = cfg_u16(link, 24);
    out->scd = cfg_u16(link, 26);
    {
        int v;
        int slot = reg_slot(0x28);
        if (slot >= 0 && link->reg_ok[slot]) {
            int div = amp_div_of(link);
            int a;
            v = link->reg_v[slot];
            if (v < 0) v = -v;
            if (div == 10 || div == 100) a = (v + div / 2) / div;
            else if (v >= 500) a = (v + 50) / 100;
            else if (v >= 200) a = (v + 5) / 10;
            else a = v;
            out->chg = a;
        }
        slot = reg_slot(0x29);
        if (slot >= 0 && link->reg_ok[slot]) {
            int div = amp_div_of(link);
            int a;
            v = link->reg_v[slot];
            if (v < 0) v = -v;
            if (div == 10 || div == 100) a = (v + div / 2) / div;
            else if (v >= 500) a = (v + 50) / 100;
            else if (v >= 200) a = (v + 5) / 10;
            else a = v;
            out->dsg = a;
        }
    }
    snprintf(out->hw, sizeof(out->hw), "%s", link->hw);
    {
        int n = link->ncell;
        int i;
        if (n > 24) n = 24;
        for (i = 0; i < n; ++i) out->cells[i] = link->cells[i];
    }
}

void bms_link_text(int index, char *out, size_t cap)
{
    const link_t *link;
    if (!out || cap == 0) return;
    if (index < 0 || index > 1) {
        snprintf(out, cap, "нет");
        return;
    }
    link = &s_link[index];
    if (!link->ok) {
        snprintf(out, cap, "нет связи");
        return;
    }
    if (link->soc >= 0) {
        snprintf(out, cap, "%d.%02d В  %d.%02d А  %d%%",
                 link->mv / 1000, (link->mv / 10) % 100,
                 link->ma / 1000, (link->ma < 0 ? -link->ma : link->ma) / 10 % 100,
                 link->soc);
    } else {
        snprintf(out, cap, "%d.%02d В  %d.%02d А",
                 link->mv / 1000, (link->mv / 10) % 100,
                 link->ma / 1000, (link->ma < 0 ? -link->ma : link->ma) / 10 % 100);
    }
}

void bms_uart_start(void)
{
    s_bus = xSemaphoreCreateMutex();
    bms_uart_install();
    ESP_LOGW(TAG, "АКБ одна, UART2 9600 TX GPIO1 RX GPIO2, контрольная сумма. +13 В на ESP не подавать");
    cap_load();
    cap_apply();
    xTaskCreate(task, "bms", 12288, NULL, 2, NULL);
}

int bms_json(char *out, size_t cap)
{
    int used = 0;
    int p;
    if (!out || cap < 16) return -1;
    used = snprintf(out, cap, "{\"ok\":true,\"ble_role\":%d,\"ble_pack\":%d,\"packs\":[",
                    settings_get_ble_role(), settings_get_bms_pack());
    for (p = 0; p < 1; ++p) {
        const link_t *L = &s_link[p];
        int i;
        int n;
        if ((size_t)used >= cap) return -1;
        n = snprintf(out + used, cap - (size_t)used,
                     "%s{\"ok\":%s,\"mv\":%d,\"ma\":%d,\"peak_ma\":%d,\"soc\":%d,\"mah\":%d,\"full_mah\":%d,\"d_mv\":%d,\"ncell\":%d,"
                     "\"fet\":%d,\"bal\":%lu,\"cfg_ok\":%s,\"writable\":%s,\"hw\":\"%s\","
                     "\"chg\":%d,\"chgd\":%d,\"dsg\":%d,\"dsgd\":%d,\"sc\":%d,\"scd\":%d,\"amp_div\":%d,\"cells\":[",
                     p ? "," : "", L->ok ? "true" : "false", L->mv, L->ma, L->peak_ma, L->soc, L->remain_mah, L->full_mah,
                     (L->ncell > 0) ? (L->cell_max_mv - L->cell_min_mv) : -1, L->ncell,
                     L->fet, (unsigned long)L->balance,
                     (L->cfg_len >= 18 || L->regs_n > 0) ? "true" : "false",
                     (L->cfg_writable || L->regs_n > 0) ? "true" : "false", L->hw,
                     cfg_u16(L, 16), cfg_u16(L, 18), cfg_u16(L, 20), cfg_u16(L, 22), cfg_u16(L, 24), cfg_u16(L, 26),
                     amp_div_of(L));
        if (n < 0) return -1;
        used += n;
        for (i = 0; i < L->ncell; ++i) {
            if ((size_t)used >= cap) return -1;
            n = snprintf(out + used, cap - (size_t)used, "%s%d", i ? "," : "", L->cells[i]);
            if (n < 0) return -1;
            used += n;
        }
        if ((size_t)used >= cap) return -1;
        n = snprintf(out + used, cap - (size_t)used, "],\"regs\":[");
        if (n < 0) return -1;
        used += n;
        for (i = 0; i < REG_N; ++i) {
            if ((size_t)used >= cap) return -1;
            n = snprintf(out + used, cap - (size_t)used, "%s{\"r\":%u,\"v\":%d,\"ok\":%d}",
                         i ? "," : "", (unsigned)k_reg[i], L->reg_ok[i] ? L->reg_v[i] : -1, L->reg_ok[i] ? 1 : 0);
            if (n < 0) return -1;
            used += n;
        }
        if ((size_t)used >= cap) return -1;
        n = snprintf(out + used, cap - (size_t)used, "]}");
        if (n < 0) return -1;
        used += n;
    }
    if ((size_t)used + 120 >= cap) return -1;
    used += snprintf(out + used, cap - (size_t)used,
        "],\"cap_src\":%d,\"need_cap\":%d,\"full_wh\":%d,\"remain_wh\":%d,\"man_ah_x100\":%d,\"man_wh\":%d}",
        s_cap_src, s_need_cap, s_full_wh, s_remain_wh, s_man_ah_x100, s_man_wh);
    return used;
}

int bms_cfg_write(int index, int offset, int value, int *readback)
{
    link_t *L;
    uint8_t tx[220];
    uint8_t rx[32];
    int nlen;
    int n;
    int got;
    if (readback) *readback = -1;
    if (index < 0 || index > 1 || offset < 0 || (offset & 1) || value < 0 || value > 65535) return -1;
    if (offset != 16 && offset != 18 && offset != 20 && offset != 22 && offset != 24 && offset != 26) return -1;
    L = &s_link[index];
    if (!s_bus || !L->cfg_writable || L->cfg_len < offset + 2) return -2;
    xSemaphoreTake(s_bus, portMAX_DELAY);
    (void)unlock_cfg(index);
    vTaskDelay(pdMS_TO_TICKS(30));
    L->cfg[offset] = (uint8_t)(value >> 8);
    L->cfg[offset + 1] = (uint8_t)value;
    nlen = frame(tx, 0x5A, 0xFA, L->cfg, L->cfg_len);
    n = xfer(index, tx, nlen, rx, sizeof(rx));
    n = sync_dd(rx, n);
    if (n < 4 || rx[0] != 0xDD || rx[2] != 0x00) {
        exit_factory(index, 0);
        xSemaphoreGive(s_bus);
        return -3;
    }
    vTaskDelay(pdMS_TO_TICKS(30));
    exit_factory(index, 1);
    vTaskDelay(pdMS_TO_TICKS(80));
    (void)unlock_cfg(index);
    vTaskDelay(pdMS_TO_TICKS(30));
    L->cfg_len = 0;
    L->cfg_writable = 0;
    (void)read_cfg_once(index, L);
    exit_factory(index, 0);
    got = cfg_u16(L, offset);
    if (readback) *readback = got;
    s_cfg_force[index] = (got == value) ? 0 : 1;
    xSemaphoreGive(s_bus);
    return got == value ? 0 : -4;
}

void bms_cfg_kick(void)
{
    s_cfg_force[0] = 1;
    s_cfg_force[1] = 1;
}

int bms_reg_write(int index, int reg, int value, int *readback)
{
    link_t *L;
    uint8_t data[2];
    uint8_t tx[16];
    uint8_t rx[24];
    int slot;
    int alt;
    int nlen;
    int n;
    int got = 0;
    int u;
    int wrote = 0;
    if (readback) *readback = -1;
    slot = reg_slot(reg);
    if (index < 0 || index > 1 || slot < 0 || value < -32768 || value > 65535) return -1;
    if (reg == 0x29 && value > 0) value = -value;
    if (reg == 0x28 && value < 0) value = -value;
    if (!s_bus) return -2;
    L = &s_link[index];
    xSemaphoreTake(s_bus, portMAX_DELAY);
    for (alt = 0; alt < 2 && !wrote; ++alt) {
        u = value & 0xFFFF;
        data[0] = (uint8_t)(u >> 8);
        data[1] = (uint8_t)u;
        enter_factory_pw(index, alt);
        vTaskDelay(pdMS_TO_TICKS(50));
        nlen = frame(tx, 0x5A, (uint8_t)reg, data, 2);
        n = xfer_ms(index, tx, nlen, rx, sizeof(rx), 200);
        n = sync_dd(rx, n);
        if (n >= 3 && rx[0] == 0xDD && rx[2] == 0x80) {
            exit_factory(index, 0);
            continue;
        }
        vTaskDelay(pdMS_TO_TICKS(40));
        exit_factory(index, 1);
        vTaskDelay(pdMS_TO_TICKS(400));
        enter_factory_pw(index, alt);
        vTaskDelay(pdMS_TO_TICKS(40));
        if (!read_reg(index, reg, &got)) {
            exit_factory(index, 0);
            continue;
        }
        exit_factory(index, 0);
        {
            int match;
            if (reg == 0x28 || reg == 0x29) {
                int a = got < 0 ? -got : got;
                int b = value < 0 ? -value : value;
                match = a == b;
            } else {
                match = ((got & 0xFFFF) == (value & 0xFFFF));
            }
            if (match) {
                wrote = 1;
                break;
            }
        }
    }
    if (readback) *readback = got;
    if (!wrote) {
        xSemaphoreGive(s_bus);
        return got == 0 ? -3 : -4;
    }
    L->reg_v[slot] = got;
    L->reg_ok[slot] = 1;
    if (L->regs_n < 1) L->regs_n = 1;
    xSemaphoreGive(s_bus);
    return 0;
}

void bms_bridge_hold(int on)
{
    s_hold = on ? 1 : 0;
    if (!s_hold) {
        taskENTER_CRITICAL(&s_brm);
        s_brn = 0;
        s_brr = 0;
        s_brw = 0;
        taskEXIT_CRITICAL(&s_brm);
        s_asm_n = 0;
    }
}

int bms_bridge_submit(const uint8_t *data, int len)
{
    int i;
    if (!data || len <= 0) return -1;
    for (i = 0; i < len; ++i) {
        if (s_asm_n >= BR_QMAX) s_asm_n = 0;
        s_asm[s_asm_n++] = data[i];
        for (;;) {
            int j = 0;
            int flen;
            int need;
            while (j < s_asm_n && s_asm[j] != 0xDD) j++;
            if (j > 0) {
                memmove(s_asm, s_asm + j, (size_t)(s_asm_n - j));
                s_asm_n -= j;
            }
            if (s_asm_n < 4) break;
            flen = s_asm[3];
            if (flen > 180) {
                memmove(s_asm, s_asm + 1, (size_t)(s_asm_n - 1));
                s_asm_n--;
                continue;
            }
            need = 7 + flen;
            if (need > BR_QMAX) {
                memmove(s_asm, s_asm + 1, (size_t)(s_asm_n - 1));
                s_asm_n--;
                continue;
            }
            if (s_asm_n < need) break;
            if (s_asm[need - 1] != 0x77) {
                memmove(s_asm, s_asm + 1, (size_t)(s_asm_n - 1));
                s_asm_n--;
                continue;
            }
            taskENTER_CRITICAL(&s_brm);
            if (s_brn >= BR_QN) {
                s_brr = (s_brr + 1) % BR_QN;
                s_brn--;
            }
            memcpy(s_brq[s_brw], s_asm, (size_t)need);
            s_brl[s_brw] = (uint8_t)need;
            s_brw = (s_brw + 1) % BR_QN;
            s_brn++;
            taskEXIT_CRITICAL(&s_brm);
            if (s_asm_n > need) memmove(s_asm, s_asm + need, (size_t)(s_asm_n - need));
            s_asm_n -= need;
        }
    }
    return 0;
}