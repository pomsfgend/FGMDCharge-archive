#pragma once

#include <stddef.h>

void cabin_start(void);
int cabin_json(char *out, size_t cap);
void cabin_lcd(char *out, size_t cap);

void cabin_set_heat(int on);
void cabin_toggle_heat(void);
void cabin_set_light(int mode);
void cabin_cycle_light(void);
void cabin_set_comfort_c(int c);
void cabin_bump_comfort(int delta_c);
void cabin_set_seat_max_c(int c);
void cabin_set_amp_lim_a(int a);
void cabin_set_duty_max(int pct);
void cabin_set_heat_mode(int mode);
void cabin_set_manual_duty(int pct);
void cabin_set_amb_on_c(int c);
void cabin_set_lux(int on_lux, int off_lux);
void cabin_set_relay(int channel, int on);
int cabin_gpio_on(int gpio);
void cabin_set_zvs(int on);
void cabin_set_auto_off(int min);   /* heater switch auto-off, minutes, 0 = never */

#define CABIN_NO_TEMP (-32768)
typedef struct {
    int seat;       /* 0.01 C or CABIN_NO_TEMP */
    int amb;        /* 0.01 C or CABIN_NO_TEMP */
    int lux;        /* lux or -1 */
    int duty;       /* heater PWM, % */
    int heat;       /* heater switch */
    int heat_mode;  /* 0 manual, 1 auto */
    int comfort;    /* 0.01 C */
    int seat_max;   /* 0.01 C */
    int light;      /* 0 off, 1 on, 2 auto */
    int rate;       /* 0.01 C per second */
    int heat_left;  /* minutes until the timer switches the heater off, -1 none */
    int auto_off;   /* timer setting, minutes */
    char fault[8];
} cabin_view_t;
void cabin_view(cabin_view_t *v);
