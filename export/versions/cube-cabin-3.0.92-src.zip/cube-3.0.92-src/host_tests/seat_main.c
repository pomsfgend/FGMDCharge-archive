#define CHECK(c) do{ if(!(c)){ printf("FAIL line %d: %s\n",__LINE__,#c); fails++; } }while(0)
int main(void){
  int fails=0; seat_filter_t f; memset(&f,0,sizeof f);
  int v=0; int64_t ms=0;
  for(int i=0;i<5;i++){ v=seat_filter_push(&f,2500,ms); ms+=400; }
  v=seat_filter_push(&f,8500,ms); ms+=400;
  CHECK(v==2500);
  v=seat_filter_push(&f,2500,ms); ms+=400;
  CHECK(v==2500);
  memset(&f,0,sizeof f); ms=0; int t=2000;
  for(int i=0;i<20;i++){ seat_filter_push(&f,t,ms); t+=4; ms+=400; }
  int r=seat_filter_rate(&f);
  printf("rate=%d (expect ~10)\n",r); CHECK(r>=8 && r<=12);

  /* Cold seat: duty climbs by 1, and not faster than once every 3 s. */
  seat_hold_t h; seat_hold_init(&h);
  int d0 = seat_hold_step(&h, 3200, 1500, 0, 400, 100, 5500);
  CHECK(d0==0);
  int prev = 0;
  int jumped = 0;
  for(int i=0;i<40;i++){
    int d = seat_hold_step(&h, 3200, 1500, 0, 400, 100, 5500);
    if(d > prev+1) jumped = 1;
    prev = d;
  }
  CHECK(!jumped);
  CHECK(h.duty>=3 && h.duty<=8);
  printf("seek duty=%d\n", h.duty);

  /* Inside the band with a quiet rate: duty freezes, then becomes the hold. */
  seat_hold_init(&h);
  h.duty = 28;
  for(int i=0;i<40;i++) seat_hold_step(&h, 3200, 3180, 2, 400, 100, 5500);
  CHECK(h.duty==28);
  CHECK(h.occ==1);
  CHECK(h.hold==28);

  /* Probe still cold but rising fast: do not add duty. The wire is ahead. */
  seat_hold_init(&h);
  h.duty = 20;
  int d = 20;
  for(int i=0;i<10;i++) d = seat_hold_step(&h, 3200, 2000, 30, 400, 100, 5500);
  CHECK(d==19);

  /* Heating, still well below target, temperature falling: after 8 s, air. */
  seat_hold_init(&h);
  h.duty = 20;
  h.seek_ms = 20000;
  for(int i=0;i<45;i++) d = seat_hold_step(&h, 3200, 1800, -12, 400, 100, 5500);
  CHECK(h.occ==2);
  CHECK(d==0);
  d = seat_hold_step(&h, 3200, 1800, -12, 400, 100, 5500);
  CHECK(d==0);

  /* Closed loop. Plant equilibrium near 34% at 32 C. Probe lags 8 s.
   * Duty must settle without a 0/100 slap. */
  double mat=1500, probe=1500; seat_hold_init(&h); memset(&f,0,sizeof f); ms=0;
  double maxT=0; int duty=0; int slaps=0; int prevd=0; int hi=0;
  for(int step=0; step<4500; step++){
     mat += (duty*0.9 - (mat-1500)*0.018) * 0.4 * 0.8;
     probe += (mat-probe)*0.4/8.0;
     int raw=((int)(probe/12.5))*125/10;
     int fl=seat_filter_push(&f,raw,ms); ms+=400;
     int rt=seat_filter_rate(&f);
     duty=seat_hold_step(&h,3200,fl,rt,400,100,5500);
     if(duty>=90) hi++;
     if((prevd>=80 && duty==0) || (prevd==0 && duty>=80)) slaps++;
     prevd=duty;
     if(probe>maxT) maxT=probe;
  }
  printf("closed loop: probe=%.1f max=%.1f duty=%d occ=%d hold=%d slaps=%d hi=%d\n",
         probe, maxT, duty, h.occ, h.hold, slaps, hi);
  CHECK(slaps==0);
  CHECK(hi==0);
  CHECK(maxT<4000);
  CHECK(probe>3000 && probe<3600);
  CHECK(duty>=15 && duty<=60);
  printf(fails?"TESTS FAILED\n":"ALL OK\n"); return fails;
}
