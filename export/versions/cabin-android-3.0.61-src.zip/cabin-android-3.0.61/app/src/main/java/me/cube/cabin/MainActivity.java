package me.cube.cabin;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiNetworkSpecifier;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String BASE = "http://192.168.4.1";
    private static final int BG = 0xFF14120E;
    private static final int CARD = 0xFF211E18;
    private static final int FG = 0xFFF3EFE4;
    private static final int MUTED = 0xFFA39886;
    private static final int COPPER = 0xFFD9843B;
    private static final int INK = 0xFF2A1608;
    private static final int[] REG = {16, 17, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 47};
    private static final String[] REG_NAME = {
            "Ёмкость, Ач", "Цикл, Ач", "Пакет, перезаряд", "Пакет, возврат заряда",
            "Пакет, разряд", "Пакет, возврат разряда", "Ячейка, перезаряд", "Ячейка, возврат заряда",
            "Ячейка, разряд", "Ячейка, возврат разряда", "Ток заряда, А", "Ток разряда, А",
            "Баланс от, В", "Окно баланса, мВ", "Число ячеек"
    };
    private static final String[] REG_KIND = {
            "ah", "ah", "packv", "packv", "packv", "packv", "cellv", "cellv",
            "cellv", "cellv", "amp", "amp", "cellv", "mv", "n"
    };

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService net = Executors.newCachedThreadPool();
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback callback;
    private volatile Network cubeNet;
    private volatile boolean polling;
    private volatile boolean proxyRun;
    private boolean touching;
    private boolean wantConnect;
    private int tickN;
    private int bmsPack;
    private int proxyPort = -1;
    private double gpsKmh = -1;
    private ServerSocket proxy;
    private WebView web;
    private LocationManager locations;

    private TextView status;
    private TextView amb;
    private TextView lux;
    private TextView seat;
    private TextView duty;
    private TextView zvs;
    private TextView note;
    private TextView home;
    private TextView motorNow;
    private TextView bmsHead;
    private TextView cubeInfo;
    private Button heat;
    private Button[] heatMode = new Button[2];
    private Button[] light = new Button[3];
    private Button[] relay = new Button[3];
    private Button[] tabs = new Button[5];
    private View[] pages = new View[5];
    private int[] relayCh = {4, 2, 3};
    private SeekBar comfort;
    private SeekBar ceiling;
    private SeekBar manualDuty;
    private SeekBar ambOn;
    private SeekBar bright;
    private EditText circ;
    private EditText diam;
    private EditText gear;
    private EditText poles;
    private EditText trim;
    private EditText reqA;
    private TextView[] regNow = new TextView[REG.length];
    private EditText[] regIn = new EditText[REG.length];

    private Location prevFix;
    private LinearLayout fdList;
    private final LocationListener gps = new LocationListener() {
        @Override public void onLocationChanged(Location location) {
            if (location == null) return;
            double v = location.hasSpeed() ? Math.max(0, location.getSpeed() * 3.6) : -1;
            if (prevFix != null) {
                long dt = location.getTime() - prevFix.getTime();
                if (dt >= 400) {
                    double calc = location.distanceTo(prevFix) / (dt / 1000.0) * 3.6;
                    if (v < 0.5) v = calc;
                }
            }
            prevFix = new Location(location);
            if (v >= 0) gpsKmh = v;
            ui.post(MainActivity.this::paintGps);
        }
        @Override public void onStatusChanged(String p, int s, android.os.Bundle b) {}
        @Override public void onProviderEnabled(String p) {}
        @Override public void onProviderDisabled(String p) {}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        locations = (LocationManager) getSystemService(LOCATION_SERVICE);
        setContentView(build());
        show(0);
        startProxy();
        status.setText("Экран открыт. «Подключить» не забирает мобильный интернет.");
        if (hasLocation()) startGps();
    }

    @Override
    protected void onDestroy() {
        polling = false;
        proxyRun = false;
        if (callback != null && cm != null) {
            try { cm.unregisterNetworkCallback(callback); } catch (Exception ignored) {}
        }
        if (locations != null) {
            try { locations.removeUpdates(gps); } catch (Exception ignored) {}
        }
        if (proxy != null) {
            try { proxy.close(); } catch (Exception ignored) {}
        }
        if (web != null) web.destroy();
        net.shutdownNow();
        super.onDestroy();
    }

    private View build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(18), dp(12), dp(8));

        root.addView(label("Кабина 3.0.61", 26, FG, true));
        status = label("Открываю…", 13, MUTED, false);
        root.addView(status);
        Button join = button("Подключить Cube", true);
        join.setOnClickListener(v -> connect());
        root.addView(join);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Кабина", "Мотор", "АКБ", "Куб", "Схема"};
        for (int i = 0; i < names.length; i++) {
            final int n = i;
            tabs[i] = button(names[i], false);
            LinearLayout.LayoutParams tp = (LinearLayout.LayoutParams) tabs[i].getLayoutParams();
            tp.width = LinearLayout.LayoutParams.WRAP_CONTENT;
            tabs[i].setLayoutParams(tp);
            tabs[i].setOnClickListener(v -> show(n));
            bar.addView(tabs[i]);
        }
        hs.addView(bar);
        root.addView(hs);

        FrameLayout frame = new FrameLayout(this);
        pages[0] = scroll(pageCabin());
        pages[1] = scroll(pageMotor());
        pages[2] = scroll(pageBms());
        pages[3] = scroll(pageCube());
        pages[4] = scroll(pageScheme());
        for (View p : pages) frame.addView(p);
        root.addView(frame, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private LinearLayout pageCabin() {
        LinearLayout box = col();
        LinearLayout metrics = row();
        amb = metric(metrics, "Улица");
        lux = metric(metrics, "Свет");
        seat = metric(metrics, "Сиденье");
        box.addView(metrics);

        LinearLayout heatCard = card();
        heatCard.addView(label("Коврик", 18, FG, true));
        note = label("", 14, MUTED, false);
        heatCard.addView(note);
        heat = button("Подогрев выключен", false);
        heat.setOnClickListener(v -> post("/api/cabin", "heat=" + (heat.isSelected() ? "0" : "1")));
        heatCard.addView(heat);
        LinearLayout mode = row();
        String[] mn = {"Ручное", "Авто"};
        for (int i = 0; i < 2; i++) {
            final int m = i;
            heatMode[i] = button(mn[i], false);
            heatMode[i].setOnClickListener(v -> post("/api/cabin", "mode=" + m));
            mode.addView(heatMode[i], weight());
        }
        heatCard.addView(mode);
        duty = label("скважность 0%", 14, MUTED, false);
        heatCard.addView(duty);
        heatCard.addView(label("Шим, %", 14, MUTED, false));
        manualDuty = bar(0, 100, 0);
        manualDuty.setOnSeekBarChangeListener(slider("manual", 0));
        heatCard.addView(manualDuty);
        heatCard.addView(label("Улица, °C", 14, MUTED, false));
        ambOn = bar(0, 35, 20);
        ambOn.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { touching = fromUser; }
            @Override public void onStartTrackingTouch(SeekBar s) { touching = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                touching = false;
                post("/api/cabin", "amb_on=" + (s.getProgress() - 10));
            }
        });
        heatCard.addView(ambOn);
        heatCard.addView(label("Комфорт, °C", 14, MUTED, false));
        comfort = bar(15, 45, 32);
        comfort.setOnSeekBarChangeListener(slider("comfort", 15));
        heatCard.addView(comfort);
        heatCard.addView(label("Потолок, °C", 14, MUTED, false));
        ceiling = bar(28, 55, 42);
        ceiling.setOnSeekBarChangeListener(slider("seat_max", 28));
        heatCard.addView(ceiling);
        box.addView(heatCard);

        LinearLayout lightCard = card();
        lightCard.addView(label("Замок", 18, FG, true));
        LinearLayout seg = row();
        String[] ln = {"Выкл", "Вкл", "Авто"};
        for (int i = 0; i < 3; i++) {
            final int modeL = i;
            light[i] = button(ln[i], false);
            light[i].setOnClickListener(v -> post("/api/cabin", "light=" + modeL));
            seg.addView(light[i], weight());
        }
        lightCard.addView(seg);
        box.addView(lightCard);

        LinearLayout relCard = card();
        String[] rn = {"Реле 1", "Реле 2", "Реле 3"};
        for (int i = 0; i < rn.length; i++) {
            final int ch = relayCh[i];
            relay[i] = button(rn[i], false);
            relay[i].setOnClickListener(v -> post("/api/cabin", "r" + ch + "=" + (v.isSelected() ? "0" : "1")));
            relCard.addView(relay[i]);
        }
        box.addView(relCard);

        LinearLayout zCard = card();
        zvs = label("—", 32, COPPER, true);
        zCard.addView(zvs);
        box.addView(zCard);
        return box;
    }

    private LinearLayout pageMotor() {
        LinearLayout box = col();
        motorNow = label("Куб: нет связи\nGPS: ещё нет скорости", 18, FG, true);
        box.addView(cardOf(motorNow));
        LinearLayout form = card();
        form.addView(label("Колесо", 16, FG, true));
        circ = field("окружность, мм");
        form.addView(circ);
        diam = field("диаметр, мм");
        form.addView(diam);
        Button fromDiam = button("Окружность из диаметра", false);
        fromDiam.setOnClickListener(v -> {
            try {
                double mm = Double.parseDouble(diam.getText().toString().replace(',', '.'));
                circ.setText(String.valueOf((int) Math.round(mm * Math.PI)));
            } catch (Exception e) {
                status.setText("Диаметр не число");
            }
        });
        form.addView(fromDiam);
        gear = field("передача");
        gear.setText("1.000");
        form.addView(gear);
        poles = field("пары полюсов");
        poles.setText("20");
        form.addView(poles);
        trim = field("подгон, %");
        trim.setText("100");
        form.addView(trim);
        Button save = button("Записать в куб", true);
        save.setOnClickListener(v -> saveMotor(false));
        form.addView(save);
        Button fit = button("Подогнать под GPS", false);
        fit.setOnClickListener(v -> saveMotor(true));
        form.addView(fit);
        box.addView(form);

        LinearLayout lock = card();
        Button scan = button("Искать", false);
        scan.setOnClickListener(v -> post("/api/fdlink", "scan=1"));
        lock.addView(scan);
        Button drop = button("Отпустить", false);
        drop.setOnClickListener(v -> post("/api/fdlink", "drop=1"));
        lock.addView(drop);
        fdList = col();
        lock.addView(fdList);
        box.addView(lock);
        return box;
    }

    private LinearLayout pageBms() {
        LinearLayout box = col();
        bmsHead = label("АКБ ещё не прочитаны", 16, FG, true);
        box.addView(cardOf(bmsHead));
        LinearLayout role = card();
        Button reread = button("Прочитать регистры ещё раз", false);
        reread.setOnClickListener(v -> post("/api/bms", "read=1"));
        role.addView(reread);
        box.addView(role);
        for (int i = 0; i < REG.length; i++) {
            final int idx = i;
            LinearLayout row = card();
            row.addView(label(REG_NAME[i], 15, FG, true));
            regNow[i] = label("жду плату", 13, MUTED, false);
            row.addView(regNow[i]);
            regIn[i] = field("");
            row.addView(regIn[i]);
            Button w = button("Записать в плату", false);
            w.setOnClickListener(v -> writeReg(idx));
            row.addView(w);
            box.addView(row);
        }
        return box;
    }

    private LinearLayout pageCube() {
        LinearLayout box = col();
        cubeInfo = label("Сессия, станция и экран появятся после связи.", 15, FG, false);
        box.addView(cardOf(cubeInfo));
        LinearLayout req = card();
        req.addView(label("Запрос 240 В", 16, FG, true));
        reqA = field("амперы");
        req.addView(reqA);
        Button go = button("Записать ток", true);
        go.setOnClickListener(v -> {
            String amp = reqA.getText().toString().trim();
            if (amp.length() == 0) amp = "50";
            post("/api/setpoints", "i=" + amp);
        });
        req.addView(go);
        box.addView(req);
        LinearLayout scr = card();
        scr.addView(label("Яркость экрана", 16, FG, true));
        bright = bar(5, 100, 80);
        bright.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { touching = fromUser; }
            @Override public void onStartTrackingTouch(SeekBar s) { touching = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                touching = false;
                post("/api/panel", "br=" + s.getProgress());
            }
        });
        scr.addView(bright);
        box.addView(scr);
        LinearLayout proto = card();
        proto.addView(label("Протокол станции", 16, FG, true));
        String[] pn = {"Авто", "15/A", "2011", "23B"};
        for (int i = 0; i < pn.length; i++) {
            final int p = i;
            Button b = button(pn[i], false);
            b.setOnClickListener(v -> post("/api/panel", "proto=" + p));
            proto.addView(b);
        }
        box.addView(proto);
        LinearLayout acts = card();
        Button stop = button("Стоп сессии", false);
        stop.setOnClickListener(v -> post("/api/stop", ""));
        acts.addView(stop);
        addAction(acts, "Wi-Fi точки заново", "/api/panel", "wifi=1");
        addAction(acts, "BLE заново", "/api/panel", "ble=1");
        addAction(acts, "Перезагрузить куб", "/api/reboot", "");
        box.addView(acts);
        return box;
    }

    private void addAction(LinearLayout host, String title, String path, String body) {
        Button b = button(title, false);
        b.setOnClickListener(v -> post(path, body));
        host.addView(b);
    }

    private FrameLayout pageSite() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        try {
            web = new WebView(this);
            web.setBackgroundColor(BG);
            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    return rewrite(view, url);
                }
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return rewrite(view, request.getUrl().toString());
                }
            });
            frame.addView(web, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        } catch (Throwable t) {
            frame.addView(label("Встроенный сайт на этом телефоне не открылся. Вкладки выше работают.", 16, FG, false));
        }
        return frame;
    }

    private boolean rewrite(WebView view, String url) {
        if (url != null && url.startsWith(BASE)) {
            view.loadUrl("http://127.0.0.1:" + proxyPort + url.substring(BASE.length()));
            return true;
        }
        return false;
    }

    private LinearLayout pageScheme() {
        LinearLayout box = col();
        String[][] rows = {
                {"Три питания", "Пачка ~60 В: коврик, лампа, плюс на IN7. 12 В: лента, вход повышайки, затвор. Катушки реле — по надписи на синем кубике. 5 В: пин 5V и TJA1050. Логика только с 3,3 В. Земля одна."},
                {"8 реле", "Джампер JD-VCC снять. VCC логики на 3,3 В. JD-VCC: на корпусе 12V — от 12 В, 5V — от 5 В. Замыкаются COM и NO, когда IN на земле. NC не нужен. IN8 пустой."},
                {"IN1 лампа", "GPIO42. COM плюс пачки, NO плюс лампы, минус лампы на минус пачки. Это не Fardriver."},
                {"Реле", "IN1 фара. IN3 лента. IN5 выход преобразователя. IN4 кнопка «Реле 1». IN6 и IN7 станция. Повышайка питается постоянно."},
                {"IN3 лента", "GPIO40. COM плюс 12 В, NO плюс ленты."},
                {"IN4", "GPIO41. Кнопка «Реле 1». Питание повышайки этой ногой больше не рвётся."},
                {"IN5 повышайка выход", "GPIO38. Только плюс выхода. Запрос станции всегда 240 В."},
                {"IN6 подготовка", "GPIO6. NO на DC+ станции. Замыкается первым, станция видит повышайку."},
                {"IN7 пачка", "GPIO7. COM плюс пачки, NO на тот же DC+. Вместе с IN6 не включено. DC− на минус пачки."},
                {"Резистор", "10 кОм 10 Вт между HV+ и HV−, до IN5. На 100 В около 1 Вт. На 390 В будет 15 Вт, так не оставлять."},
                {"Делитель", "Четыре 470 кОм 1/4 Вт из набора от HV+ до узла, узел на GPIO4, с узла 10 кОм 1/4 Вт на минус повышайки. 12 кОм нет. Стабилитрона 3,3 В нет, 15 В сюда не ставить."},
                {"Расширителя нет", "IN сидят прямо на ногах. MCP23017 не паять."},
                {"BMP280", "Чёрная плата, дырки VIN GND SCL SDA. VIN только 3,3 В, пяти вольт там нет. SCL GPIO47, SDA GPIO15."},
                {"BH1750", "Синяя GY-302, дырки сверху: VCC 3,3 В, GND земля, SCL GPIO47, SDA GPIO15, ADDR на землю."},
                {"DS18B20", "Красный 3,3 В, чёрный земля, жёлтый GPIO8, 4,7 кОм между жёлтым и 3,3 В. T_IRQ экрана сюда не сажать."},
                {"IRFP250", "Надпись на себя, ноги вниз: затвор, сток, исток. Спина это сток. Плюс коврика на плюс пачки, минус коврика на сток, исток на минус пачки."},
                {"PC817", "Точка у ноги 1. Нога 1 через 330 Ом на GPIO5, нога 2 на землю, нога 4 на 12 В, нога 3 через 100 Ом на затвор. 4,7 кОм между затвором и истоком. Стабилитрон 15 В полоской к затвору. 1N5408 полоской к плюсу коврика."},
                {"TJA1050", "Надписи слева направо: CANH и CANL на станцию. Любая GND на землю куба. CTX напрямую на GPIO17. CRX через 10 кОм на GPIO18, от GPIO18 резистор 20 кОм на землю. Дырка 5V на пин 5V. Дырку 3.3 не подключать. Транзисторы не паять."},
                {"АКБ одна", "T1409. TTL: VCC на 3V3 куба, GND на землю, RXD от GPIO1, TXD на GPIO2. RS232: GND на землю UART BMS, TXD на RX BMS, RXD на TX BMS. Ногу 11–15 В разъёма BMS на эту плату не сажать."},
                {"Не трогать", "GPIO 0, 3, 45, 46, 19, 20, 26–37, 43, 44, 48. Экран SPI: 12, 11, 9, 10, 13, 14, 21, тач CS 16. Fardriver проводами не подключать."}
        };
        for (String[] row : rows) {
            LinearLayout c = card();
            c.addView(label(row[0], 16, FG, true));
            c.addView(hint(row[1]));
            box.addView(c);
        }
        return box;
    }

    private void show(int n) {
        for (int i = 0; i < pages.length; i++) {
            pages[i].setVisibility(i == n ? View.VISIBLE : View.GONE);
            mark(tabs[i], i == n);
        }
    }

    private void connect() {
        wantConnect = true;
        if (!permsOk()) {
            requestPerms();
            status.setText("Разреши геолокацию. На Android 13 ещё «устройства рядом». Без этого сеть Cube система не отдаёт.");
            return;
        }
        status.setText("Ищу куб. Мобильный интернет не переключаю.");
        if (hasLocation()) startGps();
        net.execute(() -> {
            String body = http("GET", "/api/status", null);
            if (body != null) ui.post(this::startPoll);
            else ui.post(this::askWifi);
        });
    }

    private boolean permsOk() {
        if (Build.VERSION.SDK_INT < 23) return true;
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            return false;
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED)
            return false;
        return true;
    }

    private void requestPerms() {
        if (Build.VERSION.SDK_INT < 23) return;
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION,
                    android.Manifest.permission.NEARBY_WIFI_DEVICES
            }, 7);
        } else {
            requestPermissions(new String[]{
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
            }, 7);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (hasLocation()) startGps();
        if (wantConnect && permsOk()) connect();
        else if (wantConnect) status.setText("Без разрешения сеть Cube не вызвать. Остальные вкладки можно смотреть.");
    }

    private boolean hasLocation() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressLint("MissingPermission")
    private void startGps() {
        if (locations == null || !hasLocation()) return;
        try {
            Location last = locations.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null) last = locations.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null) gps.onLocationChanged(last);
        } catch (Exception ignored) {}
        try { locations.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0f, gps); } catch (Exception ignored) {}
        try { locations.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0f, gps); } catch (Exception ignored) {}
    }

    private void askWifi() {
        try {
            if (Build.VERSION.SDK_INT >= 29) askModern();
            else askLegacy();
        } catch (Throwable e) {
            status.setText("Wi-Fi не запросился: " + e.getClass().getSimpleName());
        }
    }

    private void askModern() {
        if (callback != null) {
            try { cm.unregisterNetworkCallback(callback); } catch (Exception ignored) {}
            callback = null;
        }
        WifiNetworkSpecifier spec = new WifiNetworkSpecifier.Builder()
                .setSsid("Cube")
                .setWpa2Passphrase("12345678")
                .build();
        NetworkRequest req = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(spec)
                .build();
        callback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                cubeNet = network;
                ui.post(() -> {
                    status.setText("Cube есть. Мобильный интернет остаётся у телефона.");
                    startPoll();
                });
            }
            @Override public void onUnavailable() {
                ui.post(() -> status.setText("Окно Cube закрыли или точка не найдена"));
            }
        };
        cm.requestNetwork(req, callback);
        status.setText("В системном окне нажми подключить Cube");
    }

    @SuppressWarnings("deprecation")
    private void askLegacy() {
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        if (wm != null) {
            if (!wm.isWifiEnabled()) wm.setWifiEnabled(true);
            WifiConfiguration conf = new WifiConfiguration();
            conf.SSID = "\"Cube\"";
            conf.preSharedKey = "\"12345678\"";
            conf.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
            int id = wm.addNetwork(conf);
            if (id >= 0) {
                wm.disconnect();
                wm.enableNetwork(id, true);
                wm.reconnect();
            }
        }
        status.setText("Android до 10: система сама может спросить, оставлять ли мобильный интернет.");
        net.execute(() -> {
            for (int i = 0; i < 24; i++) {
                if (http("GET", "/api/status", null) != null) {
                    ui.post(this::startPoll);
                    return;
                }
                try { Thread.sleep(500); } catch (InterruptedException e) { return; }
            }
            ui.post(() -> status.setText("Куб не ответил"));
        });
    }

    private void startPoll() {
        if (polling) return;
        polling = true;
        tick();
    }

    private void tick() {
        if (!polling) return;
        final int n = ++tickN;
        net.execute(() -> {
            String st = http("GET", "/api/status", null);
            String cab = http("GET", "/api/cabin", null);
            String bms = (n % 3 == 0) ? http("GET", "/api/bms", null) : null;
            String fd = (n % 2 == 0) ? http("GET", "/api/fdscan", null) : null;
            ui.post(() -> {
                if (st == null && cab == null) status.setText("Куб молчит");
                else status.setText("На связи. Мобильный интернет не занят кубом.");
                if (cab != null) paintCabin(cab);
                if (st != null) paintStatus(st);
                if (bms != null) paintBms(bms);
                if (fd != null) paintFd(fd);
                ui.postDelayed(this::tick, 1000);
            });
        });
    }

    private void post(String path, String form) {
        net.execute(() -> http("POST", path, form == null ? "" : form));
    }

    private Network cubeNetwork() {
        Network held = cubeNet;
        if (held != null) return held;
        if (cm == null) return null;
        try {
            Network[] all = cm.getAllNetworks();
            for (Network n : all) {
                LinkProperties lp = cm.getLinkProperties(n);
                if (lp == null) continue;
                for (LinkAddress a : lp.getLinkAddresses()) {
                    if (a.getAddress() instanceof Inet4Address) {
                        String host = a.getAddress().getHostAddress();
                        if (host != null && host.startsWith("192.168.4.")) return n;
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private String http(String method, String path, String form) {
        HttpURLConnection c = null;
        try {
            URL url = new URL(BASE + path);
            Network n = cubeNetwork();
            c = (HttpURLConnection) (n != null ? n.openConnection(url) : url.openConnection());
            c.setConnectTimeout(2500);
            c.setReadTimeout(5000);
            c.setRequestMethod(method);
            if (form != null) {
                byte[] b = form.getBytes(StandardCharsets.UTF_8);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                OutputStream os = c.getOutputStream();
                os.write(b);
                os.close();
            }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null || code >= 400) return null;
            return readAll(in, 700000);
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private String readAll(InputStream in, int cap) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        int total = 0;
        while ((n = in.read(buf)) > 0 && total < cap) {
            bos.write(buf, 0, n);
            total += n;
        }
        return bos.toString("UTF-8");
    }

    private void paintCabin(String body) {
        try {
            JSONObject j = new JSONObject(body);
            amb.setText(j.optInt("bme") == 1 ? temp(j.optInt("amb")) : "нет");
            lux.setText(j.optInt("bh") == 1 ? (j.optInt("lux") + " лк") : "нет");
            seat.setText(j.optInt("seat_ok") == 1 ? temp(j.optInt("seat")) : "нет");
            int d = j.optInt("duty");
            duty.setText("скважность " + d + "%");
            boolean hon = j.optInt("heat") == 1;
            mark(heat, hon);
            heat.setText(hon ? "Подогрев включён" : "Подогрев выключен");
            String fault = j.optString("fault", "");
            if ("seat".equals(fault)) note.setText("Датчика на коврике нет.");
            else if ("hot".equals(fault)) note.setText("Потолок.");
            else if ("zvs".equals(fault)) note.setText("Выход разомкнут, выше предела.");
            else if ("pile".equals(fault)) note.setText("Станция дала ток, выход разомкнут.");
            else if (j.optInt("mode") == 1) note.setText("Авто.");
            else note.setText("Ручное " + j.optInt("manual") + "%.");
            int hm = j.optInt("mode");
            for (int i = 0; i < heatMode.length; i++) mark(heatMode[i], i == hm);
            int mode = j.optInt("light");
            for (int i = 0; i < light.length; i++) mark(light[i], i == mode);
            int rel = j.optInt("rel");
            for (int i = 0; i < relay.length; i++) mark(relay[i], (rel & (1 << relayCh[i])) != 0);
            zvs.setText(j.optInt("zvs_ok") == 1 ? (j.optInt("zvs_mv") / 1000 + " В") : "нет");
            if (!touching) {
                comfort.setProgress(j.optInt("comfort") / 100);
                ceiling.setProgress(j.optInt("seat_max") / 100);
                manualDuty.setProgress(j.optInt("manual"));
                ambOn.setProgress(j.optInt("amb_on", 1000) / 100 + 10);
            }
        } catch (Exception ignored) {}
    }

    private void paintFd(String body) {
        if (fdList == null) return;
        try {
            JSONObject j = new JSONObject(body);
            JSONArray items = j.optJSONArray("items");
            fdList.removeAllViews();
            if (j.optInt("link") == 1)
                fdList.addView(label(j.optString("name") + " " + j.optString("peer"), 14, COPPER, true));
            if (items == null) return;
            for (int i = 0; i < items.length(); i++) {
                JSONObject it = items.getJSONObject(i);
                String addr = it.optString("addr");
                String name = it.optString("name");
                if (name.length() == 0) name = addr;
                Button b = button(name, false);
                b.setOnClickListener(v -> post("/api/fdlink", "addr=" + addr));
                fdList.addView(b);
            }
        } catch (Exception ignored) {}
    }

    private void paintStatus(String body) {
        try {
            JSONObject j = new JSONObject(body);
            double cube = j.optInt("fd_kmh10") / 10.0;
            int rpm = j.optInt("fd_rpm");
            String link = j.optInt("fd_link") == 1 ? "есть" : "нет";
            motorNow.setText("Куб " + one(cube) + " км/ч   GPS " + (gpsKmh < 0 ? "ждёт" : one(gpsKmh) + " км/ч")
                    + "\nобороты " + rpm + "   связь " + link
                    + "\nток " + one(j.optInt("fd_amps10") / 10.0) + " А   "
                    + one(j.optInt("fd_volts10") / 10.0) + " В   ошибка " + j.optInt("fd_err"));
            if (!circ.isFocused() && j.has("fd_circ")) circ.setText(String.valueOf(j.optInt("fd_circ")));
            if (!gear.isFocused() && j.has("fd_gear")) gear.setText(String.format(java.util.Locale.US, "%.3f", j.optInt("fd_gear") / 1000.0));
            if (!poles.isFocused() && j.optInt("fd_poles") > 0) poles.setText(String.valueOf(j.optInt("fd_poles")));
            if (!trim.isFocused() && j.has("fd_trim")) trim.setText(String.format(java.util.Locale.US, "%.1f", j.optInt("fd_trim") / 10.0));
            if (!diam.isFocused() && j.optInt("fd_diam") > 0)
                diam.setText(String.valueOf((int) Math.round(j.optInt("fd_diam") / 10.0 * 25.4)));
            if (!touching && j.has("br")) bright.setProgress(j.optInt("br"));
            cubeInfo.setText("Прошивка " + j.optString("fw") + " " + j.optString("version")
                    + "\nстанция " + j.optString("stage") + "  протокол " + j.optString("protocol")
                    + "\n" + one(j.optDouble("voltage_v")) + " В  " + one(j.optDouble("current_a")) + " А  "
                    + j.optLong("power_w") + " Вт  SOC " + j.optInt("soc") + "%"
                    + "\nАКБ A: " + j.optString("bms_a")
                    + "\nАКБ: " + j.optString("bms_a")
                    + "\nреле станции " + j.optInt("relay_a") + " / " + j.optInt("relay_b"));
        } catch (Exception ignored) {}
    }

    private void paintGps() {
        if (motorNow == null) return;
        String cur = motorNow.getText().toString();
        int nl = cur.indexOf('\n');
        String rest = nl >= 0 ? cur.substring(nl) : "";
        String head = cur;
        if (nl >= 0) head = cur.substring(0, nl);
        int gpsAt = head.indexOf("GPS");
        if (gpsAt >= 0) head = head.substring(0, gpsAt) + "GPS " + (gpsKmh < 0 ? "ждёт" : one(gpsKmh) + " км/ч");
        motorNow.setText(head + rest);
    }

    private void paintBms(String body) {
        try {
            JSONObject root = new JSONObject(body);
            JSONArray packs = root.optJSONArray("packs");
            if (packs == null || bmsPack >= packs.length()) {
                bmsHead.setText("Плата не ответила");
                return;
            }
            JSONObject p = packs.getJSONObject(bmsPack);
            if (!p.optBoolean("ok")) {
                bmsHead.setText("АКБ " + (bmsPack == 0 ? "A" : "B") + ": нет связи");
                return;
            }
            StringBuilder cells = new StringBuilder();
            JSONArray cv = p.optJSONArray("cells");
            if (cv != null) {
                for (int i = 0; i < cv.length(); i++) {
                    if (i > 0) cells.append(' ');
                    cells.append(String.format(java.util.Locale.US, "%.3f", cv.optInt(i) / 1000.0));
                }
            }
            bmsHead.setText("АКБ " + (bmsPack == 0 ? "A" : "B")
                    + "  " + one(p.optInt("mv") / 1000.0) + " В  " + one(p.optInt("ma") / 1000.0) + " А  SOC " + p.optInt("soc") + "%"
                    + "\n" + cells);
            JSONArray regs = p.optJSONArray("regs");
            int div = p.optInt("amp_div");
            for (int i = 0; i < REG.length; i++) {
                JSONObject rec = null;
                if (regs != null) {
                    for (int k = 0; k < regs.length(); k++) {
                        JSONObject r = regs.getJSONObject(k);
                        if (r.optInt("r") == REG[i]) { rec = r; break; }
                    }
                }
                if (rec == null || rec.optInt("ok") != 1) {
                    regNow[i].setText("жду это число с платы");
                    continue;
                }
                int raw = rec.optInt("v");
                int scale = scaleOf(REG_KIND[i], raw, div);
                regNow[i].setText("в плате: " + view(REG_KIND[i], raw, scale));
                if (!regIn[i].isFocused()) {
                    regIn[i].setText(view(REG_KIND[i], raw, scale));
                    regIn[i].setTag(scale);
                }
            }
        } catch (Exception ignored) {}
    }

    private void writeReg(int idx) {
        try {
            int scale = regIn[idx].getTag() instanceof Integer ? (Integer) regIn[idx].getTag() : 1;
            double n = Double.parseDouble(regIn[idx].getText().toString().replace(',', '.'));
            int mag = (int) Math.round(Math.abs(n) * scale);
            if (REG[idx] == 41) mag = -mag;
            post("/api/bms", "pack=" + bmsPack + "&reg=" + REG[idx] + "&value=" + mag);
            status.setText("Пишу регистр " + REG[idx]);
        } catch (Exception e) {
            status.setText("Число не разобрать");
        }
    }

    private int scaleOf(String kind, int raw, int div) {
        int a = Math.abs(raw);
        if ("amp".equals(kind)) {
            if (div == 10 || div == 100) return div;
            if (a >= 500) return 100;
            if (a >= 200) return 10;
            return 1;
        }
        if ("ah".equals(kind)) return a >= 200 ? 100 : 1;
        if ("packv".equals(kind)) return 100;
        if ("cellv".equals(kind)) return 1000;
        return 1;
    }

    private String view(String kind, int raw, int scale) {
        double shown = Math.abs(raw) / (double) scale;
        if ("packv".equals(kind)) return String.format(java.util.Locale.US, "%.2f", shown);
        if ("cellv".equals(kind)) return String.format(java.util.Locale.US, "%.3f", shown);
        if ("ah".equals(kind) && scale > 1) return String.format(java.util.Locale.US, "%.2f", shown);
        if ("amp".equals(kind) && scale >= 100) return String.format(java.util.Locale.US, "%.2f", shown);
        if ("amp".equals(kind) && scale == 10) return String.format(java.util.Locale.US, "%.1f", shown);
        return String.valueOf((int) Math.round(shown));
    }

    private void saveMotor(boolean fitGps) {
        try {
            int circMm = parseInt(circ.getText().toString(), 0);
            int gearX = (int) Math.round(parseDouble(gear.getText().toString(), 1) * 1000);
            int trimX = (int) Math.round(parseDouble(trim.getText().toString(), 100) * 10);
            int poleN = parseInt(poles.getText().toString(), 20);
            double diamMm = parseDouble(diam.getText().toString(), 0);
            if (fitGps) {
                double cube = 0;
                String t = motorNow.getText().toString();
                int at = t.indexOf("Куб ");
                if (at >= 0) cube = parseDouble(t.substring(at + 4), 0);
                if (gpsKmh < 3 || cube < 3) {
                    status.setText("Для подгона нужны обе скорости больше 3 км/ч");
                    return;
                }
                trimX = (int) Math.round(trimX * gpsKmh / cube);
                if (trimX < 200) trimX = 200;
                if (trimX > 3000) trimX = 3000;
                trim.setText(String.format(java.util.Locale.US, "%.1f", trimX / 10.0));
            }
            double inches = diamMm > 0 ? diamMm / 25.4 : 0;
            StringBuilder q = new StringBuilder();
            q.append("circ=").append(circMm);
            q.append("&gear=").append(gearX);
            q.append("&trim=").append(trimX);
            q.append("&poles=").append(poleN);
            if (inches >= 8 && inches <= 40) q.append("&diam=").append(String.format(java.util.Locale.US, "%.1f", inches));
            post("/api/fardriver", q.toString());
            status.setText(fitGps ? "Подгон записан в куб" : "Размеры записаны в куб");
        } catch (Exception e) {
            status.setText("Поле мотора не число");
        }
    }

    private void startProxy() {
        try {
            proxy = new ServerSocket();
            proxy.setReuseAddress(true);
            proxy.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0));
            proxyPort = proxy.getLocalPort();
            proxyRun = true;
            net.execute(this::proxyLoop);
        } catch (Exception e) {
            proxyPort = -1;
        }
    }

    private void proxyLoop() {
        while (proxyRun) {
            try {
                Socket s = proxy.accept();
                net.execute(() -> serve(s));
            } catch (Exception e) {
                if (!proxyRun) return;
            }
        }
    }

    private void serve(Socket s) {
        try {
            s.setSoTimeout(8000);
            InputStream in = s.getInputStream();
            ByteArrayOutputStream head = new ByteArrayOutputStream();
            int prev = 0;
            while (head.size() < 8192) {
                int b = in.read();
                if (b < 0) break;
                head.write(b);
                if (prev == '\n' && b == '\n') break;
                if (head.size() >= 4) {
                    byte[] a = head.toByteArray();
                    int n = a.length;
                    if (n >= 4 && a[n - 4] == '\r' && a[n - 3] == '\n' && a[n - 2] == '\r' && a[n - 1] == '\n') break;
                }
                prev = b;
            }
            String hs = head.toString("ISO-8859-1");
            String[] lines = hs.split("\r\n");
            if (lines.length == 0 || lines[0].length() == 0) { s.close(); return; }
            String[] req = lines[0].split(" ");
            String method = req[0];
            String path = req.length > 1 ? req[1] : "/";
            int clen = 0;
            for (String line : lines) {
                if (line.toLowerCase(java.util.Locale.US).startsWith("content-length:")) {
                    clen = Integer.parseInt(line.substring(15).trim());
                }
            }
            byte[] body = new byte[Math.max(0, Math.min(clen, 2000000))];
            int got = 0;
            while (got < body.length) {
                int r = in.read(body, got, body.length - got);
                if (r < 0) break;
                got += r;
            }
            byte[] outBody;
            String ctype = "text/html; charset=utf-8";
            int code = 200;
            HttpURLConnection c = null;
            try {
                URL url = new URL(BASE + path);
                Network n = cubeNetwork();
                c = (HttpURLConnection) (n != null ? n.openConnection(url) : url.openConnection());
                c.setConnectTimeout(3000);
                c.setReadTimeout(8000);
                c.setRequestMethod(method);
                if (got > 0 && !"GET".equals(method) && !"HEAD".equals(method)) {
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    OutputStream os = c.getOutputStream();
                    os.write(body, 0, got);
                    os.close();
                }
                code = c.getResponseCode();
                if (c.getContentType() != null) ctype = c.getContentType();
                InputStream rin = code >= 400 ? c.getErrorStream() : c.getInputStream();
                outBody = rin == null ? new byte[0] : readBytes(rin, 4000000);
            } catch (Exception e) {
                code = 503;
                outBody = "<html><body style='background:#14120e;color:#f3efe4;font-family:sans-serif'><p>Куб ещё не в этой сети. Нажми «Подключить». Мобильный интернет при этом не отключается. Вкладки Кабина, Мотор, АКБ, Куб и Схема листаются и без связи.</p></body></html>".getBytes(StandardCharsets.UTF_8);
            } finally {
                if (c != null) c.disconnect();
            }
            String reason = code == 200 ? "OK" : "ERR";
            String hdr = "HTTP/1.1 " + code + " " + reason + "\r\nContent-Type: " + ctype
                    + "\r\nContent-Length: " + outBody.length + "\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n";
            OutputStream os = s.getOutputStream();
            os.write(hdr.getBytes(StandardCharsets.ISO_8859_1));
            os.write(outBody);
            os.flush();
        } catch (Exception ignored) {
        } finally {
            try { s.close(); } catch (Exception ignored) {}
        }
    }

    private byte[] readBytes(InputStream in, int cap) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        int total = 0;
        while ((n = in.read(buf)) > 0 && total < cap) {
            bos.write(buf, 0, n);
            total += n;
        }
        return bos.toByteArray();
    }

    private LinearLayout scroll(LinearLayout child) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(child);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.addView(sv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
        return wrap;
    }

    private LinearLayout col() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(0, dp(8), 0, dp(24));
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(CARD));
        int p = dp(12);
        l.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        l.setLayoutParams(lp);
        return l;
    }

    private LinearLayout cardOf(View v) {
        LinearLayout c = card();
        c.addView(v);
        return c;
    }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView hint(String text) {
        TextView t = label(text, 13, MUTED, false);
        t.setPadding(0, dp(6), 0, dp(4));
        return t;
    }

    private TextView metric(LinearLayout host, String name) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(round(CARD));
        box.setPadding(dp(8), dp(8), dp(8), dp(8));
        TextView k = label(name, 12, MUTED, false);
        TextView v = label("—", 18, FG, true);
        box.addView(k);
        box.addView(v);
        host.addView(box, weight());
        return v;
    }

    private Button button(String text, boolean fill) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(fill ? INK : FG);
        b.setBackground(round(fill ? COPPER : 0x00000000));
        if (!fill) b.setBackground(stroke());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(6);
        lp.rightMargin = dp(4);
        b.setLayoutParams(lp);
        return b;
    }

    private EditText field(String hintText) {
        EditText e = new EditText(this);
        e.setHint(hintText);
        e.setHintTextColor(MUTED);
        e.setTextColor(FG);
        e.setBackground(stroke());
        e.setPadding(dp(10), dp(8), dp(10), dp(8));
        e.setSingleLine(true);
        return e;
    }

    private SeekBar bar(int min, int max, int value) {
        SeekBar s = new SeekBar(this);
        s.setMax(max);
        if (Build.VERSION.SDK_INT >= 26) s.setMin(min);
        s.setProgress(value);
        return s;
    }

    private SeekBar.OnSeekBarChangeListener slider(String key, int min) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { touching = fromUser; }
            @Override public void onStartTrackingTouch(SeekBar s) { touching = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                touching = false;
                int v = Math.max(min, s.getProgress());
                post("/api/cabin", key + "=" + v);
            }
        };
    }

    private void mark(Button b, boolean on) {
        if (b == null) return;
        b.setSelected(on);
        b.setBackground(on ? round(COPPER) : stroke());
        b.setTextColor(on ? INK : FG);
    }

    private GradientDrawable round(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(10));
        return d;
    }

    private GradientDrawable stroke() {
        GradientDrawable d = round(0x00000000);
        d.setStroke(dp(1), 0xFF3A342C);
        return d;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private String temp(int hundredths) {
        int sign = hundredths < 0 ? -1 : 1;
        int a = Math.abs(hundredths);
        return (sign < 0 ? "-" : "") + (a / 100) + "." + (a % 100 / 10) + "°";
    }

    private String one(double v) {
        return String.format(java.util.Locale.US, "%.1f", v);
    }

    private int parseInt(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return fallback; }
    }

    private double parseDouble(String s, double fallback) {
        try { return Double.parseDouble(s.trim().replace(',', '.')); } catch (Exception e) { return fallback; }
    }
}
