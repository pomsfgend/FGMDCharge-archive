#include "config.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "FARDRIVER";

/* Controller display bridge, 19200 8N1. UART0 is free because the console
 * is USB-Serial-JTAG. GPIO39 is input-only on S3, so it can only be RX. */
static void fd_task(void *arg)
{
    uint8_t buf[64];
    uint32_t rx = 0;
    (void)arg;
    for (;;) {
        int n = uart_read_bytes(UART_NUM_0, buf, sizeof(buf), pdMS_TO_TICKS(500));
        if (n > 0) rx += (uint32_t)n;
        (void)rx;
    }
}

void fardriver_init(void)
{
#if CONFIG_ESP_CONSOLE_UART_NUM == 0
    ESP_LOGW(TAG, "мост не открыт: UART0 занят консолью");
    return;
#else
    uart_config_t cfg = {
        .baud_rate = 19200,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_APB,
    };
    ESP_ERROR_CHECK(uart_driver_install(UART_NUM_0, 1024, 0, 0, NULL, 0));
    ESP_ERROR_CHECK(uart_param_config(UART_NUM_0, &cfg));
    ESP_ERROR_CHECK(uart_set_pin(UART_NUM_0, CUBE_FD_TX_GPIO, CUBE_FD_RX_GPIO,
                                 UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    ESP_LOGW(TAG, "мост 19200 RX%d TX%d", CUBE_FD_RX_GPIO, CUBE_FD_TX_GPIO);
    xTaskCreate(fd_task, "fardriver", 2048, NULL, 1, NULL);
#endif
}
