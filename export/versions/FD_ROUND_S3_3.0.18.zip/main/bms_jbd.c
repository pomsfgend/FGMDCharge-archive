#include "bms_jbd.h"
#include "config.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdio.h>
#include <string.h>

static const char *TAG = "BMS";

/* JBD / Xiaoxiang, 9600 8N1.
 * Request:  DD A5 cmd 00 chk_hi chk_lo 77
 * Response: DD cmd status len data... chk_hi chk_lo 77
 * Checksum = 0x10000 - sum(status + len + data). */
#define BMS_MAX 160

typedef struct {
    uart_port_t port;
    const char *name;
    uint8_t acc[BMS_MAX];
    int n;
    bms_pack_t pub;
    uint32_t last_ok_ms;
    uint32_t noise_log_ms;
    int which; /* 0 info, 1 cells */
} bms_port_t;

static bms_port_t s_a;
static bms_port_t s_b;
static portMUX_TYPE s_mux = portMUX_INITIALIZER_UNLOCKED;

static uint16_t be16(const uint8_t *p)
{
    return (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
}

static void build_read(uint8_t cmd, uint8_t out[7])
{
    uint16_t chk = (uint16_t)(0x10000u - (uint16_t)cmd);
    out[0] = 0xDD;
    out[1] = 0xA5;
    out[2] = cmd;
    out[3] = 0x00;
    out[4] = (uint8_t)(chk >> 8);
    out[5] = (uint8_t)chk;
    out[6] = 0x77;
}

/* Eat one valid frame from the front of acc. Returns 1 if a frame was consumed. */
static int take_frame(bms_port_t *p)
{
    int i;
    for (i = 0; i < p->n; ++i) {
        if (p->acc[i] == 0xDD) break;
    }
    if (i > 0) {
        memmove(p->acc, p->acc + i, (size_t)(p->n - i));
        p->n -= i;
    }
    if (p->n < 7) return 0;
    uint8_t cmd = p->acc[1];
    uint8_t status = p->acc[2];
    uint8_t len = p->acc[3];
    if (len > 80 || (cmd != 0x03 && cmd != 0x04)) {
        memmove(p->acc, p->acc + 1, (size_t)(p->n - 1));
        p->n -= 1;
        return 1;
    }
    if (p->n < (int)len + 7) return 0;
    if (p->acc[4 + len + 2] != 0x77) {
        memmove(p->acc, p->acc + 1, (size_t)(p->n - 1));
        p->n -= 1;
        return 1;
    }
    uint32_t sum = (uint32_t)status + len;
    for (uint8_t k = 0; k < len; ++k) sum += p->acc[4 + k];
    uint16_t chk = (uint16_t)(0x10000u - sum);
    if (be16(&p->acc[4 + len]) != chk || status != 0x00) {
        memmove(p->acc, p->acc + 1, (size_t)(p->n - 1));
        p->n -= 1;
        return 1;
    }
    const uint8_t *d = &p->acc[4];
    portENTER_CRITICAL(&s_mux);
    if (cmd == 0x03 && len >= 23) {
        p->pub.voltage_v = be16(d + 0) * 0.01f;
        p->pub.current_a = (int16_t)be16(d + 2) * 0.01f;
        p->pub.soc = d[19];
        p->pub.cells = d[21];
        p->pub.state = 1;
        p->pub.frames++;
        p->last_ok_ms = (uint32_t)(esp_timer_get_time() / 1000ULL);
    } else if (cmd == 0x04 && len >= 2) {
        int cells = len / 2;
        uint16_t mn = 0xFFFF, mx = 0;
        if (cells > 32) cells = 32;
        for (int c = 0; c < cells; ++c) {
            uint16_t mv = be16(d + 2 * c);
            if (mv < mn) mn = mv;
            if (mv > mx) mx = mv;
        }
        p->pub.cell_min_mv = mn;
        p->pub.cell_max_mv = mx;
        p->pub.cells = (uint8_t)cells;
        p->pub.state = 1;
        p->pub.frames++;
        p->last_ok_ms = (uint32_t)(esp_timer_get_time() / 1000ULL);
    }
    portEXIT_CRITICAL(&s_mux);
    int used = (int)len + 7;
    memmove(p->acc, p->acc + used, (size_t)(p->n - used));
    p->n -= used;
    return 1;
}

static void open_port(bms_port_t *p, uart_port_t uart, int tx, int rx, const char *name)
{
    uart_config_t cfg = {
        .baud_rate = 9600,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_APB,
    };
    memset(p, 0, sizeof(*p));
    p->port = uart;
    p->name = name;
    p->pub.state = 0;
    ESP_ERROR_CHECK(uart_driver_install(uart, 512, 0, 0, NULL, 0));
    ESP_ERROR_CHECK(uart_param_config(uart, &cfg));
    ESP_ERROR_CHECK(uart_set_pin(uart, tx, rx, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
}

static void poll_one(bms_port_t *p)
{
    uint8_t req[7];
    uint8_t tmp[64];
    int got;
    build_read(p->which ? 0x04 : 0x03, req);
    p->which ^= 1;
    uart_write_bytes(p->port, (const char *)req, 7);
    /* JBD answers in a few tens of ms. Keep the rest for the next poll. */
    got = uart_read_bytes(p->port, tmp, sizeof(tmp), pdMS_TO_TICKS(80));
    if (got > 0) {
        portENTER_CRITICAL(&s_mux);
        p->pub.rx_bytes += (uint32_t)got;
        portEXIT_CRITICAL(&s_mux);
        if (p->n + got > BMS_MAX) {
            int drop = p->n + got - BMS_MAX;
            if (drop > p->n) drop = p->n;
            memmove(p->acc, p->acc + drop, (size_t)(p->n - drop));
            p->n -= drop;
        }
        memcpy(p->acc + p->n, tmp, (size_t)got);
        p->n += got;
        while (take_frame(p)) {
        }
    }
    uint32_t now = (uint32_t)(esp_timer_get_time() / 1000ULL);
    portENTER_CRITICAL(&s_mux);
    if (p->pub.frames == 0 && now > 2500) {
        p->pub.state = (p->pub.rx_bytes > 0) ? 3 : 2;
    } else if (p->last_ok_ms != 0 && (uint32_t)(now - p->last_ok_ms) > 4000) {
        p->pub.state = (p->pub.rx_bytes > 0) ? 3 : 2;
    }
    int st = p->pub.state;
    uint32_t rx = p->pub.rx_bytes;
    portEXIT_CRITICAL(&s_mux);
    if (st == 3 && (uint32_t)(now - p->noise_log_ms) > 10000) {
        char hex[48];
        int k, o = 0;
        int show = p->n > 8 ? 8 : p->n;
        p->noise_log_ms = now;
        for (k = 0; k < show && o < (int)sizeof(hex) - 4; ++k) {
            o += snprintf(hex + o, sizeof(hex) - (size_t)o, "%02X", p->acc[k]);
        }
        ESP_LOGW(TAG, "%s байты есть (%lu), кадра нет, голова %s", p->name,
                 (unsigned long)rx, hex);
    }
}

static void bms_task(void *arg)
{
    (void)arg;
    for (;;) {
        poll_one(&s_a);
        poll_one(&s_b);
        vTaskDelay(pdMS_TO_TICKS(350));
    }
}

void bms_jbd_init(void)
{
    open_port(&s_a, UART_NUM_1, CUBE_BMS_A_TX_GPIO, CUBE_BMS_A_RX_GPIO, "JBD-A");
    open_port(&s_b, UART_NUM_2, CUBE_BMS_B_TX_GPIO, CUBE_BMS_B_RX_GPIO, "JBD-B");
    ESP_LOGW(TAG, "UART 9600: A TX%d/RX%d, B TX%d/RX%d. +13 В разъёма на ESP не подавать",
             CUBE_BMS_A_TX_GPIO, CUBE_BMS_A_RX_GPIO, CUBE_BMS_B_TX_GPIO, CUBE_BMS_B_RX_GPIO);
    xTaskCreate(bms_task, "bms_jbd", 3072, NULL, 2, NULL);
}

void bms_jbd_snapshot(bms_pack_t *a, bms_pack_t *b)
{
    portENTER_CRITICAL(&s_mux);
    if (a) *a = s_a.pub;
    if (b) *b = s_b.pub;
    portEXIT_CRITICAL(&s_mux);
}
