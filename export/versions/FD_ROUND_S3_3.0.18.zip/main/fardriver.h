#pragma once
void fardriver_init(void);
