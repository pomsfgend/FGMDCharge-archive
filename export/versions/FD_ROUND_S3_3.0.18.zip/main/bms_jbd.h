#pragma once
#include <stdbool.h>
#include <stdint.h>

/* One JBD SP BMS. state: 0 wait, 1 ok, 2 no reply, 3 bytes but not a frame. */
typedef struct {
    int state;
    float voltage_v;
    float current_a;
    uint8_t soc;
    uint8_t cells;
    uint16_t cell_min_mv;
    uint16_t cell_max_mv;
    uint32_t rx_bytes;
    uint32_t frames;
} bms_pack_t;

void bms_jbd_init(void);
void bms_jbd_snapshot(bms_pack_t *a, bms_pack_t *b);
