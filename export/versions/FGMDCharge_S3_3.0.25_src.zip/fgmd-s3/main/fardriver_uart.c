#include "fardriver_uart.h"

#include "ble.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs.h"
#include <stdio.h>
#include <string.h>

#define FD_UART  UART_NUM_1
#define FD_TX    42
#define FD_RX    39
#define FD_BAUD  19200
#define FD_BUF   1024

static const char *TAG = "FARDRIVER";
static int s_rpm = -1;
static int s_kmh_x10 = -1;
static int s_diam_tenths = 163;
static int64_t s_rpm_us;
static TaskHandle_t s_rx_task;
static uint32_t s_rx_n;
static uint32_t s_tx_n;

static void note_byte(uint8_t b)
{
    /* Optional local speed decode. Bridge itself is transparent. */
    static uint8_t fr[16];
    static int fill;
    if (fill == 0 && b != 0xAA) return;
    fr[fill++] = b;
    if (fill < 16) return;
    fill = 0;
    if ((fr[1] >> 6) != 2) return;
    int id = fr[1] & 0x3F;
    if (id >= 55) return;
    s_rpm = (int)fr[10] | ((int)fr[11] << 8);
    s_kmh_x10 = (int)(((long)s_rpm * s_diam_tenths * 4788L) / 1000000L);
    s_rpm_us = esp_timer_get_time();
}

static void rx_task(void *arg)
{
    uint8_t buf[180];
    (void)arg;
    for (;;) {
        int n = uart_read_bytes(FD_UART, buf, sizeof(buf), pdMS_TO_TICKS(20));
        if (n <= 0) continue;
        s_rx_n += (uint32_t)n;
        for (int i = 0; i < n; ++i) note_byte(buf[i]);
        if (cube_ble_is_connected()) {
            (void)cube_ble_notify(buf, (uint16_t)n);
        }
        if ((s_rx_n & 0x3FFU) == 0) {
            ESP_LOGW(TAG, "hw uart rx=%u tx=%u last=%02x %02x %02x %02x",
                     (unsigned)s_rx_n, (unsigned)s_tx_n,
                     n > 0 ? buf[0] : 0, n > 1 ? buf[1] : 0,
                     n > 2 ? buf[2] : 0, n > 3 ? buf[3] : 0);
        }
    }
}

void fardriver_speed_text(char *out, size_t cap)
{
    int64_t age;
    if (!out || cap == 0) return;
    if (cube_ble_is_connected()) {
        snprintf(out, cap, "телефон");
        return;
    }
    age = esp_timer_get_time() - s_rpm_us;
    if (s_rpm < 0 || age > 2000000) {
        snprintf(out, cap, "тишина");
        return;
    }
    snprintf(out, cap, "%d.%d км/ч  %d об", s_kmh_x10 / 10, s_kmh_x10 % 10, s_rpm);
}

void fardriver_set_diameter_tenths(int tenths)
{
    nvs_handle_t h;
    if (tenths < 80 || tenths > 400) return;
    s_diam_tenths = tenths;
    if (nvs_open("storage", NVS_READWRITE, &h) == ESP_OK) {
        nvs_set_u16(h, "fd_diam", (uint16_t)tenths);
        nvs_commit(h);
        nvs_close(h);
    }
}

int fardriver_diameter_tenths(void)
{
    return s_diam_tenths;
}

void fardriver_uart_write(const uint8_t *data, size_t len)
{
    if (!data || len == 0) return;
    int w = uart_write_bytes(FD_UART, data, len);
    if (w > 0) s_tx_n += (uint32_t)w;
}

void fardriver_uart_start(void)
{
    uart_config_t cfg = {
        .baud_rate = FD_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    ESP_ERROR_CHECK(uart_param_config(FD_UART, &cfg));
    ESP_ERROR_CHECK(uart_set_pin(FD_UART, FD_TX, FD_RX, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    ESP_ERROR_CHECK(uart_driver_install(FD_UART, FD_BUF, FD_BUF, 0, NULL, 0));
    {
        nvs_handle_t h;
        uint16_t saved = 0;
        if (nvs_open("storage", NVS_READONLY, &h) == ESP_OK) {
            if (nvs_get_u16(h, "fd_diam", &saved) == ESP_OK && saved >= 80 && saved <= 400)
                s_diam_tenths = saved;
            nvs_close(h);
        }
    }
    xTaskCreatePinnedToCore(rx_task, "fd_rx", 4096, NULL, 10, &s_rx_task, 1);
    ESP_LOGW(TAG, "hw UART1 19200 TX=%d RX=%d", FD_TX, FD_RX);
}

void fardriver_uart_arm(void)
{
    /* Hardware UART is already running. Kept for call-site compatibility. */
}
