#pragma once

#include <stddef.h>

typedef struct {
    int ok;
    int mv;
    int ma;
    int soc;
    int remain_mah;
    int fet;
    int cell_min_mv;
    int cell_max_mv;
    int ncell;
} bms_link_t;

void bms_uart_start(void);
void bms_link_get(int index, bms_link_t *out);
void bms_link_text(int index, char *out, size_t cap);
int bms_json(char *out, size_t cap);
int bms_cfg_write(int index, int offset, int value);


