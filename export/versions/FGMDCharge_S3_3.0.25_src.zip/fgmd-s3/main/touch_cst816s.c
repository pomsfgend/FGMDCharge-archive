#include "touch_cst816s.h"
#include "config.h"
#include "app_state.h"
#include "driver/gpio.h"
#include "driver/spi_master.h"
#include "esp_log.h"
#include "esp_timer.h"

static const char *TAG = "TOUCH";
static spi_device_handle_t s_dev;
static bool s_ok;
static int s_logs;

static int xpt_sample(uint8_t cmd)
{
    uint8_t tx[3] = {cmd, 0x00, 0x00};
    uint8_t rx[3] = {0};
    spi_transaction_t tr = {
        .length = 24,
        .tx_buffer = tx,
        .rx_buffer = rx,
    };
    if (!s_dev || spi_device_transmit(s_dev, &tr) != ESP_OK) return -1;
    return ((int)rx[1] << 5) | (rx[2] >> 3);
}

static int map_raw(int raw, int lo, int hi, int span)
{
    if (raw < lo) raw = lo;
    if (raw > hi) raw = hi;
    return (raw - lo) * (span - 1) / (hi - lo);
}

esp_err_t touch_init(void)
{
    s_ok = false;
    app_state_set_touch(false, false);
    ESP_LOGW(TAG, "XPT2046 waits for SPI. GPIO1/2 are BMS, not this touch");
    return ESP_OK;
}

esp_err_t touch_attach_spi(void)
{
    gpio_config_t irq = {
        .pin_bit_mask = 1ULL << CUBE_XPT_IRQ_GPIO,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&irq);
    spi_device_interface_config_t dev = {
        .clock_speed_hz = 2000000,
        .mode = 0,
        .spics_io_num = CUBE_XPT_CS_GPIO,
        .queue_size = 1,
    };
    esp_err_t err = spi_bus_add_device(SPI2_HOST, &dev, &s_dev);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "XPT2046 add failed: %s", esp_err_to_name(err));
        return err;
    }
    s_ok = true;
    app_state_set_touch(true, false);
    ESP_LOGW(TAG, "XPT2046 CS=%d IRQ=%d MISO=%d", CUBE_XPT_CS_GPIO, CUBE_XPT_IRQ_GPIO, CUBE_LCD_MISO_GPIO);
    return ESP_OK;
}

bool touch_is_available(void) { return s_ok; }

static int median3(int a, int b, int c)
{
    if (a > b) { int t = a; a = b; b = t; }
    if (b > c) { int t = b; b = c; c = t; }
    if (a > b) { int t = a; a = b; b = t; }
    return b;
}

void touch_lvgl_read(lv_indev_drv_t *drv, lv_indev_data_t *data)
{
    (void)drv;
    static int16_t last_x;
    static int16_t last_y;
    static int stable;
    static int idle;
    if (!s_ok || gpio_get_level(CUBE_XPT_IRQ_GPIO) != 0) {
        stable = 0;
        if (idle < 3) idle++;
        data->state = idle >= 2 ? LV_INDEV_STATE_REL : LV_INDEV_STATE_PR;
        data->point.x = last_x;
        data->point.y = last_y;
        if (idle >= 2) app_state_set_touch(s_ok, false);
        return;
    }
    int z = median3(xpt_sample(0xB1), xpt_sample(0xB1), xpt_sample(0xB1));
    int x1 = xpt_sample(0xD0), x2 = xpt_sample(0xD0), x3 = xpt_sample(0xD0);
    int y1 = xpt_sample(0x90), y2 = xpt_sample(0x90), y3 = xpt_sample(0x90);
    int xraw = median3(x1, x2, x3);
    int yraw = median3(y1, y2, y3);
    int xs = x1 > x3 ? x1 - x3 : x3 - x1;
    int ys = y1 > y3 ? y1 - y3 : y3 - y1;
    /* A finger is a steady spot. A rain drop jumps or barely presses. */
    bool hit = z > 140 && z < 3800 && xs < 160 && ys < 160
        && xraw > 200 && yraw > 200 && xraw < 3900 && yraw < 3900;
    int x = map_raw(xraw, 300, 3800, CUBE_LCD_H_RES);
    int y = map_raw(yraw, 300, 3800, CUBE_LCD_V_RES);
#if CUBE_TOUCH_INVERT_X
    x = CUBE_LCD_H_RES - 1 - x;
#endif
#if CUBE_TOUCH_INVERT_Y
    y = CUBE_LCD_V_RES - 1 - y;
#endif
    if (hit && s_logs < 8) {
        ESP_LOGI(TAG, "raw x=%d y=%d z=%d -> %d,%d", xraw, yraw, z, x, y);
        s_logs++;
    }
    if (hit) {
        idle = 0;
        if (stable < 4) stable++;
        last_x = (int16_t)x;
        last_y = (int16_t)y;
    } else {
        stable = 0;
        if (idle < 3) idle++;
    }
    data->point.x = last_x;
    data->point.y = last_y;
    data->state = (stable >= 2) ? LV_INDEV_STATE_PR : LV_INDEV_STATE_REL;
    app_state_set_touch(true, data->state == LV_INDEV_STATE_PR);
}
