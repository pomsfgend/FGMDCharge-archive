#pragma once
#include <stddef.h>
#include <stdint.h>

void fardriver_uart_start(void);
void fardriver_uart_arm(void);
void fardriver_uart_write(const uint8_t *data, size_t len);
void fardriver_speed_text(char *out, size_t cap);
void fardriver_set_diameter_tenths(int tenths);
int fardriver_diameter_tenths(void);
