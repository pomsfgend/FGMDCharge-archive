#include "bms_uart.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include <stdio.h>
#include <string.h>

static const char *TAG = "BMS";

typedef struct {
    int ok;
    int mv;
    int ma;
    int soc;
    int remain_mah;
    int fet;
    int cell_min_mv;
    int cell_max_mv;
    int ncell;
    int cells[24];
    uint8_t cfg[48];
    int cfg_len;
} link_t;

static link_t s_link[2];
static SemaphoreHandle_t s_bus;

static const struct {
    int off;
    const char *key;
} s_cfg_name[] = {
    {0, "ячейка макс мВ"},
    {2, "ячейка макс сброс мВ"},
    {4, "ячейка мин мВ"},
    {6, "ячейка мин сброс мВ"},
    {8, "пакет макс 10мВ"},
    {10, "пакет макс сброс 10мВ"},
    {12, "пакет мин 10мВ"},
    {14, "пакет мин сброс 10мВ"},
    {16, "заряд ток"},
    {18, "заряд ток задержка"},
    {20, "разряд ток"},
    {22, "разряд ток задержка"},
    {24, "короткое"},
    {26, "короткое задержка"},
    {28, "баланс старт мВ"},
    {30, "баланс разница мВ"},
    {32, "параметр 16"},
    {34, "параметр 17"},
    {36, "параметр 18"},
    {38, "параметр 19"},
    {40, "параметр 20"},
    {42, "параметр 21"},
    {44, "параметр 22"},
    {46, "параметр 23"},
};

static int frame(uint8_t *dst, uint8_t dir, uint8_t cmd, const uint8_t *data, int len)
{
    int sum = cmd + len;
    dst[0] = 0xDD;
    dst[1] = dir;
    dst[2] = cmd;
    dst[3] = (uint8_t)len;
    for (int i = 0; i < len; ++i) {
        dst[4 + i] = data[i];
        sum += data[i];
    }
    sum = (-sum) & 0xFFFF;
    dst[4 + len] = (uint8_t)(sum >> 8);
    dst[5 + len] = (uint8_t)sum;
    dst[6 + len] = 0x77;
    return 7 + len;
}

static int xfer(uart_port_t port, const uint8_t *tx, int txlen, uint8_t *rx, int rxcap)
{
    uart_flush_input(port);
    uart_write_bytes(port, (const char *)tx, txlen);
    return uart_read_bytes(port, rx, rxcap, pdMS_TO_TICKS(250));
}

/* +13 В с разъёма BMS на ESP не подавать. Здесь только TX и RX, 9600 8N1. */

static void arm(uart_port_t port, int tx, int rx)
{
    uart_config_t cfg = {
        .baud_rate = 9600,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_APB,
    };
    uart_driver_install(port, 512, 0, 0, NULL, 0);
    uart_param_config(port, &cfg);
    uart_set_pin(port, tx, rx, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
}

static void ask(uart_port_t port, link_t *link, const char *name)
{
    static const uint8_t req[] = {0xDD, 0xA5, 0x03, 0x00, 0xFF, 0xFD, 0x77};
    uint8_t rx[80];
    uart_flush_input(port);
    uart_write_bytes(port, (const char *)req, sizeof(req));
    int n = uart_read_bytes(port, rx, sizeof(rx), pdMS_TO_TICKS(200));
    if (n < 7 || rx[0] != 0xDD) {
        link->ok = 0;
        ESP_LOGI(TAG, "%s нет ответа", name);
        return;
    }
    int len = rx[3];
    if (n < 4 + len || len < 4) {
        link->ok = 0;
        ESP_LOGI(TAG, "%s короткий кадр %d", name, n);
        return;
    }
    link->ok = 1;
    link->mv = (((int)rx[4] << 8) | rx[5]) * 10;
    link->ma = (int)(int16_t)(((int)rx[6] << 8) | rx[7]) * 10;
    link->remain_mah = len > 5 ? ((((int)rx[8] << 8) | rx[9]) * 10) : 0;
    link->soc = len > 19 ? rx[23] : -1;
    link->fet = len > 20 ? rx[24] : 0;
    ESP_LOGW(TAG, "%s %d мВ %d мА soc %d", name, link->mv, link->ma, link->soc);
}

static void cells(uart_port_t port, link_t *link)
{
    static const uint8_t req[] = {0xDD, 0xA5, 0x04, 0x00, 0xFF, 0xFC, 0x77};
    uint8_t rx[128];
    int n;
    int len;
    int i;
    int min_mv = 10000;
    int max_mv = 0;
    uart_flush_input(port);
    uart_write_bytes(port, (const char *)req, sizeof(req));
    n = uart_read_bytes(port, rx, sizeof(rx), pdMS_TO_TICKS(200));
    if (n < 7 || rx[0] != 0xDD || rx[1] != 0x04) return;
    len = rx[3];
    if (len < 2 || n < 4 + len) return;
    link->ncell = len / 2;
    if (link->ncell > 24) link->ncell = 24;
    for (i = 0; i < link->ncell; ++i) {
        int mv = ((int)rx[4 + i * 2] << 8) | rx[5 + i * 2];
        link->cells[i] = mv;
        if (mv < min_mv) min_mv = mv;
        if (mv > max_mv) max_mv = mv;
    }
    link->cell_min_mv = min_mv;
    link->cell_max_mv = max_mv;
}

static void read_cfg(uart_port_t port, link_t *link)
{
    uint8_t tx[8];
    uint8_t rx[80];
    int nlen = frame(tx, 0xA5, 0xFA, NULL, 0);
    int n = xfer(port, tx, nlen, rx, sizeof(rx));
    int len;
    if (n < 7 || rx[0] != 0xDD || rx[2] != 0x00) {
        link->cfg_len = 0;
        return;
    }
    len = rx[3];
    if (len < 2 || n < 4 + len) return;
    if (len > (int)sizeof(link->cfg)) len = (int)sizeof(link->cfg);
    memcpy(link->cfg, rx + 4, (size_t)len);
    link->cfg_len = len;
}

static void task(void *arg)
{
    (void)arg;
    for (;;) {
        if (s_bus) xSemaphoreTake(s_bus, portMAX_DELAY);
        ask(UART_NUM_1, &s_link[0], "JBD-A");
        cells(UART_NUM_1, &s_link[0]);
        read_cfg(UART_NUM_1, &s_link[0]);
        ask(UART_NUM_2, &s_link[1], "JBD-B");
        cells(UART_NUM_2, &s_link[1]);
        read_cfg(UART_NUM_2, &s_link[1]);
        if (s_bus) xSemaphoreGive(s_bus);
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}

void bms_link_get(int index, bms_link_t *out)
{
    const link_t *link;
    if (!out) return;
    if (index < 0 || index > 1) {
        out->ok = 0;
        return;
    }
    link = &s_link[index];
    out->ok = link->ok;
    out->mv = link->mv;
    out->ma = link->ma;
    out->soc = link->soc;
    out->remain_mah = link->remain_mah;
    out->fet = link->fet;
    out->cell_min_mv = link->cell_min_mv;
    out->cell_max_mv = link->cell_max_mv;
    out->ncell = link->ncell;
}

void bms_link_text(int index, char *out, size_t cap)
{
    const link_t *link;
    if (!out || cap == 0) return;
    if (index < 0 || index > 1) {
        snprintf(out, cap, "нет");
        return;
    }
    link = &s_link[index];
    if (!link->ok) {
        snprintf(out, cap, "нет связи");
        return;
    }
    if (link->soc >= 0) {
        snprintf(out, cap, "%d.%02d В  %d.%02d А  %d%%",
                 link->mv / 1000, (link->mv / 10) % 100,
                 link->ma / 1000, (link->ma < 0 ? -link->ma : link->ma) / 10 % 100,
                 link->soc);
    } else {
        snprintf(out, cap, "%d.%02d В  %d.%02d А",
                 link->mv / 1000, (link->mv / 10) % 100,
                 link->ma / 1000, (link->ma < 0 ? -link->ma : link->ma) / 10 % 100);
    }
}

void bms_uart_start(void)
{
    s_bus = xSemaphoreCreateMutex();
    arm(UART_NUM_1, 1, 2);
    arm(UART_NUM_2, 40, 41);
    ESP_LOGW(TAG, "UART 9600: A TX1/RX2, B TX40/RX41. +13 В разъёма на ESP не подавать");
    xTaskCreate(task, "bms", 4096, NULL, 2, NULL);
}

int bms_json(char *out, size_t cap)
{
    int used = 0;
    int p;
    if (!out || cap < 16) return -1;
    used = snprintf(out, cap, "{\"ok\":true,\"packs\":[");
    for (p = 0; p < 2; ++p) {
        const link_t *L = &s_link[p];
        int i;
        int n;
        if ((size_t)used >= cap) return -1;
        n = snprintf(out + used, cap - (size_t)used,
                     "%s{\"ok\":%s,\"mv\":%d,\"ma\":%d,\"soc\":%d,\"mah\":%d,\"d_mv\":%d,\"ncell\":%d,\"cells\":[",
                     p ? "," : "", L->ok ? "true" : "false", L->mv, L->ma, L->soc, L->remain_mah,
                     (L->ncell > 0) ? (L->cell_max_mv - L->cell_min_mv) : -1, L->ncell);
        if (n < 0) return -1;
        used += n;
        for (i = 0; i < L->ncell; ++i) {
            if ((size_t)used >= cap) return -1;
            n = snprintf(out + used, cap - (size_t)used, "%s%d", i ? "," : "", L->cells[i]);
            if (n < 0) return -1;
            used += n;
        }
        if ((size_t)used >= cap) return -1;
        n = snprintf(out + used, cap - (size_t)used, "],\"cfg\":[");
        if (n < 0) return -1;
        used += n;
        for (i = 0; i < (int)(sizeof(s_cfg_name) / sizeof(s_cfg_name[0])); ++i) {
            int off = s_cfg_name[i].off;
            int val = (off + 1 < L->cfg_len) ? ((L->cfg[off] << 8) | L->cfg[off + 1]) : -1;
            if ((size_t)used >= cap) return -1;
            n = snprintf(out + used, cap - (size_t)used, "%s{\"off\":%d,\"name\":\"%s\",\"v\":%d}",
                         i ? "," : "", off, s_cfg_name[i].key, val);
            if (n < 0) return -1;
            used += n;
        }
        if ((size_t)used + 2 >= cap) return -1;
        out[used++] = ']';
        out[used++] = '}';
    }
    if ((size_t)used + 3 >= cap) return -1;
    out[used++] = ']';
    out[used++] = '}';
    out[used] = 0;
    return used;
}

int bms_cfg_write(int index, int offset, int value)
{
    uart_port_t port = index == 0 ? UART_NUM_1 : UART_NUM_2;
    link_t *L;
    uint8_t tx[64];
    uint8_t rx[16];
    int nlen;
    int n;
    if (index < 0 || index > 1 || offset < 0 || (offset & 1) || value < 0 || value > 65535) return -1;
    L = &s_link[index];
    if (!s_bus || L->cfg_len < offset + 2) return -2;
    xSemaphoreTake(s_bus, portMAX_DELAY);
    L->cfg[offset] = (uint8_t)(value >> 8);
    L->cfg[offset + 1] = (uint8_t)value;
    nlen = frame(tx, 0x5A, 0xFA, L->cfg, L->cfg_len);
    n = xfer(port, tx, nlen, rx, sizeof(rx));
    xSemaphoreGive(s_bus);
    if (n < 4 || rx[0] != 0xDD || rx[2] != 0x00) return -3;
    return 0;
}