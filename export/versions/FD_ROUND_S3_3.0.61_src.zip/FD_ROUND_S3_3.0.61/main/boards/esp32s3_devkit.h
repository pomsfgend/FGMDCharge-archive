#pragma once

/*
 * ESP32-S3-DevKitC-1 N16R8 (and N8R2, same free pins).
 * SPI2, CST816 on I2C0, TWAI 250 kbit, two active-high relay outputs.
 *
 * Not used, on purpose:
 *   0, 3, 45, 46     strapping
 *   19, 20           USB D-/D+  (the port this board is flashed from)
 *   22-25            not bonded on ESP32-S3
 *   26-32            in-package flash
 *   33-37            octal PSRAM on N16R8 / N8R8
 *   43, 44           UART0 (CH340 clones)
 *   38, 48           onboard RGB, revision-dependent
 */

#ifndef CUBE_LCD_USE_ST7789
#define CUBE_LCD_USE_ST7789          0
#endif
#ifndef CUBE_LCD_H_RES
#define CUBE_LCD_H_RES               240
#endif
#ifndef CUBE_LCD_V_RES
#define CUBE_LCD_V_RES               320
#endif
#ifndef CUBE_LCD_MOSI_GPIO
#define CUBE_LCD_MOSI_GPIO           11
#endif
#ifndef CUBE_LCD_MISO_GPIO
#define CUBE_LCD_MISO_GPIO           9
#endif
#ifndef CUBE_LCD_SCLK_GPIO
#define CUBE_LCD_SCLK_GPIO           12
#endif
#ifndef CUBE_LCD_CS_GPIO
#define CUBE_LCD_CS_GPIO             10
#endif
#ifndef CUBE_LCD_DC_GPIO
#define CUBE_LCD_DC_GPIO             13
#endif
#ifndef CUBE_LCD_SPI_HZ
#define CUBE_LCD_SPI_HZ              10000000
#endif
#ifndef CUBE_LCD_BL_GPIO
#define CUBE_LCD_BL_GPIO             21
#endif
#ifndef CUBE_LCD_BL_PWM_GPIO
#define CUBE_LCD_BL_PWM_GPIO         21
#endif
#ifndef CUBE_LCD_BL_PWM_HZ
#define CUBE_LCD_BL_PWM_HZ           5000
#endif
#ifndef CUBE_LCD_BL_PWM_DUTY_DEFAULT
#define CUBE_LCD_BL_PWM_DUTY_DEFAULT 100
#endif
#ifndef CUBE_LCD_RST_GPIO
#define CUBE_LCD_RST_GPIO            14
#endif
#ifndef CUBE_STATUS_LED_GPIO
#define CUBE_STATUS_LED_GPIO         (-1)
#endif
#ifndef CUBE_LCD_QUEUE_DEPTH
#define CUBE_LCD_QUEUE_DEPTH         10
#endif
#ifndef CUBE_LCD_MAX_TRANSFER
#define CUBE_LCD_MAX_TRANSFER        38400
#endif
#ifndef CUBE_LCD_GAP_X
#define CUBE_LCD_GAP_X               0
#endif
#ifndef CUBE_LCD_GAP_Y
#define CUBE_LCD_GAP_Y               0
#endif
#ifndef CUBE_LCD_INVERT
#define CUBE_LCD_INVERT              0
#endif
#ifndef CUBE_LCD_BGR
#define CUBE_LCD_BGR                 1
#endif
#ifndef CUBE_LCD_MIRROR_X
#define CUBE_LCD_MIRROR_X            1
#endif
#ifndef CUBE_LCD_MIRROR_Y
#define CUBE_LCD_MIRROR_Y            0
#endif

#ifndef CUBE_TOUCH_ENABLED_DEFAULT
#define CUBE_TOUCH_ENABLED_DEFAULT   1
#endif
#ifndef CUBE_TOUCH_SDA_GPIO
#define CUBE_TOUCH_SDA_GPIO          1
#endif
#ifndef CUBE_TOUCH_SCL_GPIO
#define CUBE_TOUCH_SCL_GPIO          2
#endif
#ifndef CUBE_TOUCH_I2C_PORT
#define CUBE_TOUCH_I2C_PORT          0
#endif
#ifndef CUBE_TOUCH_ADDR
#define CUBE_TOUCH_ADDR              0x15
#endif
#ifndef CUBE_TOUCH_SWAP_XY
#define CUBE_TOUCH_SWAP_XY           0
#endif
#ifndef CUBE_TOUCH_INVERT_X
#define CUBE_TOUCH_INVERT_X          0
#endif
#ifndef CUBE_TOUCH_INVERT_Y
#define CUBE_TOUCH_INVERT_Y          1
#endif
#ifndef CUBE_TOUCH_POLL_MS
#define CUBE_TOUCH_POLL_MS           15
#endif

#ifndef CUBE_CAN_TX_GPIO
#define CUBE_CAN_TX_GPIO             17
#endif
#ifndef CUBE_CAN_RX_GPIO
#define CUBE_CAN_RX_GPIO             18
#endif
#ifndef CUBE_CAN_BITRATE
#define CUBE_CAN_BITRATE             250000
#endif

#ifndef CUBE_RELAY_A_GPIO
#define CUBE_RELAY_A_GPIO            6
#endif
#ifndef CUBE_RELAY_B_GPIO
#define CUBE_RELAY_B_GPIO            7
#endif

/* XPT2046 CS stays on GPIO16. T_IRQ is not read (pressure Z is). GPIO8 is the seat probe. */
#define CUBE_XPT_CS_GPIO             16
#define CUBE_XPT_IRQ_GPIO            (-1)

/* Cabin sensors. Relays are the 8-channel board, active low, no MCP23017.
 * IN1 GPIO42 light, IN2 GPIO39 spare, IN3 GPIO40 strip,
 * IN4 GPIO41 ZVS input, IN5 GPIO38 ZVS output.
 * IN6 GPIO6 and IN7 GPIO7 are the station relays. IN8 has no pin. */
#define CUBE_CABIN_SDA_GPIO          15
#define CUBE_CABIN_SCL_GPIO          47
#define CUBE_CABIN_I2C_PORT          1
#define CUBE_SEAT_OW_GPIO            8
#define CUBE_HEAT_PWM_GPIO           5
#define CUBE_ZVS_ADC_GPIO            4
#define CUBE_ZVS_ADC_UNIT            ADC_UNIT_1
#define CUBE_ZVS_ADC_CHANNEL         ADC_CHANNEL_3
/* 4x 470k from HV+ to the ADC node, 12k from the node to GND. 390 V -> about 2.47 V. */
#define CUBE_ZVS_RTOP_OHM            1880000
#define CUBE_ZVS_RBOT_OHM            10000
#define CUBE_ZVS_CUT_MV              385000

