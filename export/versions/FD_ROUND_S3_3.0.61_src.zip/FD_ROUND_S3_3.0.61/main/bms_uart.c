#include "bms_uart.h"
#include "ble.h"
#include "settings.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "esp_rom_sys.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>

static const char *TAG = "BMS";

typedef struct {
    int ok;
    int mv;
    int ma;
    int soc;
    int remain_mah;
    int fet;
    int cell_min_mv;
    int cell_max_mv;
    int ncell;
    int peak_mah;
    int peak_ma;
    uint32_t balance;
    int cells[24];
    uint8_t cfg[192];
    int cfg_len;
    int cfg_writable;
    int reg_v[16];
    uint8_t reg_ok[16];
    int regs_n;
    char hw[32];
} link_t;

static link_t s_link[2];
static SemaphoreHandle_t s_bus;
#define BR_QN 4
#define BR_QMAX 220
static int s_cfg_force[2];
static int s_hold;
static uint8_t s_brq[BR_QN][BR_QMAX];
static uint8_t s_brl[BR_QN];
static int s_brr, s_brw, s_brn;
static portMUX_TYPE s_brm = portMUX_INITIALIZER_UNLOCKED;
static uint8_t s_asm[BR_QMAX];
static int s_asm_n;

static int cfg_u16(const link_t *link, int off)
{
    if (!link || off < 0 || off + 1 >= link->cfg_len) return -1;
    return ((int)link->cfg[off] << 8) | link->cfg[off + 1];
}

static int frame(uint8_t *dst, uint8_t dir, uint8_t cmd, const uint8_t *data, int len)
{
    int sum = cmd + len;
    dst[0] = 0xDD;
    dst[1] = dir;
    dst[2] = cmd;
    dst[3] = (uint8_t)len;
    for (int i = 0; i < len; ++i) {
        dst[4 + i] = data[i];
        sum += data[i];
    }
    sum = (-sum) & 0xFFFF;
    dst[4 + len] = (uint8_t)(sum >> 8);
    dst[5 + len] = (uint8_t)sum;
    dst[6 + len] = 0x77;
    return 7 + len;
}

/* BMS A is bit-banged at 9600. UART1 belongs to Fardriver (GPIO42/39);
 * UART0 is the console. UART2 stays on BMS B. */

#define BMSA_TX 1
#define BMSA_RX 2
#define BMSA_BIT 104

static void bmsa_tx(const uint8_t *data, int n)
{
    for (int i = 0; i < n; ++i) {
        uint8_t b = data[i];
        portDISABLE_INTERRUPTS();
        gpio_set_level(BMSA_TX, 0);
        esp_rom_delay_us(BMSA_BIT);
        for (int bit = 0; bit < 8; ++bit) {
            gpio_set_level(BMSA_TX, (b >> bit) & 1);
            esp_rom_delay_us(BMSA_BIT);
        }
        gpio_set_level(BMSA_TX, 1);
        esp_rom_delay_us(BMSA_BIT);
        portENABLE_INTERRUPTS();
    }
}

static int bmsa_rx_byte(int timeout_us)
{
    int64_t t0 = esp_timer_get_time();
    while (gpio_get_level(BMSA_RX)) {
        if (esp_timer_get_time() - t0 > timeout_us) return -1;
    }
    portDISABLE_INTERRUPTS();
    esp_rom_delay_us(BMSA_BIT + BMSA_BIT / 2);
    uint8_t b = 0;
    for (int bit = 0; bit < 8; ++bit) {
        if (gpio_get_level(BMSA_RX)) b |= (uint8_t)(1u << bit);
        esp_rom_delay_us(BMSA_BIT);
    }
    portENABLE_INTERRUPTS();
    return b;
}

static int bmsa_read(uint8_t *rx, int cap, int timeout_ms)
{
    int n = 0;
    int64_t limit = esp_timer_get_time() + (int64_t)timeout_ms * 1000;
    while (gpio_get_level(BMSA_RX)) {
        if (esp_timer_get_time() > limit) return 0;
    }
    portDISABLE_INTERRUPTS();
    while (n < cap) {
        int bit;
        uint8_t b = 0;
        if (n > 0) {
            int64_t w = esp_timer_get_time();
            while (gpio_get_level(BMSA_RX)) {
                if (esp_timer_get_time() - w > 6000) {
                    portENABLE_INTERRUPTS();
                    return n;
                }
            }
        }
        esp_rom_delay_us(BMSA_BIT + BMSA_BIT / 2);
        for (bit = 0; bit < 8; ++bit) {
            if (gpio_get_level(BMSA_RX)) b |= (uint8_t)(1u << bit);
            if (bit != 7) esp_rom_delay_us(BMSA_BIT);
        }
        esp_rom_delay_us(BMSA_BIT);
        rx[n++] = b;
        if (n >= 7 && rx[0] == 0xDD) {
            int len = rx[3];
            if (len < 160 && n >= 7 + len && rx[n - 1] == 0x77) break;
        }
    }
    portENABLE_INTERRUPTS();
    return n;
}

static void bus_flush(int index)
{
    int i;
    if (index == 0) {
        /* Never spin here. A stuck-low RX used to disable interrupts forever
         * and the Fardriver UART on the other core starved. */
        for (i = 0; i < 40; ++i) {
            if (bmsa_rx_byte(800) < 0) break;
        }
    } else {
        uart_flush_input(UART_NUM_2);
    }
}

static void bus_tx(int index, const uint8_t *data, int n)
{
    if (index == 0) bmsa_tx(data, n);
    else uart_write_bytes(UART_NUM_2, (const char *)data, n);
}

static int bus_rx(int index, uint8_t *data, int cap, int timeout_ms)
{
    int n = 0;
    int64_t limit;
    if (index == 0) return bmsa_read(data, cap, timeout_ms);
    limit = esp_timer_get_time() + (int64_t)timeout_ms * 1000;
    while (n < cap && esp_timer_get_time() < limit) {
        int left = (int)((limit - esp_timer_get_time()) / 1000);
        int got;
        if (left < 1) left = 1;
        got = uart_read_bytes(UART_NUM_2, data + n, cap - n, pdMS_TO_TICKS(left));
        if (got > 0) {
            n += got;
            if (n >= 7 && data[0] == 0xDD) {
                int len = data[3];
                if (len <= 180 && n >= 7 + len) return n;
            }
        } else if (n > 0) {
            return n;
        }
    }
    return n;
}

static int xfer_ms(int index, const uint8_t *tx, int txlen, uint8_t *rx, int rxcap, int ms)
{
    bus_flush(index);
    bus_tx(index, tx, txlen);
    return bus_rx(index, rx, rxcap, ms);
}

static int xfer(int index, const uint8_t *tx, int txlen, uint8_t *rx, int rxcap)
{
    return xfer_ms(index, tx, txlen, rx, rxcap, 250);
}

/* +13 В с разъёма BMS на ESP не подавать. Здесь только TX и RX, 9600 8N1. */

static void arm(uart_port_t port, int tx, int rx)
{
    uart_config_t cfg = {
        .baud_rate = 9600,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_APB,
    };
    uart_driver_install(port, 512, 0, 0, NULL, 0);
    uart_param_config(port, &cfg);
    uart_set_pin(port, tx, rx, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    /* Без этого uart_read_bytes ждёт полный буфер или все 250 мс.
     * 3 времени байта: кадр 9600 отдаётся сразу после тишины. */
    uart_set_rx_timeout(port, 3);
}

static void ask(int index, link_t *link, const char *name)
{
    static const uint8_t req[] = {0xDD, 0xA5, 0x03, 0x00, 0xFF, 0xFD, 0x77};
    uint8_t rx[80];
    bus_flush(index);
    bus_tx(index, req, sizeof(req));
    int n = bus_rx(index, rx, sizeof(rx), 200);
    if (n < 7 || rx[0] != 0xDD) {
        link->ok = 0;
        ESP_LOGI(TAG, "%s нет ответа", name);
        return;
    }
    int len = rx[3];
    if (n < 4 + len || len < 4) {
        link->ok = 0;
        ESP_LOGI(TAG, "%s короткий кадр %d", name, n);
        return;
    }
    link->ok = 1;
    link->mv = (((int)rx[4] << 8) | rx[5]) * 10;
    link->ma = (int)(int16_t)(((int)rx[6] << 8) | rx[7]) * 10;
    {
        int absma = link->ma < 0 ? -link->ma : link->ma;
        if (absma > link->peak_ma) link->peak_ma = absma;
    }
    link->remain_mah = len > 5 ? ((((int)rx[8] << 8) | rx[9]) * 10) : 0;
    if (link->remain_mah > link->peak_mah) link->peak_mah = link->remain_mah;
    link->balance = 0;
    if (len >= 16) {
        uint16_t lo = ((uint16_t)rx[16] << 8) | rx[17];
        uint16_t hi = ((uint16_t)rx[18] << 8) | rx[19];
        link->balance = ((uint32_t)hi << 16) | lo;
    }
    link->soc = len > 19 ? rx[23] : -1;
    link->fet = len > 20 ? rx[24] : 0;
    ESP_LOGW(TAG, "%s %d мВ %d мА soc %d бал %lu", name, link->mv, link->ma, link->soc,
             (unsigned long)link->balance);
}

static void cells(int index, link_t *link)
{
    static const uint8_t req[] = {0xDD, 0xA5, 0x04, 0x00, 0xFF, 0xFC, 0x77};
    uint8_t rx[128];
    int n;
    int len;
    int i;
    int min_mv = 10000;
    int max_mv = 0;
    bus_flush(index);
    bus_tx(index, req, sizeof(req));
    n = bus_rx(index, rx, sizeof(rx), 200);
    if (n < 7 || rx[0] != 0xDD || rx[1] != 0x04) return;
    len = rx[3];
    if (len < 2 || n < 4 + len) return;
    link->ncell = len / 2;
    if (link->ncell > 24) link->ncell = 24;
    for (i = 0; i < link->ncell; ++i) {
        int mv = ((int)rx[4 + i * 2] << 8) | rx[5 + i * 2];
        link->cells[i] = mv;
        if (mv < min_mv) min_mv = mv;
        if (mv > max_mv) max_mv = mv;
    }
    link->cell_min_mv = min_mv;
    link->cell_max_mv = max_mv;
}

static const uint8_t k_reg[] = {
    0x10, 0x11, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2D, 0x2F
};
#define REG_N ((int)(sizeof(k_reg)))

static int frame_ok(const uint8_t *rx, int n);

static int sync_dd(uint8_t *rx, int n)
{
    int i = 0;
    while (i < n && rx[i] != 0xDD) i++;
    if (i > 0 && i < n) {
        memmove(rx, rx + i, (size_t)(n - i));
        n -= i;
    }
    return n;
}

static int reg_slot(int reg)
{
    int i;
    for (i = 0; i < REG_N; ++i) if (k_reg[i] == (uint8_t)reg) return i;
    return -1;
}

static int amp_div_of(const link_t *L)
{
    int slot = reg_slot(0x2D);
    if (!L || slot < 0 || !L->reg_ok[slot]) return 0;
    return (L->reg_v[slot] & 0x1000) ? 10 : 100;
}

/* 0x06 is the 6-digit app password. Factory key 5678 alone is ignored on
 * newer SP boards, so a write looks like it landed and the old number stays. */
static void enter_factory(int index)
{
    static const uint8_t data[2] = {0x56, 0x78};
    uint8_t tx[16];
    uint8_t rx[24];
    int nlen = frame(tx, 0x5A, 0x00, data, 2);
    (void)xfer_ms(index, tx, nlen, rx, sizeof(rx), 150);
}

static void enter_factory_pw(int index, int alt)
{
    static const uint8_t pw_a[7] = {0x06, '1', '2', '3', '4', '5', '6'};
    static const uint8_t pw_b[7] = {0x06, '0', '0', '0', '0', '0', '0'};
    uint8_t tx[24];
    uint8_t rx[24];
    int nlen = frame(tx, 0x5A, 0x06, alt ? pw_b : pw_a, 7);
    (void)xfer_ms(index, tx, nlen, rx, sizeof(rx), 180);
    vTaskDelay(pdMS_TO_TICKS(40));
    enter_factory(index);
}

static void exit_factory(int index, int save)
{
    uint8_t data[2];
    uint8_t tx[16];
    uint8_t rx[24];
    int nlen;
    data[0] = data[1] = save ? 0x28 : 0x00;
    nlen = frame(tx, 0x5A, 0x01, data, 2);
    (void)xfer_ms(index, tx, nlen, rx, sizeof(rx), 160);
}

static int read_reg(int index, int reg, int *value)
{
    uint8_t tx[8];
    uint8_t rx[24];
    int nlen = frame(tx, 0xA5, (uint8_t)reg, NULL, 0);
    int n = xfer_ms(index, tx, nlen, rx, sizeof(rx), 120);
    int v;
    n = sync_dd(rx, n);
    if (!frame_ok(rx, n) || rx[3] < 2) return 0;
    if (rx[1] != (uint8_t)reg) return 0;
    v = ((int)rx[4] << 8) | rx[5];
    if ((reg == 0x28 || reg == 0x29) && v >= 0x8000) v -= 0x10000;
    *value = v;
    return 1;
}

static void read_regs(int index, link_t *link)
{
    int i;
    int any = 0;
    enter_factory(index);
    vTaskDelay(pdMS_TO_TICKS(40));
    for (i = 0; i < REG_N; ++i) {
        int v = 0;
        if (s_hold) break;
        if (read_reg(index, k_reg[i], &v)) {
            link->reg_v[i] = v;
            link->reg_ok[i] = 1;
        }
    }
    exit_factory(index, 0);
    for (i = 0; i < REG_N; ++i) if (link->reg_ok[i]) any++;
    link->regs_n = any;
    if (any) ESP_LOGW(TAG, "regs %d/%d", any, REG_N);
}

static int unlock_cfg(int index)
{
    static const uint8_t data[2] = {0x56, 0x78};
    uint8_t tx[16];
    uint8_t rx[16];
    int nlen = frame(tx, 0x5A, 0x00, data, 2);
    int n = xfer(index, tx, nlen, rx, sizeof(rx));
    return n >= 4 && rx[0] == 0xDD && rx[2] == 0x00;
}

static int frame_ok(const uint8_t *rx, int n)
{
    int len;
    if (n < 7 || rx[0] != 0xDD) return 0;
    len = rx[3];
    if (len < 0 || len > 160 || n < 7 + len) return 0;
    return rx[6 + len] == 0x77 && rx[2] == 0x00;
}

static int read_cfg_once(int index, link_t *link)
{
    uint8_t tx[8];
    uint8_t rx[220];
    int nlen = frame(tx, 0xA5, 0xFA, NULL, 0);
    int n;
    int declared;
    int i;
    n = xfer(index, tx, nlen, rx, sizeof(rx));
    i = 0;
    while (i + 7 < n && rx[i] != 0xDD) i++;
    if (i) {
        memmove(rx, rx + i, (size_t)(n - i));
        n -= i;
    }
    if (!frame_ok(rx, n)) {
        ESP_LOGW(TAG, "cfg n=%d %02x %02x %02x %02x %02x",
                 n, n > 0 ? rx[0] : 0, n > 1 ? rx[1] : 0, n > 2 ? rx[2] : 0, n > 3 ? rx[3] : 0,
                 n > 4 ? rx[4] : 0);
        return 0;
    }
    declared = rx[3];
    if (declared < 18) return 0;
    if (declared > (int)sizeof(link->cfg)) declared = (int)sizeof(link->cfg);
    memcpy(link->cfg, rx + 4, (size_t)declared);
    link->cfg_len = declared;
    link->cfg_writable = 1;
    ESP_LOGW(TAG, "cfg заряд %d А пауза %d разряд %d А пауза %d короткое %d пауза %d",
             cfg_u16(link, 16), cfg_u16(link, 18), cfg_u16(link, 20),
             cfg_u16(link, 22), cfg_u16(link, 24), cfg_u16(link, 26));
    return 1;
}

static void read_cfg(int index, link_t *link, const char *name)
{
    if (read_cfg_once(index, link)) return;
    if (unlock_cfg(index)) vTaskDelay(pdMS_TO_TICKS(40));
    if (!read_cfg_once(index, link)) {
        ESP_LOGW(TAG, "%s настройки не прочитаны", name);
    }
}

static void read_hw(int index, link_t *link)
{
    static const uint8_t req[] = {0xDD, 0xA5, 0x05, 0x00, 0xFF, 0xFB, 0x77};
    uint8_t rx[48];
    int n;
    int len;
    int i;
    if (link->hw[0]) return;
    n = xfer(index, req, sizeof(req), rx, sizeof(rx));
    if (!frame_ok(rx, n)) return;
    len = rx[3];
    if (len <= 0 || len > 31) return;
    for (i = 0; i < len; ++i) {
        uint8_t c = rx[4 + i];
        if (c < 32 || c > 126 || c == '"' || c == '\\') c = ' ';
        link->hw[i] = (char)c;
    }
    link->hw[len] = 0;
}

static void task(void *arg)
{
    int tickn = 0;
    int fails[2] = {0, 0};
    (void)arg;
    for (;;) {
        int i;
        int bridged = 0;
        if (s_bus) xSemaphoreTake(s_bus, portMAX_DELAY);
        if (s_hold || s_brn) {
            uint8_t tx[BR_QMAX];
            uint8_t rx[240];
            int tn = 0;
            taskENTER_CRITICAL(&s_brm);
            if (s_brn > 0) {
                tn = s_brl[s_brr];
                if (tn > BR_QMAX) tn = BR_QMAX;
                memcpy(tx, s_brq[s_brr], (size_t)tn);
                s_brr = (s_brr + 1) % BR_QN;
                s_brn--;
            }
            taskEXIT_CRITICAL(&s_brm);
            if (tn > 0) {
                int pack = settings_get_bms_pack();
                int rn;
                if (pack < 0 || pack > 1) pack = 0;
                rn = xfer(pack, tx, tn, rx, sizeof(rx));
                if (s_bus) xSemaphoreGive(s_bus);
                if (rn > 0) (void)cube_ble_notify(rx, (uint16_t)rn);
            } else if (s_bus) {
                xSemaphoreGive(s_bus);
            }
            bridged = 1;
        }
        if (bridged) {
            vTaskDelay(pdMS_TO_TICKS(8));
            continue;
        }
        ask(0, &s_link[0], "JBD-A");
        if (s_hold) { if (s_bus) xSemaphoreGive(s_bus); vTaskDelay(pdMS_TO_TICKS(8)); continue; }
        cells(0, &s_link[0]);
        read_hw(0, &s_link[0]);
        if (s_hold) { if (s_bus) xSemaphoreGive(s_bus); vTaskDelay(pdMS_TO_TICKS(8)); continue; }
        ask(1, &s_link[1], "JBD-B");
        cells(1, &s_link[1]);
        read_hw(1, &s_link[1]);
        for (i = 0; i < 2; ++i) {
            int due;
            if (s_hold) break;
            due = s_cfg_force[i] || (s_link[i].regs_n < 8 && s_link[i].cfg_len < 18);
            if (!s_link[i].ok || !due) continue;
            if (fails[i] >= 4 && (tickn % 8) != 0 && !s_cfg_force[i]) continue;
            if (s_cfg_force[i] || s_link[i].regs_n < 8) read_regs(i, &s_link[i]);
            if (s_hold) break;
            if (s_link[i].cfg_len < 18 && s_link[i].regs_n < 8) {
                read_cfg(i, &s_link[i], i ? "JBD-B" : "JBD-A");
            }
            s_cfg_force[i] = 0;
            if (s_link[i].regs_n >= 8 || s_link[i].cfg_len >= 18) fails[i] = 0;
            else if (fails[i] < 100) fails[i]++;
        }
        tickn++;
        if (s_bus) xSemaphoreGive(s_bus);
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}

void bms_link_get(int index, bms_link_t *out)
{
    const link_t *link;
    if (!out) return;
    if (index < 0 || index > 1) {
        out->ok = 0;
        return;
    }
    link = &s_link[index];
    memset(out, 0, sizeof(*out));
    out->chg = out->chgd = out->dsg = out->dsgd = out->sc = out->scd = -1;
    out->ok = link->ok;
    out->mv = link->mv;
    out->ma = link->ma;
    out->peak_ma = link->peak_ma;
    out->soc = link->soc;
    out->remain_mah = link->remain_mah;
    out->fet = link->fet;
    out->cell_min_mv = link->cell_min_mv;
    out->cell_max_mv = link->cell_max_mv;
    out->ncell = link->ncell;
    out->peak_mah = link->peak_mah;
    out->balance = link->balance;
    out->cfg_ok = (link->cfg_len >= 18) || (link->regs_n > 0);
    out->cfg_writable = link->cfg_writable || link->regs_n > 0;
    out->regs_ok = link->regs_n;
    out->chg = cfg_u16(link, 16);
    out->chgd = cfg_u16(link, 18);
    out->dsg = cfg_u16(link, 20);
    out->dsgd = cfg_u16(link, 22);
    out->sc = cfg_u16(link, 24);
    out->scd = cfg_u16(link, 26);
    {
        int v;
        int slot = reg_slot(0x28);
        if (slot >= 0 && link->reg_ok[slot]) {
            int div = amp_div_of(link);
            int a;
            v = link->reg_v[slot];
            if (v < 0) v = -v;
            if (div == 10 || div == 100) a = (v + div / 2) / div;
            else if (v >= 500) a = (v + 50) / 100;
            else if (v >= 200) a = (v + 5) / 10;
            else a = v;
            out->chg = a;
        }
        slot = reg_slot(0x29);
        if (slot >= 0 && link->reg_ok[slot]) {
            int div = amp_div_of(link);
            int a;
            v = link->reg_v[slot];
            if (v < 0) v = -v;
            if (div == 10 || div == 100) a = (v + div / 2) / div;
            else if (v >= 500) a = (v + 50) / 100;
            else if (v >= 200) a = (v + 5) / 10;
            else a = v;
            out->dsg = a;
        }
    }
    snprintf(out->hw, sizeof(out->hw), "%s", link->hw);
    {
        int n = link->ncell;
        int i;
        if (n > 24) n = 24;
        for (i = 0; i < n; ++i) out->cells[i] = link->cells[i];
    }
}

void bms_link_text(int index, char *out, size_t cap)
{
    const link_t *link;
    if (!out || cap == 0) return;
    if (index < 0 || index > 1) {
        snprintf(out, cap, "нет");
        return;
    }
    link = &s_link[index];
    if (!link->ok) {
        snprintf(out, cap, "нет связи");
        return;
    }
    if (link->soc >= 0) {
        snprintf(out, cap, "%d.%02d В  %d.%02d А  %d%%",
                 link->mv / 1000, (link->mv / 10) % 100,
                 link->ma / 1000, (link->ma < 0 ? -link->ma : link->ma) / 10 % 100,
                 link->soc);
    } else {
        snprintf(out, cap, "%d.%02d В  %d.%02d А",
                 link->mv / 1000, (link->mv / 10) % 100,
                 link->ma / 1000, (link->ma < 0 ? -link->ma : link->ma) / 10 % 100);
    }
}

void bms_uart_start(void)
{
    gpio_config_t tx = {
        .pin_bit_mask = 1ULL << BMSA_TX,
        .mode = GPIO_MODE_OUTPUT,
    };
    gpio_config_t rx = {
        .pin_bit_mask = 1ULL << BMSA_RX,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
    };
    s_bus = xSemaphoreCreateMutex();
    gpio_config(&tx);
    gpio_set_level(BMSA_TX, 1);
    gpio_config(&rx);
    ESP_LOGW(TAG, "АКБ одна, soft 9600 TX GPIO1 RX GPIO2. Вторая АКБ и UART2 сняты. +13 В на ESP не подавать");
    xTaskCreate(task, "bms", 12288, NULL, 2, NULL);
}

int bms_json(char *out, size_t cap)
{
    int used = 0;
    int p;
    if (!out || cap < 16) return -1;
    used = snprintf(out, cap, "{\"ok\":true,\"ble_role\":%d,\"ble_pack\":%d,\"packs\":[",
                    settings_get_ble_role(), settings_get_bms_pack());
    for (p = 0; p < 1; ++p) {
        const link_t *L = &s_link[p];
        int i;
        int n;
        if ((size_t)used >= cap) return -1;
        n = snprintf(out + used, cap - (size_t)used,
                     "%s{\"ok\":%s,\"mv\":%d,\"ma\":%d,\"peak_ma\":%d,\"soc\":%d,\"mah\":%d,\"d_mv\":%d,\"ncell\":%d,"
                     "\"fet\":%d,\"bal\":%lu,\"cfg_ok\":%s,\"writable\":%s,\"hw\":\"%s\","
                     "\"chg\":%d,\"chgd\":%d,\"dsg\":%d,\"dsgd\":%d,\"sc\":%d,\"scd\":%d,\"amp_div\":%d,\"cells\":[",
                     p ? "," : "", L->ok ? "true" : "false", L->mv, L->ma, L->peak_ma, L->soc, L->remain_mah,
                     (L->ncell > 0) ? (L->cell_max_mv - L->cell_min_mv) : -1, L->ncell,
                     L->fet, (unsigned long)L->balance,
                     (L->cfg_len >= 18 || L->regs_n > 0) ? "true" : "false",
                     (L->cfg_writable || L->regs_n > 0) ? "true" : "false", L->hw,
                     cfg_u16(L, 16), cfg_u16(L, 18), cfg_u16(L, 20), cfg_u16(L, 22), cfg_u16(L, 24), cfg_u16(L, 26),
                     amp_div_of(L));
        if (n < 0) return -1;
        used += n;
        for (i = 0; i < L->ncell; ++i) {
            if ((size_t)used >= cap) return -1;
            n = snprintf(out + used, cap - (size_t)used, "%s%d", i ? "," : "", L->cells[i]);
            if (n < 0) return -1;
            used += n;
        }
        if ((size_t)used >= cap) return -1;
        n = snprintf(out + used, cap - (size_t)used, "],\"regs\":[");
        if (n < 0) return -1;
        used += n;
        for (i = 0; i < REG_N; ++i) {
            if ((size_t)used >= cap) return -1;
            n = snprintf(out + used, cap - (size_t)used, "%s{\"r\":%u,\"v\":%d,\"ok\":%d}",
                         i ? "," : "", (unsigned)k_reg[i], L->reg_ok[i] ? L->reg_v[i] : -1, L->reg_ok[i] ? 1 : 0);
            if (n < 0) return -1;
            used += n;
        }
        if ((size_t)used >= cap) return -1;
        n = snprintf(out + used, cap - (size_t)used, "]}");
        if (n < 0) return -1;
        used += n;
    }
    if ((size_t)used + 3 >= cap) return -1;
    out[used++] = ']';
    out[used++] = '}';
    out[used] = 0;
    return used;
}

int bms_cfg_write(int index, int offset, int value, int *readback)
{
    link_t *L;
    uint8_t tx[220];
    uint8_t rx[32];
    int nlen;
    int n;
    int got;
    if (readback) *readback = -1;
    if (index < 0 || index > 1 || offset < 0 || (offset & 1) || value < 0 || value > 65535) return -1;
    if (offset != 16 && offset != 18 && offset != 20 && offset != 22 && offset != 24 && offset != 26) return -1;
    L = &s_link[index];
    if (!s_bus || !L->cfg_writable || L->cfg_len < offset + 2) return -2;
    xSemaphoreTake(s_bus, portMAX_DELAY);
    (void)unlock_cfg(index);
    vTaskDelay(pdMS_TO_TICKS(30));
    L->cfg[offset] = (uint8_t)(value >> 8);
    L->cfg[offset + 1] = (uint8_t)value;
    nlen = frame(tx, 0x5A, 0xFA, L->cfg, L->cfg_len);
    n = xfer(index, tx, nlen, rx, sizeof(rx));
    n = sync_dd(rx, n);
    if (n < 4 || rx[0] != 0xDD || rx[2] != 0x00) {
        exit_factory(index, 0);
        xSemaphoreGive(s_bus);
        return -3;
    }
    vTaskDelay(pdMS_TO_TICKS(30));
    exit_factory(index, 1);
    vTaskDelay(pdMS_TO_TICKS(80));
    (void)unlock_cfg(index);
    vTaskDelay(pdMS_TO_TICKS(30));
    L->cfg_len = 0;
    L->cfg_writable = 0;
    (void)read_cfg_once(index, L);
    exit_factory(index, 0);
    got = cfg_u16(L, offset);
    if (readback) *readback = got;
    s_cfg_force[index] = (got == value) ? 0 : 1;
    xSemaphoreGive(s_bus);
    return got == value ? 0 : -4;
}

void bms_cfg_kick(void)
{
    s_cfg_force[0] = 1;
    s_cfg_force[1] = 1;
}

int bms_reg_write(int index, int reg, int value, int *readback)
{
    link_t *L;
    uint8_t data[2];
    uint8_t tx[16];
    uint8_t rx[24];
    int slot;
    int alt;
    int nlen;
    int n;
    int got = 0;
    int u;
    int wrote = 0;
    if (readback) *readback = -1;
    slot = reg_slot(reg);
    if (index < 0 || index > 1 || slot < 0 || value < -32768 || value > 65535) return -1;
    if (reg == 0x29 && value > 0) value = -value;
    if (reg == 0x28 && value < 0) value = -value;
    if (!s_bus) return -2;
    L = &s_link[index];
    xSemaphoreTake(s_bus, portMAX_DELAY);
    for (alt = 0; alt < 2 && !wrote; ++alt) {
        u = value & 0xFFFF;
        data[0] = (uint8_t)(u >> 8);
        data[1] = (uint8_t)u;
        enter_factory_pw(index, alt);
        vTaskDelay(pdMS_TO_TICKS(50));
        nlen = frame(tx, 0x5A, (uint8_t)reg, data, 2);
        n = xfer_ms(index, tx, nlen, rx, sizeof(rx), 200);
        n = sync_dd(rx, n);
        if (n >= 3 && rx[0] == 0xDD && rx[2] == 0x80) {
            exit_factory(index, 0);
            continue;
        }
        vTaskDelay(pdMS_TO_TICKS(40));
        exit_factory(index, 1);
        vTaskDelay(pdMS_TO_TICKS(400));
        enter_factory_pw(index, alt);
        vTaskDelay(pdMS_TO_TICKS(40));
        if (!read_reg(index, reg, &got)) {
            exit_factory(index, 0);
            continue;
        }
        exit_factory(index, 0);
        {
            int match;
            if (reg == 0x28 || reg == 0x29) {
                int a = got < 0 ? -got : got;
                int b = value < 0 ? -value : value;
                match = a == b;
            } else {
                match = ((got & 0xFFFF) == (value & 0xFFFF));
            }
            if (match) {
                wrote = 1;
                break;
            }
        }
    }
    if (readback) *readback = got;
    if (!wrote) {
        xSemaphoreGive(s_bus);
        return got == 0 ? -3 : -4;
    }
    L->reg_v[slot] = got;
    L->reg_ok[slot] = 1;
    if (L->regs_n < 1) L->regs_n = 1;
    xSemaphoreGive(s_bus);
    return 0;
}

void bms_bridge_hold(int on)
{
    s_hold = on ? 1 : 0;
    if (!s_hold) {
        taskENTER_CRITICAL(&s_brm);
        s_brn = 0;
        s_brr = 0;
        s_brw = 0;
        taskEXIT_CRITICAL(&s_brm);
        s_asm_n = 0;
    }
}

int bms_bridge_submit(const uint8_t *data, int len)
{
    int i;
    if (!data || len <= 0) return -1;
    for (i = 0; i < len; ++i) {
        if (s_asm_n >= BR_QMAX) s_asm_n = 0;
        s_asm[s_asm_n++] = data[i];
        for (;;) {
            int j = 0;
            int flen;
            int need;
            while (j < s_asm_n && s_asm[j] != 0xDD) j++;
            if (j > 0) {
                memmove(s_asm, s_asm + j, (size_t)(s_asm_n - j));
                s_asm_n -= j;
            }
            if (s_asm_n < 4) break;
            flen = s_asm[3];
            if (flen > 180) {
                memmove(s_asm, s_asm + 1, (size_t)(s_asm_n - 1));
                s_asm_n--;
                continue;
            }
            need = 7 + flen;
            if (need > BR_QMAX) {
                memmove(s_asm, s_asm + 1, (size_t)(s_asm_n - 1));
                s_asm_n--;
                continue;
            }
            if (s_asm_n < need) break;
            if (s_asm[need - 1] != 0x77) {
                memmove(s_asm, s_asm + 1, (size_t)(s_asm_n - 1));
                s_asm_n--;
                continue;
            }
            taskENTER_CRITICAL(&s_brm);
            if (s_brn >= BR_QN) {
                s_brr = (s_brr + 1) % BR_QN;
                s_brn--;
            }
            memcpy(s_brq[s_brw], s_asm, (size_t)need);
            s_brl[s_brw] = (uint8_t)need;
            s_brw = (s_brw + 1) % BR_QN;
            s_brn++;
            taskEXIT_CRITICAL(&s_brm);
            if (s_asm_n > need) memmove(s_asm, s_asm + need, (size_t)(s_asm_n - need));
            s_asm_n -= need;
        }
    }
    return 0;
}