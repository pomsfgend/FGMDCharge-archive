#pragma once

#include <stddef.h>
#include <stdint.h>

typedef struct {
    int ok;
    int mv;
    int ma;
    int peak_ma;
    int soc;
    int remain_mah;
    int fet;
    int cell_min_mv;
    int cell_max_mv;
    int ncell;
    int peak_mah;
    int cells[24];
    uint32_t balance;
    int cfg_ok;
    int cfg_writable;
    int regs_ok;
    int chg;
    int chgd;
    int dsg;
    int dsgd;
    int sc;
    int scd;
    char hw[32];
} bms_link_t;

void bms_uart_start(void);
void bms_link_get(int index, bms_link_t *out);
void bms_link_text(int index, char *out, size_t cap);
int bms_json(char *out, size_t cap);
int bms_cfg_write(int index, int offset, int value, int *readback);
int bms_reg_write(int index, int reg, int value, int *readback);
void bms_cfg_kick(void);
void bms_bridge_hold(int on);
int bms_bridge_submit(const uint8_t *data, int len);
