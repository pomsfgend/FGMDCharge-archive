Исходники 3.0.78 — куб и приложение Кабина в одном архиве.

cube/            прошивка ESP32-S3, CUBE_FW_VERSION 3.0.78
                 без каталогов сборки, .git, managed_components и старых дампов
cabin/           приложение Android «Кабина» 3.0.78
                 без .gradle и app/build
idf-patch/       правка ESP-IDF components/hal/twai_hal_iram.c
                 (символы cube_twai_ecc / cube_twai_alc). Без неё куб не соберётся так же.
                 Повторное объявление alc, которое ломает сборку, в этот файл не входит:
                 в прошивке 3.0.78 его не было.

Сборка куба: ESP-IDF 5.0.8, цель esp32s3, каталог сборки build-s3-round.
Сборка приложения: gradle assembleDebug, модуль app.
