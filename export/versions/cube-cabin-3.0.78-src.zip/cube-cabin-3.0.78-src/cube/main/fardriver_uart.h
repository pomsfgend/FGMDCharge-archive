#pragma once
#include <stddef.h>
#include <stdint.h>

void fardriver_uart_start(void);
void fardriver_uart_arm(void);
void fardriver_uart_write(const uint8_t *data, size_t len);
void fardriver_feed(const uint8_t *data, size_t len);
void fardriver_speed_text(char *out, size_t cap);
void fardriver_set_diameter_tenths(int tenths);
int fardriver_diameter_tenths(void);
void fardriver_set_poles(int poles);
int fardriver_poles(void);
void fardriver_set_circ_mm(int mm);
int fardriver_circ_mm(void);
void fardriver_set_gear_x1000(int gear);
int fardriver_gear_x1000(void);
void fardriver_set_trim_x1000(int trim);
int fardriver_trim_x1000(void);
/* Documented UART shutdown (cmd 0x04 sub 0x02). Does not hold the wheel. Returns 0 if BLE direct owns the line. */
int fardriver_shutdown(void);
int fardriver_listed_rpm(void);
int fardriver_rx_bytes(void);
void fardriver_set_direct(int on);
int fardriver_direct(void);
/* HM-10/JDY on the FarDriver UART. Returns how many replies contained OK. HC-05 is not BLE. */
int fardriver_program_ble(void);
void fardriver_stats(int *rpm, int *kmh_x10, int *link, int *max_rpm);
void fardriver_power(int *amps_x10, int *max_amps_x10, int *volts_x10, int *err_bits);
