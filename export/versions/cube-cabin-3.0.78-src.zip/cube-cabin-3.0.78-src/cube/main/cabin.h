#pragma once

#include <stddef.h>

void cabin_start(void);
int cabin_json(char *out, size_t cap);
void cabin_lcd(char *out, size_t cap);

void cabin_set_heat(int on);
void cabin_toggle_heat(void);
void cabin_set_light(int mode);
void cabin_cycle_light(void);
void cabin_set_comfort_c(int c);
void cabin_bump_comfort(int delta_c);
void cabin_set_seat_max_c(int c);
void cabin_set_amp_lim_a(int a);
void cabin_set_duty_max(int pct);
void cabin_set_heat_mode(int mode);
void cabin_set_manual_duty(int pct);
void cabin_set_amb_on_c(int c);
void cabin_set_lux(int on_lux, int off_lux);
void cabin_set_relay(int channel, int on);
void cabin_set_zvs(int on);
