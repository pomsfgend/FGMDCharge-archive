#pragma once
#include <stddef.h>
void votol_uart_start(void);
void votol_link_text(char *out, size_t cap);
