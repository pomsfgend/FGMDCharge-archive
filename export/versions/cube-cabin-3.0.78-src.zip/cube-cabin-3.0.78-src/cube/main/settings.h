#pragma once

#include <stddef.h>
#include "esp_err.h"

#include "config.h"

esp_err_t settings_init(void);
esp_err_t settings_get_ble_name(char *out, size_t out_size);
esp_err_t settings_set_ble_name(const char *name);
int settings_get_ble_role(void);
esp_err_t settings_set_ble_role(int role);
int settings_get_bms_pack(void);
esp_err_t settings_set_bms_pack(int pack);
