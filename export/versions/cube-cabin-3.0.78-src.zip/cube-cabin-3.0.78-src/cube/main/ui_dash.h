#pragma once
#include "lvgl.h"

void ui_dash_build(lv_obj_t *scr);
void ui_dash_tick(void);
void ui_dash_fit(void);
void ui_dash_load(void);
void ui_dash_set_cycle(int on);
void ui_dash_set_dwell(int sec);
void ui_dash_set_page(int n);
int ui_dash_get_cycle(void);
int ui_dash_get_dwell(void);
int ui_dash_get_page(void);
