#pragma once
#include "esp_heap_caps.h"
#undef malloc
#undef free
#undef realloc
#define malloc(size) heap_caps_malloc((size), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)
#define free(ptr) heap_caps_free(ptr)
#define realloc(ptr, size) heap_caps_realloc((ptr), (size), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)
