#include "fardriver_uart.h"

#include "ble.h"
#include "ble_fd.h"
#include "settings.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#define FD_UART  UART_NUM_1
#define FD_TX    48
#define FD_RX    39
#define FD_BAUD  19200
#define FD_BUF   1024

static const char *TAG = "FARDRIVER";
static int s_listed = -1;
static int s_rpm = -1;
static int s_kmh_x10 = -1;
static int s_diam_tenths = 163;
static int s_poles = 20;
static int s_circ_mm;
static int s_gear_x1000 = 1000;
static int s_trim_x1000 = 1000;
static int64_t s_seen_us;
static TaskHandle_t s_rx_task;
static uint32_t s_rx_n;
static uint32_t s_tx_n;
static uint32_t s_frames;
static uint8_t s_last[4];
static int s_direct;
static volatile int s_hold;
static int s_max_rpm;
static int s_amps_x10;
static int s_max_amps;
static int s_volts_x10;
static int s_err;
static int64_t s_log_us;
static int64_t s_poll_us;

/* CRC and address map from jackhumbert/fardriver-controllers. Verified on frame AA 80 .. 1F FF. */
static const uint8_t k_crc_lo[256] = {
    0, 192, 193, 1, 195, 3, 2, 194, 198, 6, 7, 199, 5, 197, 196, 4, 204, 12, 13, 205, 15, 207, 206, 14, 10, 202, 203, 11, 201, 9, 8, 200, 216, 24, 25, 217, 27, 219, 218, 26, 30, 222, 223, 31, 221, 29, 28, 220, 20, 212, 213, 21, 215, 23, 22, 214, 210, 18, 19, 211, 17, 209, 208, 16, 240, 48, 49, 241, 51, 243, 242, 50, 54, 246, 247, 55, 245, 53, 52, 244, 60, 252, 253, 61, 255, 63, 62, 254, 250, 58, 59, 251, 57, 249, 248, 56, 40, 232, 233, 41, 235, 43, 42, 234, 238, 46, 47, 239, 45, 237, 236, 44, 228, 36, 37, 229, 39, 231, 230, 38, 34, 226, 227, 35, 225, 33, 32, 224, 160, 96, 97, 161, 99, 163, 162, 98, 102, 166, 167, 103, 165, 101, 100, 164, 108, 172, 173, 109, 175, 111, 110, 174, 170, 106, 107, 171, 105, 169, 168, 104, 120, 184, 185, 121, 187, 123, 122, 186, 190, 126, 127, 191, 125, 189, 188, 124, 180, 116, 117, 181, 119, 183, 182, 118, 114, 178, 179, 115, 177, 113, 112, 176, 80, 144, 145, 81, 147, 83, 82, 146, 150, 86, 87, 151, 85, 149, 148, 84, 156, 92, 93, 157, 95, 159, 158, 94, 90, 154, 155, 91, 153, 89, 88, 152, 136, 72, 73, 137, 75, 139, 138, 74, 78, 142, 143, 79, 141, 77, 76, 140, 68, 132, 133, 69, 135, 71, 70, 134, 130, 66, 67, 131, 65, 129, 128, 64
};
static const uint8_t k_crc_hi[256] = {
    0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 1, 192, 128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 1, 192, 128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 1, 192, 128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 1, 192, 128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 1, 192, 128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 129, 64
};
static const uint8_t k_addr[55] = {
    0xE2, 0xE8, 0xEE, 0x00, 0x06, 0x0C, 0x12,
    0xE2, 0xE8, 0xEE, 0x18, 0x1E, 0x24, 0x2A,
    0xE2, 0xE8, 0xEE, 0x30, 0x5D, 0x63, 0x69,
    0xE2, 0xE8, 0xEE, 0x7C, 0x82, 0x88, 0x8E,
    0xE2, 0xE8, 0xEE, 0x94, 0x9A, 0xA0, 0xA6,
    0xE2, 0xE8, 0xEE, 0xAC, 0xB2, 0xB8, 0xBE,
    0xE2, 0xE8, 0xEE, 0xC4, 0xCA, 0xD0,
    0xE2, 0xE8, 0xEE, 0xD6, 0xDC, 0xF4, 0xFA
};
/* 0x13 / sub 0x07: controller starts sending 16-byte status. Idle line is only ASCII VERSIONA. */
static const uint8_t k_poll[8] = {0xAA, 0x13, 0xEC, 0x07, 0x01, 0xF1, 0xA2, 0x5D};

void fardriver_uart_write(const uint8_t *data, size_t len);

static int frame_crc_ok(const uint8_t *d)
{
    uint8_t a = 0x3C;
    uint8_t b = 0x7F;
    int i;
    for (i = 0; i < 14; ++i) {
        uint8_t k = (uint8_t)(a ^ d[i]);
        a = (uint8_t)(b ^ k_crc_hi[k]);
        b = k_crc_lo[k];
    }
    return d[14] == a && d[15] == b;
}

static void recompute_speed(void)
{
    int poles = s_poles < 2 ? 20 : s_poles;
    int gear = s_gear_x1000 < 100 ? 1000 : s_gear_x1000;
    int trim = s_trim_x1000 < 200 ? 1000 : s_trim_x1000;
    int mech;
    int64_t kmh10;
    if (s_listed < 0) {
        s_rpm = -1;
        s_kmh_x10 = -1;
        return;
    }
    mech = (int)(((int64_t)s_listed * 4) / poles);
    if (mech < 0) mech = 0;
    s_rpm = mech;
    if (mech > s_max_rpm) s_max_rpm = mech;
    if (s_circ_mm >= 200) {
        kmh10 = (int64_t)mech * (int64_t)s_circ_mm * 60;
        kmh10 /= 100000;
    } else {
        kmh10 = ((int64_t)mech * (int64_t)s_diam_tenths * 4788LL) / 1000000LL;
    }
    kmh10 = kmh10 * 1000 / gear;
    kmh10 = kmh10 * trim / 1000;
    if (kmh10 < 0) kmh10 = 0;
    if (kmh10 > 30000) kmh10 = 30000;
    s_kmh_x10 = (int)kmh10;
}

static void take_frame(const uint8_t *fr)
{
    int id = fr[1] & 0x3F;
    const uint8_t *d = fr + 2;
    uint8_t addr;
    if ((fr[1] >> 6) != 2 || id >= 55) return;
    if (!frame_crc_ok(fr)) return;
    addr = k_addr[id];
    s_frames++;
    s_seen_us = esp_timer_get_time();
    if (addr == 0xE2) {
        s_listed = (int)d[6] | ((int)d[7] << 8);
        s_err = (int)d[2] | ((int)d[3] << 8);
        recompute_speed();
    } else if (addr == 0xE8) {
        int16_t volts = (int16_t)((uint16_t)d[0] | ((uint16_t)d[1] << 8));
        int16_t amps = (int16_t)((uint16_t)d[4] | ((uint16_t)d[5] << 8));
        int ax10 = ((int)amps * 10) / 4;
        s_volts_x10 = volts;
        if (ax10 < 0) ax10 = -ax10;
        s_amps_x10 = ax10;
        if (ax10 > s_max_amps) s_max_amps = ax10;
    }
}

static void note_byte(uint8_t b)
{
    static uint8_t win[16];
    static int n;
    if (n < 16) win[n++] = b;
    else {
        memmove(win, win + 1, 15);
        win[15] = b;
    }
    if (n < 16 || win[0] != 0xAA) return;
    if ((win[1] >> 6) != 2 || (win[1] & 0x3F) >= 55 || !frame_crc_ok(win)) return;
    take_frame(win);
    n = 0;
}

static void rx_task(void *arg)
{
    uint8_t buf[180];
    (void)arg;
    s_log_us = esp_timer_get_time();
    for (;;) {
        int n;
        int64_t now;
        int phone;
        if (s_hold) {
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }
        n = uart_read_bytes(FD_UART, buf, sizeof(buf), pdMS_TO_TICKS(200));
        if (n < 0) {
            vTaskDelay(pdMS_TO_TICKS(200));
            continue;
        }
        now = esp_timer_get_time();
        phone = s_direct && cube_ble_is_connected();
        if (n > 0) {
            s_rx_n += (uint32_t)n;
            s_last[0] = buf[n > 4 ? n - 4 : 0];
            s_last[1] = buf[n > 3 ? n - 3 : 0];
            s_last[2] = buf[n > 2 ? n - 2 : 0];
            s_last[3] = buf[n - 1];
            for (int i = 0; i < n; ++i) note_byte(buf[i]);
            if (phone) {
                (void)cube_ble_notify(buf, (uint16_t)n);
            }
        }
        if (!phone && !ble_fd_linked() && now - s_poll_us >= 1000000) {
            s_poll_us = now;
            fardriver_uart_write(k_poll, sizeof(k_poll));
        }
        if (now - s_log_us >= 3000000) {
            s_log_us = now;
            ESP_LOGW(TAG, "uart rx=%u tx=%u кадры=%u счетчик=%d колесо=%d kmh10=%d poles=%d last=%02x %02x %02x %02x",
                     (unsigned)s_rx_n, (unsigned)s_tx_n, (unsigned)s_frames, s_listed, s_rpm, s_kmh_x10, s_poles,
                     s_last[0], s_last[1], s_last[2], s_last[3]);
        }
    }
}

void fardriver_speed_text(char *out, size_t cap)
{
    int64_t age;
    int kmh;
    int rpm;
    if (!out || cap == 0) return;
    age = esp_timer_get_time() - s_seen_us;
    if (s_seen_us == 0 || age > 3000000) {
        if (s_direct && cube_ble_is_connected()) snprintf(out, cap, "мост CONTROLDM");
        else if (s_rx_n > 0) snprintf(out, cap, "линия есть, кадра нет");
        else snprintf(out, cap, "тишина");
        return;
    }
    kmh = s_kmh_x10 < 0 ? 0 : s_kmh_x10;
    rpm = s_rpm < 0 ? 0 : s_rpm;
    snprintf(out, cap, "%d.%d км/ч  %d об", kmh / 10, kmh % 10, rpm);
}

void fardriver_set_diameter_tenths(int tenths)
{
    nvs_handle_t h;
    if (tenths < 80 || tenths > 400) return;
    s_diam_tenths = tenths;
    recompute_speed();
    if (nvs_open("storage", NVS_READWRITE, &h) == ESP_OK) {
        nvs_set_u16(h, "fd_diam", (uint16_t)tenths);
        nvs_commit(h);
        nvs_close(h);
    }
}

int fardriver_diameter_tenths(void)
{
    return s_diam_tenths;
}

void fardriver_set_poles(int poles)
{
    nvs_handle_t h;
    if (poles < 2 || poles > 80) return;
    s_poles = poles;
    recompute_speed();
    if (nvs_open("storage", NVS_READWRITE, &h) == ESP_OK) {
        nvs_set_u16(h, "fd_poles", (uint16_t)poles);
        nvs_commit(h);
        nvs_close(h);
    }
}

int fardriver_poles(void)
{
    return s_poles;
}

static void nvs_u16(const char *key, int value)
{
    nvs_handle_t h;
    if (nvs_open("storage", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u16(h, key, (uint16_t)value);
    nvs_commit(h);
    nvs_close(h);
}

void fardriver_set_circ_mm(int mm)
{
    if (mm < 0 || mm > 6000) return;
    if (mm > 0 && mm < 200) return;
    s_circ_mm = mm;
    recompute_speed();
    nvs_u16("fd_circ", mm);
}

int fardriver_circ_mm(void)
{
    return s_circ_mm;
}

void fardriver_set_gear_x1000(int gear)
{
    if (gear < 100 || gear > 40000) return;
    s_gear_x1000 = gear;
    recompute_speed();
    nvs_u16("fd_gear", gear);
}

int fardriver_gear_x1000(void)
{
    return s_gear_x1000;
}

void fardriver_set_trim_x1000(int trim)
{
    if (trim < 200 || trim > 3000) return;
    s_trim_x1000 = trim;
    recompute_speed();
    nvs_u16("fd_trim", trim);
}

int fardriver_trim_x1000(void)
{
    return s_trim_x1000;
}

int fardriver_shutdown(void)
{
    static const uint8_t pkt[8] = {0xAA, 0x04, 0xFB, 0x02, 0x00, 0x00, 0xAB, 0x54};
    if (s_direct && cube_ble_is_connected()) return 0;
    fardriver_uart_write(pkt, sizeof(pkt));
    return 1;
}

int fardriver_listed_rpm(void)
{
    return s_listed < 0 ? 0 : s_listed;
}

int fardriver_rx_bytes(void)
{
    return (int)s_rx_n;
}

void fardriver_set_direct(int on)
{
    if (on && settings_get_ble_role() == 1) on = 0;
    s_direct = on ? 1 : 0;
    if (s_direct) {
        s_rpm = -1;
        s_kmh_x10 = -1;
    }
}

int fardriver_direct(void)
{
    return s_direct;
}

int fardriver_program_ble(void)
{
    static const int bauds[] = {9600, 38400, 19200};
    static const char *cmds[] = {
        "AT+NAME=CONTROLDM\r\n",
        "AT+NAMECONTROLDM\r\n",
        "AT+TUUID=FFEC\r\n",
        "AT+ROLE=0\r\n",
        "AT+ROLE0\r\n",
        "AT+TYPE=0\r\n",
        "AT+BAUD=19200\r\n",
        "AT+RESET\r\n",
    };
    uint8_t buf[80];
    uint32_t back = FD_BAUD;
    int hits = 0;
    if (s_hold) return 0;
    (void)uart_get_baudrate(FD_UART, &back);
    s_hold = 1;
    vTaskDelay(pdMS_TO_TICKS(280));
    for (size_t b = 0; b < sizeof(bauds) / sizeof(bauds[0]); ++b) {
        uart_flush(FD_UART);
        uart_set_baudrate(FD_UART, bauds[b]);
        uart_flush_input(FD_UART);
        for (size_t c = 0; c < sizeof(cmds) / sizeof(cmds[0]); ++c) {
            int n;
            uart_write_bytes(FD_UART, cmds[c], strlen(cmds[c]));
            vTaskDelay(pdMS_TO_TICKS(50));
            n = uart_read_bytes(FD_UART, buf, sizeof(buf) - 1, pdMS_TO_TICKS(30));
            if (n > 0) {
                buf[n] = 0;
                if (strstr((char *)buf, "OK") || strstr((char *)buf, "ok")) hits++;
            }
        }
    }
    uart_flush(FD_UART);
    uart_set_baudrate(FD_UART, back ? back : (uint32_t)FD_BAUD);
    uart_flush_input(FD_UART);
    s_hold = 0;
    ESP_LOGW(TAG, "AT module oks=%d", hits);
    return hits;
}

void fardriver_stats(int *rpm, int *kmh_x10, int *link, int *max_rpm)
{
    int64_t age = esp_timer_get_time() - s_seen_us;
    int ok = s_seen_us != 0 && age >= 0 && age < 3000000;
    if (rpm) *rpm = ok ? (s_rpm < 0 ? 0 : s_rpm) : 0;
    if (kmh_x10) *kmh_x10 = ok ? s_kmh_x10 : 0;
    if (link) *link = ok;
    if (max_rpm) *max_rpm = s_max_rpm;
}

void fardriver_power(int *amps_x10, int *max_amps_x10, int *volts_x10, int *err_bits)
{
    int64_t age = esp_timer_get_time() - s_seen_us;
    int ok = s_seen_us != 0 && age >= 0 && age < 3000000;
    if (amps_x10) *amps_x10 = ok ? s_amps_x10 : 0;
    if (max_amps_x10) *max_amps_x10 = s_max_amps;
    if (volts_x10) *volts_x10 = ok ? s_volts_x10 : 0;
    if (err_bits) *err_bits = ok ? s_err : 0;
}

void fardriver_feed(const uint8_t *data, size_t len)
{
    size_t i;
    if (!data || len == 0) return;
    for (i = 0; i < len; ++i) note_byte(data[i]);
}

void fardriver_uart_write(const uint8_t *data, size_t len)
{
    if (!data || len == 0) return;
    int w = uart_write_bytes(FD_UART, data, len);
    if (w > 0) s_tx_n += (uint32_t)w;
}

static int probe_score(const uint8_t *buf, int n)
{
    int score = 0;
    int zeros = 0;
    if (n < 8) return 0;
    for (int i = 0; i < n; ++i) {
        if (buf[i] == 0x00) zeros++;
        if (buf[i] == 0xAA) score += 4;
        if (i + 1 < n && buf[i] == 'A' && buf[i + 1] == 'T') score += 2;
    }
    if (zeros * 4 > n * 3) return 0;
    return score;
}

static void pick_baud(void)
{
    static const int bauds[] = {19200, 115200, 921600};
    int best = 19200;
    int best_score = -1;
    uint8_t buf[192];
    for (size_t i = 0; i < sizeof(bauds) / sizeof(bauds[0]); ++i) {
        int n = 0;
        uart_set_baudrate(FD_UART, bauds[i]);
        uart_flush_input(FD_UART);
        int64_t t0 = esp_timer_get_time();
        while (n < (int)sizeof(buf) && esp_timer_get_time() - t0 < 180000) {
            int r = uart_read_bytes(FD_UART, buf + n, (uint32_t)(sizeof(buf) - n), pdMS_TO_TICKS(30));
            if (r > 0) n += r;
        }
        int score = probe_score(buf, n);
        ESP_LOGW(TAG, "probe %d n=%d score=%d %02x %02x %02x %02x",
                 bauds[i], n, score,
                 n > 0 ? buf[0] : 0, n > 1 ? buf[1] : 0,
                 n > 2 ? buf[2] : 0, n > 3 ? buf[3] : 0);
        if (score > best_score) {
            best_score = score;
            best = bauds[i];
        }
    }
    if (best_score <= 0) best = 19200;
    uart_set_baudrate(FD_UART, best);
    uart_flush_input(FD_UART);
    ESP_LOGW(TAG, "Fardriver baud %d", best);
}

void fardriver_uart_start(void)
{
    nvs_handle_t h;
    uint16_t saved = 0;
    if (nvs_open("storage", NVS_READONLY, &h) == ESP_OK) {
        if (nvs_get_u16(h, "fd_diam", &saved) == ESP_OK && saved >= 80 && saved <= 400)
            s_diam_tenths = saved;
        saved = 0;
        if (nvs_get_u16(h, "fd_poles", &saved) == ESP_OK && saved >= 2 && saved <= 80)
            s_poles = saved;
        saved = 0;
        if (nvs_get_u16(h, "fd_circ", &saved) == ESP_OK && (saved == 0 || (saved >= 200 && saved <= 6000)))
            s_circ_mm = saved;
        saved = 0;
        if (nvs_get_u16(h, "fd_gear", &saved) == ESP_OK && saved >= 100 && saved <= 40000)
            s_gear_x1000 = saved;
        saved = 0;
        if (nvs_get_u16(h, "fd_trim", &saved) == ESP_OK && saved >= 200 && saved <= 3000)
            s_trim_x1000 = saved;
        nvs_close(h);
    }
    uart_config_t cfg = {
        .baud_rate = FD_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    if (uart_is_driver_installed(FD_UART)) {
        uart_driver_delete(FD_UART);
    }
    if (uart_driver_install(FD_UART, FD_BUF, FD_BUF, 0, NULL, 0) != ESP_OK ||
        uart_param_config(FD_UART, &cfg) != ESP_OK ||
        uart_set_pin(FD_UART, FD_TX, FD_RX, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE) != ESP_OK) {
        if (uart_is_driver_installed(FD_UART)) uart_driver_delete(FD_UART);
        ESP_LOGE(TAG, "UART1 install failed");
        return;
    }
    uart_flush_input(FD_UART);
    {
        nvs_handle_t h;
        uint16_t saved = 0;
        if (nvs_open("storage", NVS_READONLY, &h) == ESP_OK) {
            if (nvs_get_u16(h, "fd_diam", &saved) == ESP_OK && saved >= 80 && saved <= 400)
                s_diam_tenths = saved;
            saved = 0;
            if (nvs_get_u16(h, "fd_poles", &saved) == ESP_OK && saved >= 2 && saved <= 80)
                s_poles = saved;
            saved = 0;
            if (nvs_get_u16(h, "fd_circ", &saved) == ESP_OK && (saved == 0 || (saved >= 200 && saved <= 6000)))
                s_circ_mm = saved;
            saved = 0;
            if (nvs_get_u16(h, "fd_gear", &saved) == ESP_OK && saved >= 100 && saved <= 40000)
                s_gear_x1000 = saved;
            saved = 0;
            if (nvs_get_u16(h, "fd_trim", &saved) == ESP_OK && saved >= 200 && saved <= 3000)
                s_trim_x1000 = saved;
            nvs_close(h);
        }
    }
    pick_baud();
    gpio_set_pull_mode(FD_RX, GPIO_PULLUP_ONLY);
    xTaskCreatePinnedToCore(rx_task, "fd_rx", 4096, NULL, 4, &s_rx_task, 1);
    ESP_LOGW(TAG, "ESP TX GPIO%d -> RXD фарика, ESP RX GPIO%d <- TXD фарика, 8N1", FD_TX, FD_RX);
}

void fardriver_uart_arm(void)
{
    /* Hardware UART is already running. Kept for call-site compatibility. */
}
