#include "config.h"
#include "esp_log.h"

#if (CUBE_LCD_BL_PWM_GPIO >= 0)
#include "driver/ledc.h"
#endif

static const char *TAG = "ADC_PWM";

void adc_pwm_init(void)
{
    /* Backlight is owned by display.c (GPIO21, full duty). A second LEDC
     * setup here used duty 100/1023 (~10%) and dimmed the panel to a pale
     * flicker after the UI had already turned the backlight fully on. */
    ESP_LOGW(TAG, "backlight left to display");
}
