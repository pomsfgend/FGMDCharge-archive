#include "ble_fd.h"
#include "fardriver_uart.h"
#include "esp_log.h"
#include "esp_gattc_api.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdio.h>
#include <string.h>

static const char *TAG = "FD-BLE";
static const uint8_t k_poll[8] = {0xAA, 0x13, 0xEC, 0x07, 0x01, 0xF1, 0xA2, 0x5D};

#define FD_N 12
typedef struct {
    uint8_t addr[6];
    uint8_t type;
    int rssi;
    char name[20];
} fd_seen_t;

static fd_seen_t s_dev[FD_N];
static int s_ndev;
static int s_scanning;
static int s_linked;
static esp_gatt_if_t s_gif = ESP_GATT_IF_NONE;
static uint16_t s_conn;
static uint8_t s_peer[6];
static char s_peer_name[20];
static uint16_t s_write;
static uint16_t s_svc_s[8];
static uint16_t s_svc_e[8];
static int s_nsvc;

static void mac_text(const uint8_t *a, char *out, int cap)
{
    snprintf(out, (size_t)cap, "%02X:%02X:%02X:%02X:%02X:%02X",
             a[0], a[1], a[2], a[3], a[4], a[5]);
}

static void subscribe(uint16_t start, uint16_t end)
{
    uint16_t n = 0;
    esp_gattc_char_elem_t ch[12];
    if (s_gif == ESP_GATT_IF_NONE) return;
    if (esp_ble_gattc_get_attr_count(s_gif, s_conn, ESP_GATT_DB_CHARACTERISTIC,
                                     start, end, 0, &n) != ESP_GATT_OK || n == 0) return;
    if (n > 12) n = 12;
    if (esp_ble_gattc_get_all_char(s_gif, s_conn, start, end, ch, &n, 0) != ESP_GATT_OK) return;
    for (int i = 0; i < n; ++i) {
        if (ch[i].properties & (ESP_GATT_CHAR_PROP_BIT_WRITE | ESP_GATT_CHAR_PROP_BIT_WRITE_NR))
            s_write = ch[i].char_handle;
        if (ch[i].properties & ESP_GATT_CHAR_PROP_BIT_NOTIFY)
            esp_ble_gattc_register_for_notify(s_gif, s_peer, ch[i].char_handle);
    }
}

static void gattc_cb(esp_gattc_cb_event_t event, esp_gatt_if_t gif, esp_ble_gattc_cb_param_t *p)
{
    if (event == ESP_GATTC_REG_EVT) {
        if (p->reg.status == ESP_GATT_OK) s_gif = gif;
        return;
    }
    if (s_gif != ESP_GATT_IF_NONE && gif != s_gif) return;
    switch (event) {
        case ESP_GATTC_OPEN_EVT:
            if (p->open.status != ESP_GATT_OK) {
                s_linked = 0;
                ESP_LOGW(TAG, "open fail %d", p->open.status);
                break;
            }
            s_conn = p->open.conn_id;
            s_linked = 1;
            s_nsvc = 0;
            s_write = 0;
            esp_ble_gattc_send_mtu_req(s_gif, s_conn);
            break;
        case ESP_GATTC_CFG_MTU_EVT:
            esp_ble_gattc_search_service(s_gif, s_conn, NULL);
            break;
        case ESP_GATTC_SEARCH_RES_EVT:
            if (s_nsvc < 8) {
                s_svc_s[s_nsvc] = p->search_res.start_handle;
                s_svc_e[s_nsvc] = p->search_res.end_handle;
                s_nsvc++;
            }
            break;
        case ESP_GATTC_SEARCH_CMPL_EVT:
            for (int i = 0; i < s_nsvc; ++i) subscribe(s_svc_s[i], s_svc_e[i]);
            ESP_LOGW(TAG, "services %d write %u", s_nsvc, (unsigned)s_write);
            break;
        case ESP_GATTC_REG_FOR_NOTIFY_EVT: {
            uint16_t count = 4;
            esp_gattc_descr_elem_t d[4];
            uint16_t h = p->reg_for_notify.handle;
            if (esp_ble_gattc_get_all_descr(s_gif, s_conn, h, d, &count, 0) == ESP_GATT_OK) {
                uint8_t on[2] = {0x01, 0x00};
                for (int i = 0; i < count; ++i) {
                    if (d[i].uuid.len == ESP_UUID_LEN_16 && d[i].uuid.uuid.uuid16 == 0x2902)
                        esp_ble_gattc_write_char_descr(s_gif, s_conn, d[i].handle, 2, on,
                                                       ESP_GATT_WRITE_TYPE_RSP, ESP_GATT_AUTH_REQ_NONE);
                }
            }
            break;
        }
        case ESP_GATTC_NOTIFY_EVT:
            fardriver_feed(p->notify.value, p->notify.value_len);
            break;
        case ESP_GATTC_DISCONNECT_EVT:
            s_linked = 0;
            s_write = 0;
            ESP_LOGW(TAG, "drop");
            break;
        default:
            break;
    }
}

static void poll_task(void *arg)
{
    (void)arg;
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(1000));
        if (!s_linked || s_write == 0 || s_gif == ESP_GATT_IF_NONE) continue;
        esp_ble_gattc_write_char(s_gif, s_conn, s_write, sizeof(k_poll), (uint8_t *)k_poll,
                                 ESP_GATT_WRITE_TYPE_NO_RSP, ESP_GATT_AUTH_REQ_NONE);
    }
}

void ble_fd_start(void)
{
    static int once;
    esp_ble_gattc_register_callback(gattc_cb);
    esp_ble_gattc_app_register(0x56);
    if (!once) {
        once = 1;
        xTaskCreate(poll_task, "fdble", 3072, NULL, 4, NULL);
    }
}

void ble_fd_on_gap(esp_gap_ble_cb_event_t event, esp_ble_gap_cb_param_t *param)
{
    if (event == ESP_GAP_BLE_SCAN_PARAM_SET_COMPLETE_EVT) {
        esp_ble_gap_start_scanning(8);
        return;
    }
    if (event != ESP_GAP_BLE_SCAN_RESULT_EVT || !param) return;
    if (param->scan_rst.search_evt != ESP_GAP_SEARCH_INQ_RES_EVT) {
        if (param->scan_rst.search_evt == ESP_GAP_SEARCH_INQ_CMPL_EVT) s_scanning = 0;
        return;
    }
    uint8_t len = 0;
    uint8_t *name = esp_ble_resolve_adv_data(param->scan_rst.ble_adv, ESP_BLE_AD_TYPE_NAME_CMPL, &len);
    if (!name) name = esp_ble_resolve_adv_data(param->scan_rst.ble_adv, ESP_BLE_AD_TYPE_NAME_SHORT, &len);
    char nm[20];
    nm[0] = 0;
    if (name && len) {
        if (len > 19) len = 19;
        memcpy(nm, name, len);
        nm[len] = 0;
    }
    for (int i = 0; i < s_ndev; ++i) {
        if (memcmp(s_dev[i].addr, param->scan_rst.bda, 6) == 0) {
            s_dev[i].rssi = param->scan_rst.rssi;
            if (nm[0]) snprintf(s_dev[i].name, sizeof(s_dev[i].name), "%s", nm);
            return;
        }
    }
    if (s_ndev >= FD_N) return;
    memcpy(s_dev[s_ndev].addr, param->scan_rst.bda, 6);
    s_dev[s_ndev].type = param->scan_rst.ble_addr_type;
    s_dev[s_ndev].rssi = param->scan_rst.rssi;
    snprintf(s_dev[s_ndev].name, sizeof(s_dev[s_ndev].name), "%s", nm);
    s_ndev++;
}

void ble_fd_scan(void)
{
    /* One radio. Role 0 advertises CONTROLDM; a scan would drop that bridge. */
    ESP_LOGW(TAG, "скан выключен, куб светится как CONTROLDM");
}

int ble_fd_connect(const char *mac)
{
    (void)mac;
    return 0;
}

void ble_fd_drop(void)
{
    if (s_linked && s_gif != ESP_GATT_IF_NONE) esp_ble_gattc_close(s_gif, s_conn);
    s_linked = 0;
}

int ble_fd_linked(void) { return s_linked; }

int ble_fd_json(char *out, int cap)
{
    int n;
    char mac[20];
    if (!out || cap < 32) return -1;
    mac_text(s_peer, mac, sizeof(mac));
    n = snprintf(out, (size_t)cap, "{\"scanning\":%d,\"link\":%d,\"peer\":\"%s\",\"name\":\"%s\",\"items\":[",
                 s_scanning, s_linked, s_linked ? mac : "", s_peer_name);
    for (int i = 0; i < s_ndev && n > 0 && n < cap - 48; ++i) {
        char a[20];
        mac_text(s_dev[i].addr, a, sizeof(a));
        n += snprintf(out + n, (size_t)(cap - n), "%s{\"name\":\"%s\",\"addr\":\"%s\",\"rssi\":%d}",
                      i ? "," : "", s_dev[i].name, a, s_dev[i].rssi);
    }
    if (n > 0 && n < cap - 3) n += snprintf(out + n, (size_t)(cap - n), "]}");
    return n;
}
