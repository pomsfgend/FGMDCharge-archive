#include "votol_uart.h"

#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_rom_sys.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include <stdio.h>
#include <string.h>

#define VOTOL_RX 5
#define BIT_US 104

static const char *TAG = "VOTOL";
static SemaphoreHandle_t s_edge;
static int s_bytes;
static uint8_t s_last[8];
static int s_last_n;

static void IRAM_ATTR rx_isr(void *arg)
{
    BaseType_t wake = pdFALSE;
    (void)arg;
    gpio_intr_disable(VOTOL_RX);
    xSemaphoreGiveFromISR(s_edge, &wake);
    if (wake) portYIELD_FROM_ISR();
}

static int read_byte(void)
{
    int value = 0;
    esp_rom_delay_us(BIT_US + BIT_US / 2);
    for (int i = 0; i < 8; ++i) {
        if (gpio_get_level(VOTOL_RX)) value |= 1 << i;
        esp_rom_delay_us(BIT_US);
    }
    esp_rom_delay_us(BIT_US);
    return value;
}

static void task(void *arg)
{
    (void)arg;
    for (;;) {
        if (xSemaphoreTake(s_edge, pdMS_TO_TICKS(30)) == pdTRUE) {
            int byte = read_byte();
            gpio_intr_enable(VOTOL_RX);
            s_last[s_bytes & 7] = (uint8_t)byte;
            s_bytes++;
            if (s_last_n < 8) s_last_n++;
        } else {
            gpio_intr_enable(VOTOL_RX);
        }
    }
}

void votol_link_text(char *out, size_t cap)
{
    if (!out || cap == 0) return;
    if (s_bytes <= 0) {
        snprintf(out, cap, "тишина");
        return;
    }
    int i = s_bytes - 4;
    if (i < 0) i = 0;
    snprintf(out, cap, "%d байт %02X %02X %02X %02X",
             s_bytes,
             s_last[i & 7], s_last[(i + 1) & 7], s_last[(i + 2) & 7], s_last[(i + 3) & 7]);
}

void votol_uart_start(void)
{
    gpio_config_t rx = {0};
    rx.pin_bit_mask = 1ULL << VOTOL_RX;
    rx.mode = GPIO_MODE_INPUT;
    rx.pull_up_en = GPIO_PULLUP_ENABLE;
    rx.intr_type = GPIO_INTR_NEGEDGE;
    gpio_config(&rx);
    s_edge = xSemaphoreCreateBinary();
    esp_err_t err = gpio_install_isr_service(0);
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
        ESP_LOGE(TAG, "isr %s", esp_err_to_name(err));
        return;
    }
    gpio_isr_handler_add(VOTOL_RX, rx_isr, NULL);
    xTaskCreate(task, "votol", 3072, NULL, 4, NULL);
    ESP_LOGW(TAG, "RX GPIO5, 9600, только чтение. GPIO4 не трогаем: это АЦП HV");
}
