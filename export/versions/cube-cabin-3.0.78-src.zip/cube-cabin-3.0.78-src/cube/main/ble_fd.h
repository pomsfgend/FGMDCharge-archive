#pragma once
#include "esp_gap_ble_api.h"

void ble_fd_start(void);
void ble_fd_on_gap(esp_gap_ble_cb_event_t event, esp_ble_gap_cb_param_t *param);
void ble_fd_scan(void);
int ble_fd_connect(const char *mac);
void ble_fd_drop(void);
int ble_fd_json(char *out, int cap);
int ble_fd_linked(void);
