#include "settings.h"
#include <string.h>
#include <stdio.h>
#include "nvs.h"
#include "esp_log.h"
#include "config.h"

static const char *TAG = "SETTINGS";

esp_err_t settings_init(void)
{
    nvs_handle_t h;
    esp_err_t err = nvs_open(CUBE_NVS_NAMESPACE, NVS_READWRITE, &h);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "NVS namespace '%s' open failed: %s", CUBE_NVS_NAMESPACE, esp_err_to_name(err));
        return err;
    }

    size_t len = 0;
    uint8_t role = 0;
    err = nvs_get_u8(h, "ble_role", &role);
    if (err == ESP_ERR_NVS_NOT_FOUND) role = 0;
    if (role == 1) {
        err = nvs_set_str(h, CUBE_NVS_BLE_NAME, "Xiaoxiang BMS");
        if (err == ESP_OK) err = nvs_commit(h);
        if (err == ESP_OK) ESP_LOGW(TAG, "BLE name is Xiaoxiang BMS");
        nvs_close(h);
        return err;
    }
    err = nvs_get_str(h, CUBE_NVS_BLE_NAME, NULL, &len);
    if (err == ESP_ERR_NVS_NOT_FOUND) {
        err = nvs_set_str(h, CUBE_NVS_BLE_NAME, CUBE_BLE_NAME);
        if (err == ESP_OK) err = nvs_commit(h);
        if (err == ESP_OK) ESP_LOGI(TAG, "Created default BLE name '%s' in %s", CUBE_BLE_NAME, CUBE_NVS_NAMESPACE);
    } else if (err == ESP_OK) {
        char cur[32];
        size_t n = sizeof(cur);
        if (nvs_get_str(h, CUBE_NVS_BLE_NAME, cur, &n) == ESP_OK &&
            strcmp(cur, CUBE_BLE_NAME) != 0) {
            err = nvs_set_str(h, CUBE_NVS_BLE_NAME, CUBE_BLE_NAME);
            if (err == ESP_OK) err = nvs_commit(h);
            if (err == ESP_OK) ESP_LOGW(TAG, "BLE name forced to '%s' (was '%s')", CUBE_BLE_NAME, cur);
        }
    } else if (err == ESP_ERR_NVS_INVALID_LENGTH) {
        err = ESP_OK;
    }
    nvs_close(h);
    if (err == ESP_OK) ESP_LOGI(TAG, "NVS namespace '%s' ready", CUBE_NVS_NAMESPACE);
    return err;
}

esp_err_t settings_get_ble_name(char *out, size_t out_size)
{
    if (!out || out_size < 2U) return ESP_ERR_INVALID_ARG;
    nvs_handle_t h;
    esp_err_t err = nvs_open(CUBE_NVS_NAMESPACE, NVS_READONLY, &h);
    if (err != ESP_OK) return err;
    size_t len = out_size;
    err = nvs_get_str(h, CUBE_NVS_BLE_NAME, out, &len);
    nvs_close(h);
    if (err == ESP_ERR_NVS_NOT_FOUND) {
        (void)snprintf(out, out_size, "%s", CUBE_BLE_NAME);
        return ESP_OK;
    }
    if (err == ESP_OK && out[0] == '\0') {
        (void)snprintf(out, out_size, "%s", CUBE_BLE_NAME);
    }
    return err;
}

esp_err_t settings_set_ble_name(const char *name)
{
    if (!name || !name[0] || strlen(name) >= 32U) return ESP_ERR_INVALID_ARG;
    nvs_handle_t h;
    esp_err_t err = nvs_open(CUBE_NVS_NAMESPACE, NVS_READWRITE, &h);
    if (err != ESP_OK) return err;
    err = nvs_set_str(h, CUBE_NVS_BLE_NAME, name);
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    return err;
}

static int nvs_u8(const char *key, int fallback, int maxv)
{
    nvs_handle_t h;
    uint8_t v = 0;
    if (nvs_open(CUBE_NVS_NAMESPACE, NVS_READONLY, &h) != ESP_OK) return fallback;
    if (nvs_get_u8(h, key, &v) != ESP_OK) v = (uint8_t)fallback;
    nvs_close(h);
    if ((int)v > maxv) return fallback;
    return (int)v;
}

static esp_err_t nvs_set_u8_key(const char *key, int value)
{
    nvs_handle_t h;
    esp_err_t err = nvs_open(CUBE_NVS_NAMESPACE, NVS_READWRITE, &h);
    if (err != ESP_OK) return err;
    err = nvs_set_u8(h, key, (uint8_t)value);
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    return err;
}

int settings_get_ble_role(void)
{
    return nvs_u8("ble_role", 0, 1);
}

esp_err_t settings_set_ble_role(int role)
{
    return nvs_set_u8_key("ble_role", role ? 1 : 0);
}

int settings_get_bms_pack(void)
{
    return nvs_u8("bms_pack", 0, 1);
}

esp_err_t settings_set_bms_pack(int pack)
{
    return nvs_set_u8_key("bms_pack", pack ? 1 : 0);
}
