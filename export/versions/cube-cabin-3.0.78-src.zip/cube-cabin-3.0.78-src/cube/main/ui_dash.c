#include "ui_dash.h"

#include "app_state.h"
#include "ble.h"
#include "ble_fd.h"
#include "can_gbt.h"
#include "config.h"
#include "bms_uart.h"
#include "display.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "fardriver_uart.h"
#include "settings.h"
#include "sm_relay.h"
#include "touch_cst816s.h"
#include "web.h"
#include "cabin.h"
#include "nvs.h"
#include <stdio.h>
#include <string.h>

extern const lv_font_t lv_font_ru_14;
extern const lv_font_t lv_font_montserrat_28;

static lv_obj_t *s_page[5];
static lv_obj_t *s_nav[5];
static lv_obj_t *s_time;
static lv_obj_t *s_relay;
static lv_obj_t *s_proto;
static lv_obj_t *s_can_line;
static lv_obj_t *s_req_v;
static lv_obj_t *s_req_a;
static lv_obj_t *s_watt;
static lv_obj_t *s_out_v;
static lv_obj_t *s_out_a;
static int s_pack;
static lv_obj_t *s_bms_tab[2];
static lv_obj_t *s_bms_info;
static lv_obj_t *s_bms_lim;
static lv_obj_t *s_cell_box[24];
static lv_obj_t *s_cell_lbl[24];
static lv_obj_t *s_fd_link;
static lv_obj_t *s_fd_i;
static lv_obj_t *s_fd_imax;
static lv_obj_t *s_fd_v;
static lv_obj_t *s_fd_err;
static lv_obj_t *s_fd_rpm;
static lv_obj_t *s_fd_kmh;
static lv_obj_t *s_direct_lbl;
static lv_obj_t *s_poles_lbl;
static lv_obj_t *s_wheel_lbl;
static lv_obj_t *s_msg;
static lv_obj_t *s_ssid;
static lv_obj_t *s_ap_pass;
static lv_obj_t *s_sta_pass;
static lv_obj_t *s_net[4];
static int s_net_i = -1;
static lv_obj_t *s_kb;
static lv_obj_t *s_touch_lbl;
static lv_obj_t *s_turn;
static lv_obj_t *s_diam_lbl;
static lv_obj_t *s_cabin;
static int s_ap_filled;

static lv_obj_t *caption(lv_obj_t *p, const char *t, int y)
{
    lv_obj_t *l = lv_label_create(p);
    lv_label_set_text(l, t);
    lv_obj_set_style_text_font(l, &lv_font_ru_14, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(0xF6E7C1), 0);
    lv_obj_set_pos(l, 6, y);
    lv_obj_set_width(l, 228);
    lv_label_set_long_mode(l, LV_LABEL_LONG_WRAP);
    return l;
}

static lv_obj_t *btn(lv_obj_t *p, int x, int y, int w, int h, const char *t, lv_event_cb_t cb, void *ud)
{
    lv_obj_t *b = lv_btn_create(p);
    lv_obj_t *l;
    lv_obj_set_pos(b, x, y);
    lv_obj_set_size(b, w, h);
    lv_obj_set_style_bg_color(b, lv_color_hex(0x1A140C), 0);
    lv_obj_set_style_radius(b, 10, 0);
    lv_obj_set_style_border_width(b, 1, 0);
    lv_obj_set_style_border_color(b, lv_color_hex(0xE8A317), 0);
    lv_obj_set_style_shadow_width(b, 0, 0);
    lv_obj_set_style_pad_all(b, 2, 0);
    if (cb) lv_obj_add_event_cb(b, cb, LV_EVENT_CLICKED, ud);
    l = lv_label_create(b);
    lv_label_set_text(l, t);
    lv_obj_set_style_text_font(l, &lv_font_ru_14, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(0xF6E7C1), 0);
    lv_obj_center(l);
    return b;
}

static void show_page(int n)
{
    int i;
    if (n < 0) n = 0;
    if (n > 4) n = 4;
    for (i = 0; i < 5; ++i) {
        if (!s_page[i] || !s_nav[i]) continue;
        if (i == n) lv_obj_clear_flag(s_page[i], LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(s_page[i], LV_OBJ_FLAG_HIDDEN);
        lv_obj_set_style_bg_color(s_nav[i], lv_color_hex(i == n ? 0xE8A317 : 0x12151C), 0);
        lv_obj_set_style_border_color(s_nav[i], lv_color_hex(i == n ? 0xE8A317 : 0x3A2E1A), 0);
        if (lv_obj_get_child_cnt(s_nav[i]) > 0) {
            lv_obj_set_style_text_color(lv_obj_get_child(s_nav[i], 0),
                                        lv_color_hex(i == n ? 0x1A1408 : 0xF6E7C1), 0);
        }
    }
    if (s_kb) lv_obj_add_flag(s_kb, LV_OBJ_FLAG_HIDDEN);
}

static int s_cycle = 1;
static int s_dwell = 5;
static int s_cur;
static int64_t s_turn_us;

static void scr_save(void)
{
    nvs_handle_t h;
    if (nvs_open("storage", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u8(h, "scr_cyc", (uint8_t)(s_cycle ? 1 : 0));
    nvs_set_u8(h, "scr_dwell", (uint8_t)s_dwell);
    nvs_set_u8(h, "scr_page", (uint8_t)s_cur);
    nvs_commit(h);
    nvs_close(h);
}

void ui_dash_load(void)
{
    nvs_handle_t h;
    uint8_t v = 0;
    if (nvs_open("storage", NVS_READONLY, &h) == ESP_OK) {
        if (nvs_get_u8(h, "scr_cyc", &v) == ESP_OK) s_cycle = v ? 1 : 0;
        if (nvs_get_u8(h, "scr_dwell", &v) == ESP_OK && v >= 2 && v <= 60) s_dwell = (int)v;
        if (nvs_get_u8(h, "scr_page", &v) == ESP_OK && v < 5) s_cur = (int)v;
        nvs_close(h);
    }
    s_turn_us = esp_timer_get_time();
    show_page(s_cur);
}

void ui_dash_set_cycle(int on)
{
    s_cycle = on ? 1 : 0;
    s_turn_us = esp_timer_get_time();
    scr_save();
}

void ui_dash_set_dwell(int sec)
{
    if (sec < 2) sec = 2;
    if (sec > 60) sec = 60;
    s_dwell = sec;
    scr_save();
}

void ui_dash_set_page(int n)
{
    bool locked;
    if (n < 0) n = 0;
    if (n > 4) n = 4;
    s_cur = n;
    s_cycle = 0;
    s_turn_us = esp_timer_get_time();
    locked = display_lock();
    show_page(n);
    if (locked) display_unlock();
    scr_save();
}

int ui_dash_get_cycle(void) { return s_cycle; }
int ui_dash_get_dwell(void) { return s_dwell; }
int ui_dash_get_page(void) { return s_cur; }

static void nav_cb(lv_event_t *e)
{
    ui_dash_set_page((int)(intptr_t)lv_event_get_user_data(e));
}

static void relay_cb(lv_event_t *e)
{
    (void)e;
    sm_request_relay_test();
}

static void key_cb(lv_event_t *e)
{
    display_open_keypad((int)(intptr_t)lv_event_get_user_data(e));
}

static void pack_cb(lv_event_t *e)
{
    s_pack = (int)(intptr_t)lv_event_get_user_data(e);
    if (s_pack < 0) s_pack = 0;
    if (s_pack > 1) s_pack = 1;
}

static void proto_cb(lv_event_t *e)
{
    app_state_set_protocol((uint8_t)(intptr_t)lv_event_get_user_data(e));
}

static void note(const char *t)
{
    if (s_msg) lv_label_set_text(s_msg, t);
}

static void act_cb(lv_event_t *e)
{
    int id = (int)(intptr_t)lv_event_get_user_data(e);
    if (id == 1) {
        note(web_wifi_restart() == ESP_OK ? "Wi-Fi перезапущен" : "Wi-Fi не поднялся");
    } else if (id == 2) {
        note(cube_ble_rearm() == ESP_OK ? "BLE снова в эфире" : "BLE не перезапустился");
    } else if (id == 3) {
        note("перезагрузка");
        esp_restart();
    } else if (id == 4) {
        const char *ssid = s_ssid ? lv_textarea_get_text(s_ssid) : "";
        const char *pass = s_ap_pass ? lv_textarea_get_text(s_ap_pass) : "";
        note(web_set_ap(ssid, pass) == ESP_OK ? "точка сохранена" : "имя 1-32, пароль от 8");
    } else if (id == 5) {
        int n;
        int i;
        if (web_scan_now() != ESP_OK) {
            note("скан не удался");
            return;
        }
        n = web_scan_count();
        s_net_i = -1;
        for (i = 0; i < 4; ++i) {
            if (!s_net[i]) continue;
            if (i < n && web_scan_ssid(i)[0]) {
                lv_obj_t *l = lv_obj_get_child(s_net[i], 0);
                if (l) lv_label_set_text(l, web_scan_ssid(i));
                lv_obj_clear_flag(s_net[i], LV_OBJ_FLAG_HIDDEN);
            } else {
                lv_obj_add_flag(s_net[i], LV_OBJ_FLAG_HIDDEN);
            }
        }
        note(n ? "сеть выбрана кнопкой" : "сетей нет");
    } else if (id == 6) {
        const char *pass = s_sta_pass ? lv_textarea_get_text(s_sta_pass) : "";
        const char *ssid;
        if (s_net_i < 0 || s_net_i >= web_scan_count()) {
            note("сначала выбери сеть");
            return;
        }
        ssid = web_scan_ssid(s_net_i);
        note(web_sta_join(ssid, pass) == ESP_OK ? "подключаюсь" : "не подключился");
    } else if (id == 7) {
        sm_stop_session();
        note("сессия остановлена");
    } else if (id == 8 || id == 9) {
        int t = fardriver_diameter_tenths();
        t += (id == 8) ? -1 : 1;
        fardriver_set_diameter_tenths(t);
    } else if (id == 10 || id == 11) {
        int p = fardriver_poles();
        p += (id == 10) ? -1 : 1;
        fardriver_set_poles(p);
    } else if (id == 30) {
        if (settings_get_ble_role() != 0) {
            (void)settings_set_ble_role(0);
            note("перезапуск, мост CONTROLDM");
            vTaskDelay(pdMS_TO_TICKS(200));
            esp_restart();
        } else {
            note("уже мост CONTROLDM");
        }
    } else if (id == 32) {
        note("AT модуль — кнопка в приложении");
    } else if (id == 31) {
        (void)settings_set_ble_role(1);
        note("перезапуск, BLE BMS");
        vTaskDelay(pdMS_TO_TICKS(200));
        esp_restart();
    } else if (id == 40) {
        cabin_toggle_heat();
    } else if (id == 41) {
        cabin_cycle_light();
    } else if (id == 42) {
        cabin_bump_comfort(-1);
    } else if (id == 43) {
        cabin_bump_comfort(1);
    } else if (id == 44) {
        display_turn_90();
    }
}

static void net_cb(lv_event_t *e)
{
    s_net_i = (int)(intptr_t)lv_event_get_user_data(e);
    note(web_scan_ssid(s_net_i));
}

static void kb_hide_cb(lv_event_t *e)
{
    lv_event_code_t c = lv_event_get_code(e);
    if ((c == LV_EVENT_READY || c == LV_EVENT_CANCEL) && s_kb)
        lv_obj_add_flag(s_kb, LV_OBJ_FLAG_HIDDEN);
}

static void ta_cb(lv_event_t *e)
{
    if (!s_kb) return;
    lv_keyboard_set_textarea(s_kb, lv_event_get_target(e));
    lv_obj_clear_flag(s_kb, LV_OBJ_FLAG_HIDDEN);
    lv_obj_move_foreground(s_kb);
}

static void wire_cb(lv_event_t *e)
{
    gbt_can_wire_test();
    (void)e;
    if (s_can_line) lv_label_set_text(s_can_line, gbt_can_wire_result());
}

static void bus_cb(lv_event_t *e)
{
    (void)e;
    gbt_can_bus_test();
    if (s_can_line) lv_label_set_text(s_can_line, gbt_can_wire_result());
}

static void br_cb(lv_event_t *e)
{
    display_set_brightness(lv_slider_get_value(lv_event_get_target(e)));
}

static void gate_cb(lv_event_t *e)
{
    int z = lv_slider_get_value(lv_event_get_target(e));
    char b[40];
    touch_set_gate(z);
    if (s_touch_lbl) {
        snprintf(b, sizeof(b), "порог нажатия %d", z);
        lv_label_set_text(s_touch_lbl, b);
    }
}

static lv_obj_t *tile(lv_obj_t *p, int x, int y, int w, int h, uint32_t bg, uint32_t fg, const char *cap, lv_obj_t **value, const char *init, const lv_font_t *font)
{
    lv_obj_t *c = lv_obj_create(p);
    lv_obj_t *v;
    lv_obj_t *k;
    lv_obj_set_pos(c, x, y);
    lv_obj_set_size(c, w, h);
    lv_obj_set_style_bg_color(c, lv_color_hex(bg), 0);
    lv_obj_set_style_bg_opa(c, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(c, 8, 0);
    lv_obj_set_style_border_width(c, 1, 0);
    lv_obj_set_style_border_color(c, lv_color_hex(bg == 0xE8A317 ? 0xE8A317 : 0x3A2E1A), 0);
    lv_obj_set_style_pad_all(c, 0, 0);
    lv_obj_clear_flag(c, LV_OBJ_FLAG_SCROLLABLE);
    v = lv_label_create(c);
    lv_label_set_text(v, init);
    lv_obj_set_style_text_font(v, font, 0);
    lv_obj_set_style_text_color(v, lv_color_hex(fg), 0);
    lv_obj_align(v, LV_ALIGN_CENTER, 0, -8);
    lv_obj_add_flag(v, LV_OBJ_FLAG_EVENT_BUBBLE);
    k = lv_label_create(c);
    lv_label_set_text(k, cap);
    lv_obj_set_style_text_font(k, &lv_font_ru_14, 0);
    lv_obj_set_style_text_color(k, lv_color_hex(bg == 0xE8A317 ? 0x1A1408 : 0xE8A317), 0);
    lv_obj_align(k, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_obj_add_flag(k, LV_OBJ_FLAG_EVENT_BUBBLE);
    if (value) *value = v;
    return c;
}

static lv_obj_t *field(lv_obj_t *p, int x, int y, int w, const char *init)
{
    lv_obj_t *t = lv_textarea_create(p);
    lv_obj_set_pos(t, x, y);
    lv_obj_set_size(t, w, 32);
    lv_textarea_set_one_line(t, true);
    lv_textarea_set_text(t, init);
    lv_obj_set_style_bg_color(t, lv_color_hex(0x12151C), 0);
    lv_obj_set_style_text_color(t, lv_color_hex(0xF6E7C1), 0);
    lv_obj_set_style_border_color(t, lv_color_hex(0xE8A317), 0);
    lv_obj_set_style_text_font(t, &lv_font_ru_14, 0);
    lv_obj_add_event_cb(t, ta_cb, LV_EVENT_FOCUSED, NULL);
    return t;
}

static void page_bg(lv_obj_t *p)
{
    lv_obj_set_style_bg_opa(p, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(p, 0, 0);
    lv_obj_set_style_pad_all(p, 0, 0);
    lv_obj_clear_flag(p, LV_OBJ_FLAG_SCROLLABLE);
}

void ui_dash_fit(void)
{
    lv_disp_t *d = lv_disp_get_default();
    lv_coord_t hor;
    lv_coord_t ver;
    lv_coord_t nav_h = 34;
    lv_coord_t bw;
    int i;
    char b[20];
    if (!d || !s_page[0] || !s_nav[0]) return;
    hor = lv_disp_get_hor_res(d);
    ver = lv_disp_get_ver_res(d);
    if (hor < 80 || ver < 80) return;
    bw = (hor - 8) / 5;
    if (bw < 36) bw = 36;
    for (i = 0; i < 5; ++i) {
        lv_obj_set_pos(s_page[i], 0, 0);
        lv_obj_set_size(s_page[i], hor, ver - nav_h);
        lv_obj_add_flag(s_page[i], LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_scroll_dir(s_page[i], LV_DIR_VER);
        lv_obj_set_pos(s_nav[i], 2 + i * bw, ver - nav_h + 1);
        lv_obj_set_size(s_nav[i], bw - 2, nav_h - 2);
    }
    if (s_turn && lv_obj_get_child_cnt(s_turn) > 0) {
        snprintf(b, sizeof(b), "экран %d", display_get_rot());
        lv_label_set_text(lv_obj_get_child(s_turn, 0), b);
    }
}

void ui_dash_build(lv_obj_t *scr)
{
    int i;
    lv_obj_t *c;
    const char *nav[] = {"СТАН", "АКБ", "МОТ", "КУБ", "ОТЛ"};

    lv_obj_set_style_bg_color(scr, lv_color_hex(0x07090E), 0);
    lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, 0);

    for (i = 0; i < 5; ++i) {
        s_page[i] = lv_obj_create(scr);
        lv_obj_set_pos(s_page[i], 0, 0);
        lv_obj_set_size(s_page[i], 240, 284);
        page_bg(s_page[i]);
    }
    lv_obj_add_flag(s_page[1], LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_scroll_dir(s_page[1], LV_DIR_VER);
    lv_obj_add_flag(s_page[2], LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_scroll_dir(s_page[2], LV_DIR_VER);
    lv_obj_add_flag(s_page[3], LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_scroll_dir(s_page[3], LV_DIR_VER);
    lv_obj_add_flag(s_page[4], LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_scroll_dir(s_page[4], LV_DIR_VER);

    c = tile(s_page[0], 4, 4, 114, 108, 0x12151C, 0xF7F1E4, "выход В", &s_out_v, "0", &lv_font_montserrat_28);
    (void)c;
    c = tile(s_page[0], 122, 4, 114, 108, 0x12151C, 0xF7F1E4, "выход А", &s_out_a, "0", &lv_font_montserrat_28);
    (void)c;
    c = tile(s_page[0], 4, 116, 76, 52, 0x12151C, 0xF7F1E4, "время", &s_time, "00:00", &lv_font_ru_14);
    (void)c;
    c = tile(s_page[0], 82, 116, 76, 52, 0xE8A317, 0x1A1408, "протокол", &s_proto, "авто", &lv_font_ru_14);
    (void)c;
    c = tile(s_page[0], 160, 116, 76, 52, 0x12151C, 0xF7F1E4, "ватт", &s_watt, "0", &lv_font_ru_14);
    (void)c;
    c = tile(s_page[0], 4, 172, 76, 48, 0xE8A317, 0x1A1408, "запрос В", &s_req_v, "240", &lv_font_ru_14);
    lv_obj_add_flag(c, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(c, key_cb, LV_EVENT_CLICKED, (void *)(intptr_t)3);
    c = tile(s_page[0], 82, 172, 76, 48, 0xE8A317, 0x1A1408, "запрос А", &s_req_a, "50", &lv_font_ru_14);
    lv_obj_add_flag(c, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(c, key_cb, LV_EVENT_CLICKED, (void *)(intptr_t)4);
    c = tile(s_page[0], 160, 172, 76, 48, 0x12151C, 0xF7F1E4, "реле", &s_relay, "OFF", &lv_font_ru_14);
    lv_obj_add_flag(c, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(c, relay_cb, LV_EVENT_CLICKED, NULL);
    s_can_line = caption(s_page[0], "CAN: нажми проверку", 222);
    lv_label_set_long_mode(s_can_line, LV_LABEL_LONG_DOT);
    btn(s_page[0], 4, 246, 114, 34, "до модуля", wire_cb, NULL);
    btn(s_page[0], 122, 246, 114, 34, "кабель CAN", bus_cb, NULL);

    s_bms_tab[0] = btn(s_page[1], 6, 4, 140, 28, "АКБ", pack_cb, (void *)(intptr_t)0);
    s_bms_tab[1] = NULL;
    s_bms_info = caption(s_page[1], "нет связи", 36);
    lv_label_set_long_mode(s_bms_info, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(s_bms_info, 228);
    for (i = 0; i < 24; ++i) {
        int x = 4 + (i % 6) * 39;
        int y = 210 + (i / 6) * 36;
        lv_obj_t *l;
        s_cell_box[i] = lv_obj_create(s_page[1]);
        lv_obj_set_pos(s_cell_box[i], x, y);
        lv_obj_set_size(s_cell_box[i], 37, 34);
        lv_obj_set_style_bg_color(s_cell_box[i], lv_color_hex(0x12151C), 0);
        lv_obj_set_style_bg_opa(s_cell_box[i], LV_OPA_COVER, 0);
        lv_obj_set_style_radius(s_cell_box[i], 4, 0);
        lv_obj_set_style_border_width(s_cell_box[i], 0, 0);
        lv_obj_set_style_pad_all(s_cell_box[i], 0, 0);
        lv_obj_clear_flag(s_cell_box[i], LV_OBJ_FLAG_SCROLLABLE);
        l = lv_label_create(s_cell_box[i]);
        lv_label_set_text(l, "--");
        lv_obj_set_style_text_font(l, &lv_font_ru_14, 0);
        lv_obj_set_style_text_color(l, lv_color_hex(0xF6E7C1), 0);
        lv_obj_center(l);
        s_cell_lbl[i] = l;
    }
    s_bms_lim = caption(s_page[1], "пороги читаю с BMS", 360);
    lv_label_set_long_mode(s_bms_lim, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(s_bms_lim, 228);

    tile(s_page[2], 4, 4, 232, 86, 0x12151C, 0xF7F1E4, "скорость км/ч", &s_fd_kmh, "0.0", &lv_font_montserrat_28);
    s_fd_link = caption(s_page[2], "нет связи", 90);
    s_fd_i = caption(s_page[2], "ток 0.0 А", 112);
    s_fd_imax = caption(s_page[2], "макс ток сессии 0.0 А", 134);
    s_fd_v = caption(s_page[2], "напряжение 0.0 В", 156);
    s_fd_rpm = caption(s_page[2], "обороты колеса 0", 178);
    lv_obj_set_width(s_fd_rpm, 228);
    s_fd_err = caption(s_page[2], "ошибки нет", 222);
    lv_label_set_long_mode(s_fd_err, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(s_fd_err, 228);
    caption(s_page[2], "пары полюсов", 268);
    s_poles_lbl = caption(s_page[2], "пары полюсов 20", 310);
    btn(s_page[2], 6, 332, 54, 28, "-", act_cb, (void *)(intptr_t)10);
    btn(s_page[2], 64, 332, 54, 28, "+", act_cb, (void *)(intptr_t)11);
    s_wheel_lbl = caption(s_page[2], "колесо 16.3", 368);
    btn(s_page[2], 6, 390, 54, 28, "-", act_cb, (void *)(intptr_t)8);
    btn(s_page[2], 64, 390, 54, 28, "+", act_cb, (void *)(intptr_t)9);

    caption(s_page[3], "яркость", 4);
    {
        lv_obj_t *sl = lv_slider_create(s_page[3]);
        lv_obj_set_pos(sl, 8, 24);
        lv_obj_set_width(sl, 220);
        lv_slider_set_range(sl, 5, 100);
        lv_slider_set_value(sl, display_get_brightness(), LV_ANIM_OFF);
        lv_obj_add_event_cb(sl, br_cb, LV_EVENT_VALUE_CHANGED, NULL);
    }
    s_touch_lbl = caption(s_page[3], "порог нажатия 80", 48);
    {
        lv_obj_t *sl = lv_slider_create(s_page[3]);
        lv_obj_set_pos(sl, 8, 70);
        lv_obj_set_width(sl, 220);
        lv_slider_set_range(sl, 40, 400);
        lv_slider_set_value(sl, touch_get_gate(), LV_ANIM_OFF);
        lv_obj_add_event_cb(sl, gate_cb, LV_EVENT_VALUE_CHANGED, NULL);
    }
    btn(s_page[3], 6, 118, 110, 28, "Wi-Fi заново", act_cb, (void *)(intptr_t)1);
    btn(s_page[3], 122, 118, 110, 28, "BLE заново", act_cb, (void *)(intptr_t)2);
    btn(s_page[3], 6, 150, 110, 28, "куб заново", act_cb, (void *)(intptr_t)3);
    btn(s_page[3], 122, 150, 110, 28, "стоп сессии", act_cb, (void *)(intptr_t)7);
    caption(s_page[3], "имя точки", 186);
    s_ssid = field(s_page[3], 8, 206, 220, "Cube");
    caption(s_page[3], "пароль точки, от 8 цифр или букв", 242);
    s_ap_pass = field(s_page[3], 8, 262, 220, "12345678");
    btn(s_page[3], 6, 300, 220, 28, "сохранить точку", act_cb, (void *)(intptr_t)4);
    caption(s_page[3], "домашняя сеть", 336);
    btn(s_page[3], 6, 356, 100, 28, "скан", act_cb, (void *)(intptr_t)5);
    btn(s_page[3], 112, 356, 114, 28, "подключить", act_cb, (void *)(intptr_t)6);
    for (i = 0; i < 4; ++i) {
        s_net[i] = btn(s_page[3], 6, 390 + i * 32, 220, 28, "—", net_cb, (void *)(intptr_t)i);
        lv_obj_add_flag(s_net[i], LV_OBJ_FLAG_HIDDEN);
    }
    s_sta_pass = field(s_page[3], 8, 522, 220, "");
    caption(s_page[3], "пароль домашней сети над этой строкой", 556);
    caption(s_page[3], "15/A = 2015 и 2023-A, один провод", 580);
    btn(s_page[3], 6, 600, 54, 28, "авто", proto_cb, (void *)(intptr_t)0);
    btn(s_page[3], 64, 600, 54, 28, "15/A", proto_cb, (void *)(intptr_t)1);
    btn(s_page[3], 122, 600, 54, 28, "2011", proto_cb, (void *)(intptr_t)2);
    btn(s_page[3], 180, 600, 54, 28, "23B", proto_cb, (void *)(intptr_t)3);
    s_diam_lbl = caption(s_page[3], "колесо 16.3", 636);
    btn(s_page[3], 6, 658, 54, 28, "-", act_cb, (void *)(intptr_t)8);
    btn(s_page[3], 64, 658, 54, 28, "+", act_cb, (void *)(intptr_t)9);
    s_msg = caption(s_page[3], "", 696);
    lv_label_set_long_mode(s_msg, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(s_msg, 228);
    lv_obj_set_height(s_page[3], 284);

    s_cabin = caption(s_page[4], "кабина", 6);
    lv_label_set_long_mode(s_cabin, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(s_cabin, 228);
    btn(s_page[4], 6, 78, 110, 36, "подогрев", act_cb, (void *)(intptr_t)40);
    btn(s_page[4], 122, 78, 110, 36, "фара", act_cb, (void *)(intptr_t)41);
    btn(s_page[4], 6, 120, 54, 36, "-", act_cb, (void *)(intptr_t)42);
    btn(s_page[4], 64, 120, 54, 36, "+", act_cb, (void *)(intptr_t)43);
    caption(s_page[4], "комфорт 0…120", 164);
    btn(s_page[4], 6, 188, 228, 34, "мост фары", act_cb, (void *)(intptr_t)30);
    btn(s_page[4], 6, 226, 228, 34, "AT модуль", act_cb, (void *)(intptr_t)32);
    btn(s_page[4], 6, 264, 228, 34, "телефон на АКБ", act_cb, (void *)(intptr_t)31);
    s_turn = btn(s_page[4], 6, 304, 228, 34, "экран +90", act_cb, (void *)(intptr_t)44);

    for (i = 0; i < 5; ++i) {
        s_nav[i] = btn(scr, 2 + i * 47, 286, 46, 32, nav[i], nav_cb, (void *)(intptr_t)i);
    }
    s_kb = lv_keyboard_create(scr);
    lv_obj_set_size(s_kb, 240, 140);
    lv_obj_align(s_kb, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_obj_add_event_cb(s_kb, kb_hide_cb, LV_EVENT_READY, NULL);
    lv_obj_add_event_cb(s_kb, kb_hide_cb, LV_EVENT_CANCEL, NULL);
    lv_obj_add_flag(s_kb, LV_OBJ_FLAG_HIDDEN);
    show_page(0);
    ui_dash_fit();
    ui_dash_load();
}

static const char *proto_name(uint8_t p)
{
    if (p == 1) return "2015/A";
    if (p == 2) return "2011";
    if (p == 3) return "2023-B";
    return "авто";
}

static void bal_line(const bms_link_t *L, char *out, size_t cap)
{
    size_t n = 0;
    int i;
    int any = 0;
    int lim = L->ncell > 0 ? L->ncell : 24;
    if (lim > 32) lim = 32;
    n = (size_t)snprintf(out, cap, "балансир включен:");
    for (i = 0; i < lim && n + 4 < cap; ++i) {
        if ((L->balance & (1u << i)) == 0) continue;
        any = 1;
        n += (size_t)snprintf(out + n, cap - n, " %d", i + 1);
    }
    if (!any) snprintf(out, cap, "балансир выключен");
}

static void amps_line(char *out, size_t cap, int ma)
{
    int neg = ma < 0;
    int a = neg ? -ma : ma;
    snprintf(out, cap, "%s%d.%02d", neg ? "-" : "+", a / 1000, (a / 10) % 100);
}

static void paint_pack(const bms_link_t *L)
{
    char b[480];
    char ia[16];
    char ip[16];
    char bal[96];
    int i;
    int n;
    if (!s_bms_info) return;
    if (s_bms_tab[0]) {
        lv_obj_set_style_bg_color(s_bms_tab[0], lv_color_hex(0xE8A317), 0);
        if (lv_obj_get_child_cnt(s_bms_tab[0]) > 0)
            lv_obj_set_style_text_color(lv_obj_get_child(s_bms_tab[0], 0), lv_color_hex(0x1A1408), 0);
    }
    if (s_bms_tab[1]) lv_obj_set_style_bg_color(s_bms_tab[1], lv_color_hex(s_pack == 1 ? 0x1F6F5B : 0x24485C), 0);
    if (!L->ok) {
        snprintf(b, sizeof(b), "нет связи");
        bal[0] = 0;
    } else {
        int dlt = (L->ncell > 0) ? (L->cell_max_mv - L->cell_min_mv) : 0;
        amps_line(ia, sizeof(ia), L->ma);
        amps_line(ip, sizeof(ip), L->peak_ma);
        bal_line(L, bal, sizeof(bal));
        snprintf(b, sizeof(b),
                 "%d%%  %d / %d Вт·ч\nосталось %d.%02d А·ч\nток %s А   пик %s А\n%d.%02d В   разброс %d мВ\n%s\nключ заряда %s, ключ разряда %s",
                 L->soc < 0 ? 0 : L->soc, bms_remain_wh(), bms_full_wh(),
                 L->remain_mah / 1000, (L->remain_mah / 10) % 100,
                 ia, ip,
                 L->mv / 1000, (L->mv / 10) % 100,
                 dlt,
                 bal,
                 (L->fet & 1) ? "вкл" : "выкл",
                 (L->fet & 2) ? "вкл" : "выкл");
    }
    lv_label_set_text(s_bms_info, b);
    if (s_bms_lim) {
        if (!L->ok) {
            lv_label_set_text(s_bms_lim, "нет связи, пороги не прочитать");
        } else if (L->regs_ok > 0 && L->chg >= 0) {
            snprintf(b, sizeof(b),
                     "с платы, амперы\nзаряд %d А\nразряд %d А\nправка в приложении",
                     L->chg, L->dsg < 0 ? 0 : L->dsg);
            lv_label_set_text(s_bms_lim, b);
        } else if (!L->cfg_ok || L->chg < 0) {
            lv_label_set_text(s_bms_lim, "пороги с BMS ещё не прочитаны\nправка в приложении");
        } else {
            snprintf(b, sizeof(b),
                     "с BMS, амперы\nзаряд %d, пауза %d с\nразряд %d, пауза %d с\nкороткое %d, пауза %d\nправка в приложении",
                     L->chg, L->chgd < 0 ? 0 : L->chgd, L->dsg < 0 ? 0 : L->dsg,
                     L->dsgd < 0 ? 0 : L->dsgd, L->sc < 0 ? 0 : L->sc, L->scd < 0 ? 0 : L->scd);
            lv_label_set_text(s_bms_lim, b);
        }
    }
    n = L->ncell;
    if (n > 24) n = 24;
    for (i = 0; i < 24; ++i) {
        int low;
        int on;
        if (!s_cell_lbl[i] || !s_cell_box[i]) continue;
        if (!L->ok || i >= n || L->cells[i] <= 0) {
            lv_label_set_text(s_cell_lbl[i], "--");
            lv_obj_set_style_bg_color(s_cell_box[i], lv_color_hex(0x12151C), 0);
            lv_obj_set_style_border_width(s_cell_box[i], 0, 0);
            continue;
        }
        snprintf(b, sizeof(b), "%d.%02d", L->cells[i] / 1000, (L->cells[i] / 10) % 100);
        lv_label_set_text(s_cell_lbl[i], b);
        on = (L->balance & (1u << i)) != 0;
        low = !on && L->ncell > 0 && (L->cell_max_mv - L->cell_min_mv) >= 20 && L->cells[i] <= L->cell_max_mv - 20;
        lv_obj_set_style_bg_color(s_cell_box[i], lv_color_hex(on ? 0x3A5A28 : (low ? 0x7A3030 : 0x12151C)), 0);
        lv_obj_set_style_border_width(s_cell_box[i], on ? 2 : 0, 0);
        lv_obj_set_style_border_color(s_cell_box[i], lv_color_hex(0xE8A317), 0);
        lv_obj_set_style_text_color(s_cell_lbl[i], lv_color_hex(0xF6E7C1), 0);
    }
}

void ui_dash_tick(void)
{
    cube_state_snapshot_t st;
    bms_link_t A, B;
    char b[64];
    uint32_t now;
    uint32_t sec;
    int rpm = 0;
    int kmh = 0;
    int link = 0;
    int max_rpm = 0;
    int amps_x10 = 0;
    int max_amps = 0;
    int volts_x10 = 0;
    int err_bits = 0;
    float uv;
    float ia;
    int live;

    app_state_snapshot(&st);
    gbt_can_probe_poll();
    now = (uint32_t)(esp_timer_get_time() / 1000ULL);
    if (st.session_active && now >= st.session_start_ms) sec = (now - st.session_start_ms) / 1000u;
    else sec = 0;
    if (s_time) {
        snprintf(b, sizeof(b), "%02u:%02u:%02u",
                 (unsigned)(sec / 3600u), (unsigned)((sec / 60u) % 60u), (unsigned)(sec % 60u));
        lv_label_set_text(s_time, b);
    }
    if (s_relay) {
        const char *r = "выкл";
        if (st.relay_a && !st.relay_b) r = "имит";
        else if (st.relay_b) r = "акб";
        lv_label_set_text(s_relay, r);
    }
    if (s_proto) lv_label_set_text(s_proto, proto_name(st.protocol));
    if (s_can_line) {
        const char *wire = gbt_can_wire_result();
        const char *m = "станция молчит";
        int talk = st.last_charger_rx_ms != 0 && (now - st.last_charger_rx_ms) < 1500u;
        if (wire[0]) m = wire;
        else if (st.main_state == ST_CHARGING) m = "идёт заряд";
        else if (st.main_state == ST_READY_WAIT_CRO) m = "ждём готовность станции";
        else if (st.main_state == ST_PARAM_CONFIG) m = "согласуем заряд";
        else if (st.crm_status == 0xAA && st.last_crm_ms != 0 && (now - st.last_crm_ms) < 5000u) m = "батарея узнана";
        else if (st.last_crm_ms != 0 && (now - st.last_crm_ms) < 5000u)
            m = st.relay_a ? "поиск, имитация вкл" : "станция ищет батарею";
        else if (talk && st.relay_a) m = "имитация включена";
        else if (talk && st.tx_count == 0) m = "кадр куба не принят";
        else if (talk) m = "куб отвечает станции";
        lv_label_set_text(s_can_line, m);
    }
    if (s_req_v) {
        int v = st.bcl_requested_voltage_raw / 10;
        if (v < 1) v = 240;
        snprintf(b, sizeof(b), "%d", v);
        lv_label_set_text(s_req_v, b);
    }
    if (s_req_a) {
        int a = st.bcl_requested_current_0p1a;
        if (a < 0) a = -a;
        a /= 10;
        if (a < 1) a = 50;
        snprintf(b, sizeof(b), "%d", a);
        lv_label_set_text(s_req_a, b);
    }
    live = st.ccs_output_voltage_raw > 0;
    uv = live ? st.ccs_output_voltage_raw / 10.0f : 0;
    ia = st.ccs_output_current_0p1a / 10.0f;
    if (ia < 0) ia = -ia;
    if (s_out_v) {
        snprintf(b, sizeof(b), "%.0f", (double)uv);
        lv_label_set_text(s_out_v, b);
    }
    if (s_out_a) {
        snprintf(b, sizeof(b), "%.0f", (double)ia);
        lv_label_set_text(s_out_a, b);
    }
    if (s_watt) {
        snprintf(b, sizeof(b), "%.0f", (double)(uv * ia));
        lv_label_set_text(s_watt, b);
    }

    bms_link_get(0, &A);
    bms_link_get(1, &B);
    paint_pack(s_pack ? &B : &A);

    fardriver_stats(&rpm, &kmh, &link, &max_rpm);
    fardriver_power(&amps_x10, &max_amps, &volts_x10, &err_bits);
    if (s_fd_kmh) {
        int phone = fardriver_direct() && cube_ble_is_connected();
        if (!link) lv_label_set_text(s_fd_kmh, phone ? "BLE" : "0.0");
        else {
            int show = kmh < 0 ? -kmh : kmh;
            snprintf(b, sizeof(b), "%d.%d", show / 10, show % 10);
            lv_label_set_text(s_fd_kmh, b);
        }
    }
    if (s_fd_link) {
        int phone = fardriver_direct() && cube_ble_is_connected();
        if (phone && link) {
            lv_label_set_text(s_fd_link, "мост, кадр есть");
        } else if (phone) {
            lv_label_set_text(s_fd_link, "мост CONTROLDM");
        } else if (link) {
            lv_label_set_text(s_fd_link, "кадр есть");
        } else if (fardriver_rx_bytes() > 0) {
            snprintf(b, sizeof(b), "линия есть, байт %d", fardriver_rx_bytes());
            lv_label_set_text(s_fd_link, b);
        } else {
            lv_label_set_text(s_fd_link, "нет связи");
        }
    }
    if (s_fd_i) {
        snprintf(b, sizeof(b), "ток %d.%d А", amps_x10 / 10, amps_x10 % 10);
        lv_label_set_text(s_fd_i, b);
    }
    if (s_fd_imax) {
        snprintf(b, sizeof(b), "макс ток сессии %d.%d А", max_amps / 10, max_amps % 10);
        lv_label_set_text(s_fd_imax, b);
    }
    if (s_fd_v) {
        snprintf(b, sizeof(b), "напряжение %d.%d В", volts_x10 / 10, volts_x10 % 10);
        lv_label_set_text(s_fd_v, b);
    }
    if (s_fd_rpm) {
        int listed = fardriver_listed_rpm();
        if (!link || fardriver_direct()) lv_label_set_text(s_fd_rpm, "обороты колеса 0\nсчётчик фарика 0");
        else {
            snprintf(b, sizeof(b), "обороты колеса %d\nсчётчик фарика %d", rpm, listed);
            lv_label_set_text(s_fd_rpm, b);
        }
    }
    if (s_fd_err) {
        if (!link || fardriver_direct() || err_bits == 0) lv_label_set_text(s_fd_err, "ошибки нет");
        else {
            snprintf(b, sizeof(b), "ошибка %04x", err_bits & 0xFFFF);
            lv_label_set_text(s_fd_err, b);
        }
    }
    if (s_direct_lbl) lv_label_set_text(s_direct_lbl, fardriver_direct() ? "мост включен" : "мост выключен");
    if (s_diam_lbl) {
        int t = fardriver_diameter_tenths();
        snprintf(b, sizeof(b), "колесо %d.%d", t / 10, t % 10);
        lv_label_set_text(s_diam_lbl, b);
        if (s_wheel_lbl) lv_label_set_text(s_wheel_lbl, b);
    }
    if (s_poles_lbl) {
        snprintf(b, sizeof(b), "пары полюсов %d", fardriver_poles());
        lv_label_set_text(s_poles_lbl, b);
    }
    if (s_cabin) {
        char line[120];
        cabin_lcd(line, sizeof(line));
        lv_label_set_text(s_cabin, line);
    }
    if (!s_ap_filled && s_ssid && web_ap_ssid()[0]) {
        lv_textarea_set_text(s_ssid, web_ap_ssid());
        if (s_ap_pass) lv_textarea_set_text(s_ap_pass, web_ap_pass());
        s_ap_filled = 1;
    }
    if (s_cycle) {
        int64_t now_us = esp_timer_get_time();
        if (s_turn_us == 0) s_turn_us = now_us;
        if (now_us - s_turn_us >= (int64_t)s_dwell * 1000000LL) {
            s_turn_us = now_us;
            s_cur = (s_cur + 1) % 5;
            show_page(s_cur);
        }
    }
}
