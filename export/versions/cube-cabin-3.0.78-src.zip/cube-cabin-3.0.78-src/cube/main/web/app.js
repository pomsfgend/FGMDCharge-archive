const $=(id)=>document.getElementById(id);
let pick="", cap=7.5, otaErr=false, otaMode="";
document.querySelectorAll(".nav:not([disabled])").forEach(b=>b.onclick=()=>{
  document.querySelectorAll(".nav").forEach(x=>x.classList.remove("on"));
  b.classList.add("on");
  document.querySelectorAll("main section").forEach(s=>s.classList.add("hide"));
  $(b.dataset.tab).classList.remove("hide");
  if (b.dataset.tab==="logs") logsMeta();
  if (b.dataset.tab==="bms") loadBms();
});
async function tick(){
  try{
    const s=await (await fetch("/api/status?t="+Date.now())).json();
    const live=s.ccs_voltage_0p1v>0;
    $("v").textContent=live?(s.ccs_voltage_0p1v/10).toFixed(0)+" В":"--";
    $("a").textContent=live?(Math.abs(s.ccs_current_0p1a)/10).toFixed(1)+" А":"--";
    $("p").textContent=live?(s.power_w||0)+" Вт":"--";
    const kwh=Number(s.energy_kwh||0);
    $("kwh").textContent=kwh.toFixed?kwh.toFixed(3)+" кВт·ч":"--";
    $("kwh2").textContent=$("kwh").textContent;
    if (s.cap_kwh) cap=Number(s.cap_kwh);
    $("soc").textContent=(s.soc||0)+" %";
    $("soc2").textContent=(s.soc||0)+" %";
    $("st").textContent=s.main_state_name||"нет сессии";
    const tx = s.tx_enabled ? "передача вкл" : "передача выкл";
    $("xchg").textContent = tx+" · "+(s.charger_online?("обмен "+s.rx_count+"/"+s.tx_count):"тишина");
    $("proto").textContent=(s.protocol||"AUTO")+" · "+(s.stage||"");
    if (document.activeElement !== $("protosel")) {
      const map = {"AUTO":"0","GBT-2015/A":"1","GBT-2011":"2","GBT-2023-B":"3"};
      if (map[s.protocol] !== undefined) $("protosel").value = map[s.protocol];
    }
    $("stage").textContent=s.stage||"--";
    $("mins").textContent=(s.ccs_time_min||0)+" мин";
    $("lim").textContent=s.cml_max_voltage_0p1v?((s.cml_min_voltage_0p1v/10)+"-"+(s.cml_max_voltage_0p1v/10)+" В"):"ждём CML";
    $("ch").textContent=s.ap_channel||"--";
    $("sta").textContent=s.ap_clients||0;
    $("sip").textContent=s.sta_ip&&s.sta_ip!=="wait"?("http://"+s.sta_ip+"/"):"ещё нет";
    $("req").textContent=((s.bcl_voltage_0p1v||2400)/10)+" В / "+(Math.abs(s.bcl_current_0p1a||500)/10)+" А";
    $("rel").textContent=(s.relay_a?"замкн":"откр")+" / "+(s.relay_b?"замкн":"откр");
    if ($("bmsa")) $("bmsa").textContent=s.bms_a||"нет связи";
    if ($("bmsb")) $("bmsb").textContent=s.bms_b||"нет связи";
    if ($("votol")) $("votol").textContent=s.speed||s.votol||"--";
    if ($("fdspeed")) $("fdspeed").textContent=s.speed||"--";
    if ($("fddiam") && document.activeElement !== $("fddiam") && s.fd_diam) $("fddiam").value=(s.fd_diam/10).toFixed(1);
    if ($("fdpoles") && document.activeElement !== $("fdpoles") && s.fd_poles) $("fdpoles").value=s.fd_poles;
    if ($("fdcirc") && document.activeElement !== $("fdcirc") && s.fd_circ !== undefined) $("fdcirc").value=s.fd_circ;
    if ($("fdgear") && document.activeElement !== $("fdgear") && s.fd_gear) $("fdgear").value=(s.fd_gear/1000).toFixed(3);
    if ($("fdtrim") && document.activeElement !== $("fdtrim") && s.fd_trim) $("fdtrim").value=(s.fd_trim/10).toFixed(1);
    paintScreen(s);
    if (shown("bms")) refreshBmsTab();
    $("vin").textContent=s.vin||"не задан";
    $("capv").textContent=cap+" кВт·ч";
    if ($("p2011")) {
      const on = (name, yes) => { $(name).textContent = yes ? "активен" : "не активен"; };
      on("p2011", s.protocol==="GBT-2011");
      on("p2015", s.protocol==="GBT-2015/A");
      on("p2023", s.protocol==="GBT-2023-B");
      $("plock").textContent = (s.proto_lock ? "зафиксирован вручную" : "авто") + " · " + (s.protocol||"AUTO");
      const seen = (ms) => ms && ms>0;
      $("crmv").textContent = !seen(s.last_crm_ms) ? "кадра не было" : (s.crm_status===0xAA ? "0xAA — узнала батарею" : "0x00 — ещё не узнала, шлём BRM");
      $("crov").textContent = !seen(s.last_cro_ms) ? "кадра не было" : (s.cro_status_raw===0xAA ? "0xAA — станция готова" : "0x00 — контакторы ещё не готовы");
      $("ccsv").textContent = !seen(s.last_ccs_ms) ? "кадра не было" : ((s.ccs_charge_permit===1 ? "можно ток" : "пауза, сессию не рвём")+" · "+(s.ccs_time_min||0)+" мин");
      if (!seen(s.last_cml_ms)) $("cmlv").textContent = "кадра не было";
      else {
        const amax = Math.abs(s.cml_max_current_0p1a||0)/10;
        const amin = Math.abs(s.cml_min_current_0p1a||0)/10;
        $("cmlv").textContent = ((s.cml_min_voltage_0p1v||0)/10)+"-"+((s.cml_max_voltage_0p1v||0)/10)+" В, ток "+amin.toFixed(0)+"-"+amax.toFixed(0)+" А";
      }
      $("cstv").textContent = !seen(s.last_cst_ms) ? "кадра не было" : ("причина 0x"+(s.cst_status_raw||0).toString(16));
      $("csdv").textContent = !seen(s.last_csd_ms) ? "кадра не было" : ((s.csd_time_min||0)+" мин, "+((s.csd_energy_0p1kwh||0)/10).toFixed(1)+" кВт·ч по станции");
      $("cemv").textContent = !seen(s.last_cem_ms) ? "кадра не было" : ("байты "+(s.cem||""));
      const mode = s.bcl_mode ? "постоянный ток" : "постоянное напряжение";
      $("bclv").textContent = ((s.bcl_voltage_0p1v||0)/10)+" В / "+(Math.abs(s.bcl_current_0p1a||0)/10)+" А · "+mode;
    }
    if (otaMode==="wr" && typeof s.ota_pct==="number" && s.ota_pct>=0) animate(s.ota_pct, "запись "+s.ota_pct+"%");
  }catch(e){
    if (otaMode==="wr") { otaMode=""; animate(100, "куб перезагружается, питание не снимать"); }
  }
}
setInterval(tick,1000); tick();
$("set").onsubmit=async(e)=>{e.preventDefault(); cap=+$("cap").value||7.5;
  await fetch("/api/setpoints",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"v="+$("vv").value+"&i="+$("ii").value+"&soc="+$("ss").value+"&cap="+$("cap").value+"&proto="+$("protosel").value+"&vin="+encodeURIComponent($("vinin").value)});
};
$("scan").onclick=async()=>{
  const r=await (await fetch("/api/wifi/scan")).json();
  $("nets").innerHTML=""; $("sheet").classList.add("hide");
  (r.nets||[]).forEach(n=>{const li=document.createElement("li"); li.textContent=n; li.onclick=()=>{pick=n; $("chosen").textContent=n; $("sheet").classList.remove("hide"); $("pw").focus();}; $("nets").appendChild(li);});
};
$("cancel").onclick=()=>$("sheet").classList.add("hide");
$("join").onclick=async()=>{ $("sip").textContent="wait"; $("sheet").classList.add("hide"); await fetch("/api/wifi/join",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"ssid="+encodeURIComponent(pick)+"&pass="+$("pw").value}); };
$("relay").onclick=async()=>{await fetch("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:"{\"relay_test\":true}"});};
$("fdset").onsubmit=async(e)=>{
  e.preventDefault();
  const gear=Math.round(Number($("fdgear").value)*1000);
  const trim=Math.round(Number($("fdtrim").value)*10);
  await fetch("/api/fardriver",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"diam="+encodeURIComponent($("fddiam").value)+"&poles="+encodeURIComponent($("fdpoles").value)+"&circ="+encodeURIComponent($("fdcirc").value)+"&gear="+gear+"&trim="+trim});
  $("fdspeed").textContent="сохранено";
};
const REGS=[
  {r:16, title:"Ёмкость по паспорту", kind:"ah", hint:"Ампер-часы, как в программе на ПК."},
  {r:17, title:"Ёмкость цикла", kind:"ah", hint:"Ампер-часы одного цикла."},
  {r:32, title:"Пакет, перезаряд, отсечка", kind:"packv", hint:"Вольты всего пакета."},
  {r:33, title:"Пакет, перезаряд, возврат", kind:"packv", hint:"Ниже этого заряд снова разрешён."},
  {r:34, title:"Пакет, разряд, отсечка", kind:"packv", hint:"Ниже этого плата рвёт разряд."},
  {r:35, title:"Пакет, разряд, возврат", kind:"packv", hint:"Вольты возврата после глубокого разряда."},
  {r:36, title:"Ячейка, перезаряд, отсечка", kind:"cellv", hint:"Одна ячейка. Для LiFePO4 обычно около 3.650."},
  {r:37, title:"Ячейка, перезаряд, возврат", kind:"cellv", hint:"Вольты возврата ячейки."},
  {r:38, title:"Ячейка, разряд, отсечка", kind:"cellv", hint:"Ниже этого ячейка считается пустой."},
  {r:39, title:"Ячейка, разряд, возврат", kind:"cellv", hint:"Вольты возврата ячейки."},
  {r:40, title:"Ток заряда, отсечка", kind:"amp", hint:"Напиши 100 или 110 и нажми «Записать в плату». Это порог, не живой ток."},
  {r:41, title:"Ток разряда, отсечка", kind:"amp", hint:"Напиши 100 или 110 и нажми «Записать в плату». Это порог, не живой ток."},
  {r:42, title:"Балансир включается от", kind:"cellv", hint:"Вольты ячейки, с которых начинается баланс."},
  {r:43, title:"Окно балансира", kind:"mv", hint:"Милливольты, как в программе на ПК."},
  {r:47, title:"Число ячеек", kind:"n", hint:"Для этой платы обычно 24. Не ставь другое, если ячеек столько и есть."}
];
function regById(p){
  const m={};
  ((p&&p.regs)||[]).forEach((x)=>{ m[x.r]=x; });
  return m;
}
function ampScale(raw, div){
  if (div===10 || div===100) return div;
  const a=Math.abs(Number(raw)||0);
  if (a>=500) return 100;
  if (a>=200) return 10;
  return 1;
}
function viewOf(item, raw, div){
  const v=Number(raw);
  if (!isFinite(v)) return null;
  if (item.kind==="amp"){
    const scale=ampScale(v, div);
    const shown=Math.abs(v)/scale;
    return {scale, sign:v<0?-1:1, unit:"А", text:scale===1?String(Math.round(shown)):shown.toFixed(scale>=100?2:1)};
  }
  if (item.kind==="ah"){
    const scale=Math.abs(v)>=200?100:1;
    const shown=Math.abs(v)/scale;
    return {scale, sign:1, unit:"Ач", text:scale===1?String(Math.round(shown)):shown.toFixed(2)};
  }
  if (item.kind==="packv") return {scale:100, sign:1, unit:"В", text:(v/100).toFixed(2)};
  if (item.kind==="cellv") return {scale:1000, sign:1, unit:"В", text:(v/1000).toFixed(3)};
  if (item.kind==="mv" || item.kind==="n") return {scale:1, sign:1, unit:item.kind==="mv"?"мВ":"", text:String(v)};
  return {scale:1, sign:1, unit:"", text:String(v)};
}
function rawFrom(item, text, scale){
  const n=Number(String(text).replace(",", "."));
  if (!isFinite(n)) return null;
  let mag=Math.round(Math.abs(n)*(scale||1));
  if (item.r===41) mag=-mag;
  if (item.kind==="amp"){
    if (mag>32767) mag=32767;
    if (mag<-32767) mag=-32767;
  }
  return mag;
}
function fillLimits(host, p, idx){
  if (host.dataset.pack !== String(idx) || host.dataset.mode !== "rg") {
    host.dataset.pack = String(idx);
    host.dataset.mode = "rg";
    host.innerHTML = "";
    const kick=document.createElement("button");
    kick.type="button";
    kick.textContent="Прочитать с платы ещё раз";
    kick.onclick=async()=>{
      kick.disabled=true;
      kick.textContent="спрашиваю плату…";
      try { await postForm("/api/bms","read=1"); } catch (e) {}
      bmsAt=0;
      kick.disabled=false;
      kick.textContent="Прочитать с платы ещё раз";
    };
    host.appendChild(kick);
    REGS.forEach((item)=>{
      const row=document.createElement("div");
      row.className="lim";
      const t=document.createElement("b");
      t.textContent=item.title;
      const h=document.createElement("small");
      h.textContent=item.hint;
      const now=document.createElement("div");
      now.className="now";
      now.dataset.k="r"+item.r;
      const inp=document.createElement("input");
      inp.type="text";
      inp.inputMode="decimal";
      inp.dataset.k="r"+item.r;
      inp.oninput=()=>{ inp.dataset.dirty="1"; };
      const btn=document.createElement("button");
      btn.type="button";
      btn.textContent="Записать в плату";
      btn.onclick=async()=>{
        const scale=Number(inp.dataset.scale)||1;
        const raw=rawFrom(item, inp.value, scale);
        if (raw===null || inp.disabled) return;
        btn.disabled=true;
        btn.textContent="пишу и сохраняю…";
        now.dataset.lock="0";
        try {
          const ans=await (await fetch("/api/bms",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"pack="+idx+"&reg="+item.r+"&value="+encodeURIComponent(String(raw))})).json();
          const back=viewOf(item, ans.value, scale);
          if (ans.ok && back) {
            now.textContent="записано в плату: "+back.text+(back.unit?(" "+back.unit):"");
            inp.value=back.text;
            inp.dataset.raw=String(ans.value);
            inp.dataset.dirty="0";
          } else {
            inp.dataset.dirty="1";
            now.dataset.lock="1";
            now.textContent = back ? ("плата не сменила, в ней осталось "+back.text+(back.unit?(" "+back.unit):"")) : "плата не приняла запись";
          }
        } catch (e) {
          inp.dataset.dirty="1";
          now.dataset.lock="1";
          now.textContent="нет ответа от куба";
        }
        btn.disabled=false;
        btn.textContent="Записать в плату";
        bmsAt=0;
      };
      row.appendChild(t); row.appendChild(h); row.appendChild(now); row.appendChild(inp); row.appendChild(btn);
      host.appendChild(row);
    });
  }
  const map=regById(p);
  const div=Number(p && p.amp_div);
  REGS.forEach((item)=>{
    const rec=map[item.r];
    const ok=!!(p && p.ok && rec && rec.ok);
    const view=ok?viewOf(item, rec.v, div):null;
    const now=host.querySelector('.now[data-k="r'+item.r+'"]');
    const inp=host.querySelector('input[data-k="r'+item.r+'"]');
    const btn=inp?inp.parentElement.querySelector("button"):null;
    const locked=now && now.dataset.lock==="1" && inp && inp.dataset.dirty==="1";
    if (now && !locked) now.textContent = view ? ("в плате сейчас: "+view.text+(view.unit?(" "+view.unit):"")) : "жду это число с платы";
    if (inp) {
      inp.disabled=!view;
      if (view) {
        inp.dataset.raw=String(rec.v);
        inp.dataset.scale=String(view.scale);
      }
      if (document.activeElement!==inp && inp.dataset.dirty!=="1" && view) inp.value=view.text;
    }
    if (btn && btn.textContent!=="пишу и сохраняю…") {
      btn.disabled=!view;
      btn.textContent="Записать в плату";
    }
  });
}
function ampsMa(ma){
  const n=(ma||0)<0;
  const a=Math.abs(ma||0);
  return (n?"-":"+")+(a/1000).toFixed(2);
}
function balCells(mask, ncell){
  const m=BigInt(mask||0);
  const lim=ncell>0?ncell:32;
  const out=[];
  for (let i=0;i<lim && i<32;i++) if ((m & (1n<<BigInt(i)))!==0n) out.push(i+1);
  return out;
}
function packHead(p){
  if (!p || !p.ok) return "нет связи";
  const cells=balCells(p.bal, p.ncell);
  const bal=cells.length?("балансир включен: "+cells.join(", ")):"балансир выключен";
  const fet="ключ заряда "+((p.fet&1)?"вкл":"выкл")+", ключ разряда "+((p.fet&2)?"вкл":"выкл");
  const hw=p.hw?("плата: "+p.hw+"\n"):"";
  return hw+"осталось "+((p.mah||0)/1000).toFixed(2)+" Ач\nток "+ampsMa(p.ma)+" А, пик с включения "+ampsMa(p.peak_ma)+" А\n"+((p.mv||0)/1000).toFixed(2)+" В, разброс "+(p.d_mv<0?"—":p.d_mv+" мВ")+", "+(p.soc||0)+"%\n"+bal+"\n"+fet;
}
function cellGrid(host, p){
  host.innerHTML="";
  if (!p || !p.ok || !p.cells || !p.cells.length) return;
  const mx=Math.max.apply(null, p.cells);
  const mn=Math.min.apply(null, p.cells);
  const on=balCells(p.bal, p.ncell);
  p.cells.slice(0,24).forEach((mv,i)=>{
    const d=document.createElement("div");
    const low=mx-mn>=20 && mv<=mx-20;
    d.className=on.indexOf(i+1)>=0?"cell bal":(low?"cell low":"cell");
    d.textContent=(i+1)+"  "+(mv/1000).toFixed(3);
    host.appendChild(d);
  });
}
function paintRole(r){
  const s=$("blerole");
  const p=$("blepack");
  const t=$("blerolev");
  if (!s || !r) return;
  if (document.activeElement!==s && r.ble_role!==undefined) s.value=String(r.ble_role);
  if (p && document.activeElement!==p && r.ble_pack!==undefined) p.value=String(r.ble_pack);
  if (t) t.textContent = Number(r.ble_role)===1
    ? "сейчас в эфире Xiaoxiang BMS, приложение Xiaoxiang, АКБ "+(Number(r.ble_pack)?"B":"A")
    : "сейчас в эфире FarDriver, для фары";
}
let bmsCache=null, bmsAt=0, spk=0, sp=0, snet="";
async function bmsFresh(){
  if (bmsCache && Date.now()-bmsAt<1500) return bmsCache;
  bmsCache=await (await fetch("/api/bms?t="+Date.now())).json();
  bmsAt=Date.now();
  return bmsCache;
}
async function loadBms(){
  const box=$("bmspacks");
  box.textContent="читаю";
  try{
    const r=await bmsFresh();
    box.innerHTML="";
    (r.packs||[]).forEach((p,idx)=>{
      const h=document.createElement("h2");
      h.textContent="АКБ "+(idx?"B":"A");
      const info=document.createElement("p");
      info.style.whiteSpace="pre-wrap";
      info.className="live";
      info.dataset.pack=String(idx);
      info.textContent=packHead(p);
      const g=document.createElement("div");
      g.className="cells";
      g.dataset.pack=String(idx);
      cellGrid(g, p);
      const lim=document.createElement("div");
      lim.className="limhost";
      lim.dataset.pack=String(idx);
      box.appendChild(h); box.appendChild(info); box.appendChild(g); box.appendChild(lim);
      fillLimits(lim, p, idx);
    });
    paintRole(r);
  }catch(e){ box.textContent="нет ответа"; }
}
async function logsMeta(){
  try{
    const r=await (await fetch("/api/logs?t="+Date.now())).json();
    const logs=r.logs||[];
    $("logn").textContent = logs.length ? ("файлов сессии: "+logs.length) : "файлов ещё нет: станция не начала обмен";
    $("allzip").classList.toggle("hide", logs.length<2);
    const ul=$("logfiles");
    ul.innerHTML="";
    logs.forEach((f)=>{
      const li=document.createElement("li");
      const a=document.createElement("a");
      a.href="/api/logs/file?n="+(f.n-1);
      a.textContent="Скачать этот файл";
      li.appendChild(document.createTextNode("№"+f.seq+" · "+f.protocol+" · "+f.bytes+" байт · "+f.reason+" "));
      li.appendChild(a);
      ul.appendChild(li);
    });
  }catch(e){}
}
$("getlog").onclick=async()=>{ $("esplog").textContent=await (await fetch("/api/log")).text(); $("canlog").textContent=await (await fetch("/api/can")).text(); logsMeta(); };
$("allzip").onclick=()=>{ location.href="/api/logs.zip"; };
let hold;
$("hold").addEventListener("pointerdown",(e)=>{e.preventDefault(); hold=setTimeout(async()=>{await fetch("/api/stop",{method:"POST"});},700);});
$("hold").addEventListener("pointerup",()=>clearTimeout(hold));
function animate(p,txt){ $("otamodal").classList.add("show"); $("bar").style.width=Math.max(0,Math.min(100,p))+"%"; $("otatxt").textContent=txt; }
$("ota").onclick=()=>{
  const f=$("bin").files[0];
  otaErr=false;
  otaMode="rx";
  if(!f){ otaErr=true; otaMode=""; animate(0, "выберите файл .bin"); return; }
  const name=(f.name||"").toLowerCase();
  if(name.endsWith(".zip") || f.size>0x190000 || f.size<24){
    otaErr=true;
    otaMode="";
    animate(0, "нужен FD_ROUND_S3.bin, не zip и не загрузчик");
    return;
  }
  const xhr=new XMLHttpRequest(); xhr.timeout=0; xhr.open("POST","/api/ota");
  xhr.upload.onprogress=(e)=>{ if(e.lengthComputable && otaMode==="rx") animate(e.loaded/e.total*100, "приём "+Math.round(e.loaded/e.total*100)+"%"); };
  xhr.onload=()=>{
    let t=xhr.responseText||"";
    if(xhr.status>=200 && xhr.status<300 && t.indexOf('"ok":true')>=0) { otaMode="wr"; animate(0, "запись 0%"); }
    else { otaErr=true; otaMode=""; animate(0, t||("ошибка "+xhr.status)); }
  };
  xhr.onerror=()=>{
    if (otaMode==="wr") { otaMode=""; animate(100, "куб перезагружается, питание не снимать"); }
    else { otaErr=true; otaMode=""; animate(0, "приём оборвался, залейте ещё раз"); }
  };
  xhr.ontimeout=()=>{ otaErr=true; animate(0, "таймаут"); };
  xhr.send(f);
};
$("netfw").onclick=async()=>{
  animate(8, "запрос файла, полоса на кубе");
  const body="url="+encodeURIComponent($("url").value)+"&user="+encodeURIComponent($("wu").value)+"&pass="+encodeURIComponent($("wp").value);
  const r=await fetch("/api/ota/url",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});
  animate(12, await r.text());
};
async function refreshBmsTab(){
  try{
    const r=await bmsFresh();
    (r.packs||[]).forEach((p,idx)=>{
      document.querySelectorAll("#bmspacks .live").forEach((el)=>{
        if (el.dataset.pack===String(idx)) el.textContent=packHead(p);
      });
      document.querySelectorAll("#bmspacks .cells").forEach((el)=>{
        if (el.dataset.pack===String(idx)) cellGrid(el, p);
      });
      document.querySelectorAll("#bmspacks .limhost").forEach((el)=>{
        if (el.dataset.pack===String(idx)) fillLimits(el, p, idx);
      });
    });
    paintRole(r);
  }catch(e){}
}
function clock(sec){
  sec=sec|0;
  const z=(n)=>String(n).padStart(2,"0");
  return z(Math.floor(sec/3600))+":"+z(Math.floor(sec/60)%60)+":"+z(sec%60);
}
function shown(id){ const e=$(id); return e && !e.classList.contains("hide"); }
function postForm(url, body){
  return fetch(url,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});
}
function paintScreen(s){
  if (!shown("screen") || !$("skmh")) return;
  const live=s.ccs_voltage_0p1v>0;
  $("sctime").textContent=clock(s.sess_s||0);
  const rv=Math.round((s.bcl_voltage_0p1v||2400)/10);
  const ra=Math.round(Math.abs(s.bcl_current_0p1a||500)/10);
  $("sreqv").textContent=String(rv);
  $("sreqa").textContent=String(ra);
  if (document.activeElement!==$("svin")) $("svin").value=rv;
  if (document.activeElement!==$("sain")) $("sain").value=ra;
  $("soutv").textContent=live?String(Math.round(s.ccs_voltage_0p1v/10)):"0";
  $("souta").textContent=live?(Math.abs(s.ccs_current_0p1a)/10).toFixed(0):"0";
  $("swatt").textContent=live?String(Math.round(s.power_w||0)):"0";
  $("srelt").textContent=s.relay_b?"ON":"OFF";
  const names=["авто","2015/A","2011","2023-B"];
  $("sproto").textContent=names[s.proto_n]||s.protocol||"авто";
  $("scanline").textContent=s.line||"";
  const kmh=Math.abs(s.fd_kmh10||0);
  $("skmh").textContent=s.fd_direct?"BLE":(kmh/10).toFixed(1);
  $("slink").textContent=s.fd_direct?"мост, разбор выключен":(s.fd_link?"кадр есть":"нет связи");
  $("si").textContent="ток "+((Math.abs(s.fd_amps10||0))/10).toFixed(1)+" А";
  $("simax").textContent="макс ток сессии "+((s.fd_maxa10||0)/10).toFixed(1)+" А";
  $("sv").textContent="напряжение "+((s.fd_volts10||0)/10).toFixed(1)+" В";
  $("srpm").style.whiteSpace="pre-wrap";
  $("srpm").textContent="обороты колеса "+(s.fd_rpm||0)+"\nс контроллера тишина, провода нет";
  $("serr").textContent=(!s.fd_link||s.fd_direct||!s.fd_err)?"ошибки нет":("ошибка "+(s.fd_err>>>0).toString(16));
  $("spolev").textContent=String(s.fd_poles||20);
  if (s.fd_diam) $("sdiamv").textContent=(s.fd_diam/10).toFixed(1);
  if (document.activeElement!==$("sbr") && s.br) $("sbr").value=s.br;
  if (document.activeElement!==$("sgate") && s.gate) $("sgate").value=s.gate;
  $("sbrv").textContent="яркость "+$("sbr").value;
  $("sgatev").textContent="порог нажатия "+$("sgate").value+" — выше, меньше ложных касаний";
  if (document.activeElement!==$("sdirect") && s.fd_direct!==undefined) $("sdirect").value=s.fd_direct?"1":"0";
  $("sdirectv").textContent=s.fd_direct?"мост включен":"мост выключен";
  if (sp===1) screenBms();
}
async function screenBms(){
  try{
    const r=await bmsFresh();
    const p=(r.packs||[])[spk]||{ok:false};
    $("spack").style.whiteSpace="pre-wrap";
    $("spack").textContent=packHead(p);
    cellGrid($("scells"), p);
    $("spk0").classList.toggle("on", spk===0);
    if ($("spk1")) $("spk1").classList.toggle("on", spk===1);
    fillLimits($("slim"), p, spk);
  }catch(e){}
}
function showSp(n){
  sp=n;
  for (let i=0;i<5;i++) $("sp"+i).classList.toggle("hide", i!==n);
  document.querySelectorAll("#lcdnav button").forEach((b)=>b.classList.toggle("on", Number(b.dataset.sp)===n));
  if (n===1) screenBms();
}
document.querySelectorAll("#lcdnav button").forEach((b)=>b.onclick=()=>showSp(Number(b.dataset.sp)));
$("spk0").onclick=()=>{ spk=0; $("slim").dataset.stamp=""; screenBms(); };
if ($("spk1")) $("spk1").onclick=()=>{ spk=1; $("slim").dataset.stamp=""; screenBms(); };
$("srelay").onclick=()=>fetch("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:"{\"relay_test\":true}"});
$("swire").onclick=()=>postForm("/api/panel","wire=1");
$("sbus").onclick=()=>postForm("/api/panel","bus=1");
$("sreq").onclick=()=>postForm("/api/setpoints","v="+$("svin").value+"&i="+$("sain").value);
$("spolem").onclick=()=>postForm("/api/fardriver","poles="+((Number($("spolev").textContent)||20)-1));
$("spolep").onclick=()=>postForm("/api/fardriver","poles="+((Number($("spolev").textContent)||20)+1));
$("sdiamm").onclick=()=>postForm("/api/fardriver","diam="+(((Number($("sdiamv").textContent)||16.3)-0.1).toFixed(1)));
$("sdiamp").onclick=()=>postForm("/api/fardriver","diam="+(((Number($("sdiamv").textContent)||16.3)+0.1).toFixed(1)));
$("sbr").oninput=()=>{ $("sbrv").textContent="яркость "+$("sbr").value; postForm("/api/panel","br="+$("sbr").value); };
$("sgate").oninput=()=>{ $("sgatev").textContent="порог нажатия "+$("sgate").value; postForm("/api/panel","gate="+$("sgate").value); };
$("swifi").onclick=()=>{ $("smsg").textContent="Wi-Fi перезапускается"; postForm("/api/panel","wifi=1"); };
$("sble").onclick=async()=>{ $("smsg").textContent="BLE снова в эфире"; await postForm("/api/panel","ble=1"); };
$("sreboot").onclick=()=>fetch("/api/reboot",{method:"POST"});
$("sstop").onclick=()=>fetch("/api/stop",{method:"POST"});
$("sapsave").onclick=async()=>{
  $("smsg").textContent="точка сохраняется";
  await postForm("/api/panel","ssid="+encodeURIComponent($("sapssid").value)+"&pass="+encodeURIComponent($("sappass").value));
};
$("sscan").onclick=async()=>{
  const r=await (await fetch("/api/wifi/scan")).json();
  $("snets").innerHTML="";
  snet="";
  (r.nets||[]).forEach((n)=>{
    const li=document.createElement("li");
    li.textContent=n;
    li.onclick=()=>{ snet=n; $("smsg").textContent=n; };
    $("snets").appendChild(li);
  });
  $("smsg").textContent=(r.nets||[]).length?"сеть выбрана нажатием":"сетей нет";
};
$("sjoin").onclick=async()=>{
  if (!snet){ $("smsg").textContent="сначала выбери сеть"; return; }
  $("smsg").textContent="подключаюсь";
  await postForm("/api/wifi/join","ssid="+encodeURIComponent(snet)+"&pass="+encodeURIComponent($("sstap").value));
};
document.querySelectorAll("#sprotos button").forEach((b)=>b.onclick=()=>postForm("/api/panel","proto="+b.dataset.proto));
$("sdirect").onchange=()=>postForm("/api/fardriver","direct="+$("sdirect").value);
$("blerolego").onclick=async()=>{
  $("blerolev").textContent="куб перезапускает BLE. Подожди и открой страницу снова.";
  try { await postForm("/api/ble","role="+$("blerole").value+"&pack="+$("blepack").value); }
  catch (e) {}
};
