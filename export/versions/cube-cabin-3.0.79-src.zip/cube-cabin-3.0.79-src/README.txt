Исходники 3.0.79.

cube/ прошивка ESP32-S3
cabin/ приложение Кабина
idf-patch/twai_hal_iram.c правка ESP-IDF, без неё кадры CAN не разбираются.

Сборка куба: idf.py -B build-s3-round build
Сборка приложения: gradle assembleDebug
