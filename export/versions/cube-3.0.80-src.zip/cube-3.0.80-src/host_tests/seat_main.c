#define CHECK(c) do{ if(!(c)){ printf("FAIL line %d: %s\n",__LINE__,#c); fails++; } }while(0)
int main(void){
  int fails=0; seat_filter_t f; memset(&f,0,sizeof f);
  /* 1. median removes a single spike */
  int v=0; int64_t ms=0;
  for(int i=0;i<5;i++){ v=seat_filter_push(&f,2500,ms); ms+=400; }
  v=seat_filter_push(&f,8500,ms); ms+=400;   /* glitch */
  CHECK(v==2500);
  v=seat_filter_push(&f,2500,ms); ms+=400;
  CHECK(v==2500);
  /* 2. rate: +0.1 C/s (10 per s) ramp sampled every 400 ms */
  memset(&f,0,sizeof f); ms=0; int t=2000;
  for(int i=0;i<20;i++){ seat_filter_push(&f,t,ms); t+=4; ms+=400; }
  int r=seat_filter_rate(&f);
  printf("rate=%d (expect ~10)\n",r); CHECK(r>=8 && r<=12);
  CHECK(seat_lead(r)>=30 && seat_lead(r)<=50);
  CHECK(seat_lead(100000)==SEAT_LEAD_MAX && seat_lead(-100000)==-SEAT_LEAD_MAX);
  /* 3. PID: cold seat -> full duty, at setpoint -> ~0, anti-windup bounds */
  int32_t I=0;
  CHECK(seat_pid_step(3200,1500,400,&I)==100);
  CHECK(I<=600);
  for(int i=0;i<5000;i++) seat_pid_step(3200,1500,400,&I);
  CHECK(I<=600 && I>=0);
  I=0; int d=seat_pid_step(3200,3200,400,&I); CHECK(d==0);
  I=0; d=seat_pid_step(3200,3000,400,&I); printf("duty at -2C: %d\n",d); CHECK(d>=45&&d<=60);
  I=600; d=seat_pid_step(3200,3400,400,&I); CHECK(d<=30);   /* above setpoint: output falls fast */
  /* 4. closed loop with a lagged plant: mat heats seat, probe lags */
  double mat=1500, probe=1500; I=0; memset(&f,0,sizeof f); ms=0; double maxT=0; int duty=0;
  for(int step=0; step<4500; step++){ /* 0.4 s steps = 30 min */
     mat += (duty*0.9 - (mat-1500)*0.018) * 0.4 * 0.8;       /* plant */
     probe += (mat-probe)*0.4/6.0;                           /* sensor lag 6 s */
     int raw=((int)(probe/12.5))*125/10;                    /* 0.125 C quantisation */
     int fl=seat_filter_push(&f,raw,ms); ms+=400;
     int pr=fl+seat_lead(seat_filter_rate(&f));
     duty=seat_pid_step(3200,pr,400,&I);
     if(probe>maxT) maxT=probe;
  }
  printf("closed loop: final probe=%.1f max=%.1f duty=%d\n",probe,maxT,duty);
  CHECK(maxT<3200+250);
  CHECK(probe>3200-150 && probe<3200+150);
  printf(fails?"TESTS FAILED\n":"ALL OK\n"); return fails;
}
