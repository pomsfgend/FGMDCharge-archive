#!/usr/bin/env bash
# Builds and runs the seat filter / regulator tests on the host.
# The logic is taken straight from main/cabin.c between the SEAT-LOGIC markers,
# so the test always checks the code that is flashed.
set -e
cd "$(dirname "$0")"
{
  printf '#include <stdint.h>\n#include <stdio.h>\n#include <string.h>\n#include <stdlib.h>\n'
  printf '#define SEAT_LEAD_MS 4000\n#define SEAT_LEAD_MAX 150\n#define SEAT_HIST 16\n'
  sed -n '/SEAT-LOGIC-BEGIN/,/SEAT-LOGIC-END/p' ../main/cabin.c
  cat seat_main.c
} > /tmp/seat_test_build.c
gcc -Wall -Wextra -o /tmp/seat_test /tmp/seat_test_build.c
/tmp/seat_test
