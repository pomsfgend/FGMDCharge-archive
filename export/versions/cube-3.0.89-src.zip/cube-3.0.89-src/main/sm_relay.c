/*
 * State machine + relay control reconstructed from original FGMDCharge dump.
 * Sequence (CONFIRMED):
 *   Station seen -> GPIO6 ON (ZVS imitates the battery through the whole search).
 *   State5 + CCS >= 50.0V stable 5s -> GPIO6 OFF, GPIO7 ON (pack). Never both.
 *   GPIO38 closes and opens with GPIO7, for a second pack contactor.
 *   The screen tile only bench-tests that output while no station is on CAN.
 *   It does not latch and it does not decide the charge.
 *   Stop / idle / error -> both relays LOW
 * BLE 0x66 only touches GPIO6 + substate, never GPIO7.
 */
#include "sm_relay.h"
#include "app_state.h"
#include "bms_uart.h"
#include "config.h"
#include "can_gbt.h"
#include "gbt_b.h"
#include "session_log.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "nvs.h"
#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "SM_RELAY";

static uint8_t  s_main = ST_IDLE;
static uint8_t  s_sub  = 0;
static bool     s_handoff = false;
static uint32_t s_entry_ms = 0;
static bool     s_crm_ok = false;
static bool     s_cro_ok = false;
static uint32_t s_last_bhm_ms = 0;
static uint32_t s_last_bcl_ms = 0;
static uint32_t s_last_bcs_ms = 0;
static uint32_t s_last_bsm_ms = 0;
static bool     s_crm00 = false;
static bool     s_crmaa = false;
static uint32_t s_last_brm_ms = 0;
static uint32_t s_last_bcp_ms = 0;
static uint32_t s_last_rx_count = 0;
static uint32_t s_last_chg_ms = 0;
static uint32_t s_auto_hold_until = 0;
static bool     s_boot_started = false;
static uint32_t s_power_seen_ms = 0;
static bool s_load_on = false;
static uint16_t s_v_anchor = 0;
/* Bench test of the output while no station is talking. Never latches into a charge. */
static int s_bench = 0;
static int s_user_a = 0;
static int s_user_b = 0;
static int s_user_hold = 0;
static int s_hv_lockout = 0;
static int s_hv_fitted = 0; /* 3.0.89: the 12-220 converter is not wired */
static int s_drv_a = -1;
static int s_drv_b = -1;
static uint32_t s_station_since = 0;
static uint32_t s_last_opt_ms = 0;
static uint32_t s_bhm_log_ms = 0;
static int s_bhm_pri3 = 0;
static uint32_t s_flood_ms = 0;
static uint32_t s_flood_rx = 0;
static int s_flood = 0;

static uint32_t now_ms(void)
{
    return (uint32_t)(esp_timer_get_time() / 1000ULL);
}

static void relays_drive(int a, int b)
{
    if (a == s_drv_a && b == s_drv_b) {
        app_state_set_relays((uint8_t)(a ? 1 : 0), (uint8_t)(b ? 1 : 0));
        return;
    }
    /* Active-low opto board: HIGH = coil off. Write only when the coil changes. */
    gpio_set_level(CUBE_RELAY_A_GPIO, a ? 0 : 1);
    gpio_set_level(CUBE_RELAY_B_GPIO, b ? 0 : 1);
    gpio_set_level(CUBE_RELAY_PAR_GPIO, b ? 0 : 1);
    s_drv_a = a;
    s_drv_b = b;
    app_state_set_relays((uint8_t)(a ? 1 : 0), (uint8_t)(b ? 1 : 0));
    ESP_LOGW(TAG, "coils IN6=%d IN7=%d", a, b);
}

/* Returns 1 when the outputs match the request. A pending break-before-make
 * returns 0 and must be asked again on the next tick. */
static int relays_set(int a, int b)
{
    if (!s_hv_fitted || s_hv_lockout) a = 0;
    if (a && b) a = 0;
    if (s_drv_a == 1 && b) {
        relays_drive(0, 0);
        return 0;
    }
    relays_drive(a ? 1 : 0, b ? 1 : 0);
    return 1;
}

static void hv_load(void)
{
    nvs_handle_t h;
    uint8_t v = 0;
    s_hv_fitted = 0;
    if (nvs_open("storage", NVS_READONLY, &h) != ESP_OK) return;
    if (nvs_get_u8(h, "hv_fit", &v) == ESP_OK) s_hv_fitted = v ? 1 : 0;
    nvs_close(h);
}

void sm_set_hv_fitted(int on)
{
    nvs_handle_t h;
    s_hv_fitted = on ? 1 : 0;
    if (!s_hv_fitted) {
        s_user_a = 0;
        relays_set(0, s_drv_b == 1);
    }
    if (nvs_open("storage", NVS_READWRITE, &h) == ESP_OK) {
        nvs_set_u8(h, "hv_fit", (uint8_t)s_hv_fitted);
        nvs_commit(h);
        nvs_close(h);
    }
    app_state_log(s_hv_fitted
        ? "преобразователь 12-220 можно включать"
        : "преобразователь снят, IN6 молчит");
}

int sm_hv_fitted(void)
{
    return s_hv_fitted;
}

void sm_hv_lockout(int on)
{
    s_hv_lockout = on ? 1 : 0;
    if (s_hv_lockout) {
        s_user_a = 0;
        relays_set(0, s_user_b);
    }
}

static void relays_fail_safe(void)
{
    relays_set(0, 0);
}

static void set_state(uint8_t s)
{
    s_main = s;
    s_entry_ms = now_ms();
    s_handoff = false;
    app_state_set_main_state(s);
    app_state_set_handoff(false);

    if (s == ST_IDLE || s == ST_STOP || s == ST_FINALIZE ||
        s == ST_HANDSHAKE_INIT || s == ST_CHARGING) {
        s_load_on = false;
        s_power_seen_ms = 0;
        s_v_anchor = 0;
    }
    if (s == ST_IDLE || s == ST_STOP || s == ST_FINALIZE) {
        s_hv_lockout = 0;
        app_state_set_session(false);
        if (s == ST_IDLE && s_user_hold) relays_set(s_user_a, s_user_b);
        else {
            relays_fail_safe();
            if (s == ST_IDLE && s_bench) relays_set(0, 1);
        }
    }
    if (s == ST_READY_WAIT_CRO || s == ST_WAIT_CRM) {
        s_sub = (s == ST_READY_WAIT_CRO) ? 3 : s_sub;
        if (s == ST_READY_WAIT_CRO) app_state_set_substate(3);
        s_bench = 0;
        s_hv_lockout = 0;
        if (s_hv_fitted) {
            relays_set(1, 0);
            if (s == ST_WAIT_CRM) app_state_log("имитация батареи включена");
        } else {
            relays_set(0, 0);
            if (s == ST_WAIT_CRM) app_state_log("преобразователь снят, IN6 не включаю");
        }
    }
    ESP_LOGI(TAG, "state -> %s (%u) sub=%u", cube_main_state_name(s), (unsigned)s, (unsigned)s_sub);
}

static void end_session(void)
{
    session_log_request(1, SESSION_LOG_STOP);
    app_state_release_auto_protocol();
    if (s_main == ST_IDLE) return;
    set_state(ST_STOP);
    set_state(ST_FINALIZE);
    set_state(ST_IDLE);
}

/* --- TX helpers (only when TX enabled) --- */
static bool st_proto_is_2011(void);

static int bus_is_flood(const cube_state_snapshot_t *st)
{
    uint32_t t = now_ms();
    if (s_flood_ms == 0 || (t - s_flood_ms) >= 500) {
        uint32_t d = (s_flood_ms == 0) ? 0 : (st->rx_count - s_flood_rx);
        if (s_flood_ms != 0) s_flood = d > 50;
        s_flood_ms = t;
        s_flood_rx = st->rx_count;
    }
    return s_flood;
}

static esp_err_t tx_bhm(void)
{
    uint8_t d[8] = {0};
    uint16_t vmax = CUBE_DEFAULT_MAX_VOLTAGE_0P1V;
    uint32_t id = 0x182756F4u;
    cube_state_snapshot_t st;
    app_state_snapshot(&st);
    d[0] = (uint8_t)(vmax & 0xFF);
    d[1] = (uint8_t)(vmax >> 8);
    /* Log 8 was a normal pile, ~4 CHM/s. Priority 3 (0x0C2756F4) is not BHM
     * to that pile. Use it only when CHM is a flood (>100 frames/s), where
     * the standard ID loses arbitration to 0x1826F456. */
    s_bhm_pri3 = 0;
    if (bus_is_flood(&st)) {
        id = 0x0C2756F4u;
        s_bhm_pri3 = 1;
    }
    return gbt_can_send(id, d, 2);
}

/* J1939 BAM: stations drop the session if BRM/BCP are not multi-frame. */
static esp_err_t tx_bam(uint32_t pgn, const uint8_t *payload, uint16_t len)
{
    /* 2011 piles expect J1939 priority 6 on BRM/BCP/BCS. 2015 and 2023-A use 7. */
    const int old = st_proto_is_2011();
    const uint32_t cm_id = old ? 0x18EC56F4u : 0x1CEC56F4u;
    const uint32_t dt_id = old ? 0x18EB56F4u : 0x1CEB56F4u;
    uint8_t packets = (uint8_t)((len + 6) / 7);
    uint8_t cm[8] = {
        32, (uint8_t)(len & 0xFF), (uint8_t)(len >> 8), packets, 0xFF,
        (uint8_t)(pgn & 0xFF), (uint8_t)((pgn >> 8) & 0xFF), (uint8_t)((pgn >> 16) & 0xFF)
    };
    if (gbt_can_send(cm_id, cm, 8) != ESP_OK) return ESP_FAIL;
    vTaskDelay(pdMS_TO_TICKS(10));
    for (uint8_t seq = 1; seq <= packets; ++seq) {
        uint8_t dt[8];
        memset(dt, 0xFF, sizeof(dt));
        dt[0] = seq;
        uint16_t off = (uint16_t)(seq - 1) * 7;
        for (int i = 0; i < 7 && (off + i) < len; ++i) dt[1 + i] = payload[off + i];
        if (gbt_can_send(dt_id, dt, 8) != ESP_OK) return ESP_FAIL;
        vTaskDelay(pdMS_TO_TICKS(10));
    }
    return ESP_OK;
}


static bool st_proto_is_2011(void)
{
    cube_state_snapshot_t snap;
    app_state_snapshot(&snap);
    return snap.protocol == 2;
}

static esp_err_t tx_brm(void)
{
    uint8_t b[49];
    esp_err_t e;
    memset(b, 0xFF, sizeof(b));
    b[0] = st_proto_is_2011() ? 0 : 1; /* 2011 is V1.0 -> 00 01 00, 2015 is V1.1 -> 01 01 00 */
    b[1] = 1;
    b[2] = 0;
    b[3] = 6;                     /* ternary lithium */
    b[4] = 0xE8; b[5] = 0x03;     /* 100.0 Ah */
    b[6] = 0xA0; b[7] = 0x0F;     /* 400.0 V */
    memcpy(&b[8], "CUBE", 4);
    b[16] = 41;                   /* year 1985+41 = 2026 */
    b[17] = 10;
    b[18] = 29;
    b[19] = 1;                    /* one cycle, next two bytes must not stay 0xFF */
    b[20] = 0;
    b[21] = 0;
    b[22] = 1;                    /* vehicle owns the pack */
    memcpy(&b[24], "00000000000000000", 17);
    {
        const char *vin = app_state_vin();
        for (int i = 0; i < 17 && vin && vin[i]; ++i) b[24 + i] = (uint8_t)vin[i];
    }
    memcpy(&b[41], CUBE_FW_VERSION, 6);
    if (st_proto_is_2011()) {
        e = tx_bam(0x000200u, b, 41);
        if (e == ESP_OK) app_state_log("паспорт батареи ушёл, старый протокол");
    } else {
        e = tx_bam(0x000200u, b, 49);
        if (e == ESP_OK) app_state_log("паспорт батареи ушёл");
    }
    return e;
}

static void tx_bcp(void)
{
    cube_state_snapshot_t st;
    app_state_snapshot(&st);
    uint8_t b[13];
    memset(b, 0, sizeof(b));
    uint16_t cell = 420; /* 4.20 V */
    int32_t i_abs = st.bcl_requested_current_0p1a;
    int32_t imax;
    uint16_t energy = (uint16_t)(app_state_cap_kwh() * 10.0f); /* 0.1 kWh */
    uint16_t vmax = CUBE_DEFAULT_MAX_VOLTAGE_0P1V;
    uint16_t vnow = st.battery_voltage_0p1v;
    uint16_t soc_01;
    if (vnow < 100) vnow = st.bcl_requested_voltage_raw ? st.bcl_requested_voltage_raw : 2400;
    if (i_abs < 0) i_abs = -i_abs;
    if (st.last_cml_ms != 0 && st.cml_max_current_0p1a < 0) {
        int32_t lim = -(int32_t)st.cml_max_current_0p1a;
        if (i_abs > lim) i_abs = lim;
    }
    if (vnow > vmax) vmax = vnow;
    /* Charge current is negative. raw = 4000 - |I|. +I is outside -400..0 A and the pile aborts. */
    imax = 4000 - i_abs;
    if (imax < 0) imax = 0;
    if (imax > 65535) imax = 65535;
    soc_01 = (uint16_t)(st.soc_percent ? st.soc_percent : 50) * 10u;
    b[0] = (uint8_t)(cell & 0xFF); b[1] = (uint8_t)(cell >> 8);
    b[2] = (uint8_t)(imax & 0xFF); b[3] = (uint8_t)(imax >> 8);
    b[4] = (uint8_t)(energy & 0xFF); b[5] = (uint8_t)(energy >> 8);
    b[6] = (uint8_t)(vmax & 0xFF); b[7] = (uint8_t)(vmax >> 8);
    b[8] = 90; /* 40 C, offset -50 */
    b[9] = (uint8_t)(soc_01 & 0xFF);
    b[10] = (uint8_t)(soc_01 >> 8);          /* SOC is 0.1 % in 2015 and 2023-A */
    b[11] = (uint8_t)(vnow & 0xFF);
    b[12] = (uint8_t)(vnow >> 8);
    if (tx_bam(0x000600u, b, 13) == ESP_OK) app_state_log("параметры батареи ушли");
}

static void tx_bro(uint8_t ready)
{
    uint8_t d[8] = {ready, 0, 0, 0, 0, 0, 0, 0};
    (void)gbt_can_send(0x100956F4u, d, 1);
}

/* BEM bits: 00 normal, 01 timeout, 10 untrusted. One 2-bit field per missed message. */
static void tx_bem(uint8_t which)
{
    /* Reserved bits are 1. Each 2-bit field is 01 only for the missed message. */
    uint8_t d[4] = {0xF0, 0xF0, 0xF0, 0xFC};
    switch (which) {
        case 0: d[0] = 0xF1; break; /* CRM = 0x00 */
        case 1: d[0] = 0xF4; break; /* CRM = 0xAA */
        case 2: d[1] = 0xF1; break; /* CML */
        case 3: d[1] = 0xF4; break; /* CRO */
        case 4: d[2] = 0xF1; break; /* CCS */
        case 5: d[2] = 0xF4; break; /* CST */
        default: d[3] = 0xFD; break; /* CSD */
    }
    (void)gbt_can_send(GBT_ID_BEM, d, 4);
    app_state_log("таймаут, реле выкл");
}

static void tx_bsd(void)
{
    cube_state_snapshot_t st;
    app_state_snapshot(&st);
    uint8_t d[8] = {0};
    uint16_t cell_min = 330; /* 3.30 V, 0.01 V */
    uint16_t cell_max = 420; /* 4.20 V */
    d[0] = st.soc_percent;
    d[1] = (uint8_t)(cell_min & 0xFF);
    d[2] = (uint8_t)(cell_min >> 8);
    d[3] = (uint8_t)(cell_max & 0xFF);
    d[4] = (uint8_t)(cell_max >> 8);
    d[5] = 70; /* 20 C, offset -50 */
    d[6] = 80; /* 30 C */
    (void)gbt_can_send(GBT_ID_BSD, d, 7);
    app_state_log("итог отправлен");
}

static void tx_bcl(void)
{
    cube_state_snapshot_t st;
    app_state_snapshot(&st);
    uint8_t d[8] = {0};
    uint16_t v = st.bcl_requested_voltage_raw;
    int32_t i_abs = st.bcl_requested_current_0p1a;
    int32_t i_enc;
    if (i_abs < 0) i_abs = -i_abs;
    if (st.last_cml_ms != 0 && st.cml_max_current_0p1a < 0) {
        int32_t lim = -(int32_t)st.cml_max_current_0p1a;
        if (i_abs > lim) i_abs = lim;
    }
    i_enc = 4000 - i_abs;
    if (i_enc < 0) i_enc = 0;
    if (i_enc > 65535) i_enc = 65535;
    d[0] = (uint8_t)(v & 0xFF);
    d[1] = (uint8_t)(v >> 8);
    d[2] = (uint8_t)(i_enc & 0xFF);
    d[3] = (uint8_t)(i_enc >> 8);
    d[4] = st.bcl_mode;
    (void)gbt_can_send(0x181056F4u, d, 5);
}

static void tx_bcs(void)
{
    cube_state_snapshot_t st;
    app_state_snapshot(&st);
    uint8_t b[9];
    uint16_t v = st.battery_voltage_0p1v ? st.battery_voltage_0p1v : st.ccs_output_voltage_raw;
    int32_t i_abs = st.battery_current_0p1a ? st.battery_current_0p1a : st.ccs_output_current_0p1a;
    uint16_t cell = 420; /* 4.20 V, group 0 */
    int32_t i_enc;
    if (i_abs < 0) i_abs = -i_abs;
    i_enc = 4000 - i_abs;
    if (i_enc < 0) i_enc = 0;
    if (i_enc > 65535) i_enc = 65535;
    memset(b, 0, sizeof(b));
    b[0] = (uint8_t)(v & 0xFF);
    b[1] = (uint8_t)(v >> 8);
    b[2] = (uint8_t)(i_enc & 0xFF);
    b[3] = (uint8_t)(i_enc >> 8);
    b[4] = (uint8_t)(cell & 0xFF);
    b[5] = (uint8_t)(cell >> 8);
    b[6] = st.soc_percent;
    b[7] = 0x58; /* 600 min. Zero means "finished" and a lot of piles stop. */
    b[8] = 0x02;
    tx_bam(0x001100u, b, 9);
}

static void tx_bsm(void)
{
    uint16_t bits = 0;
    uint8_t d[8];
    memset(d, 0, sizeof(d));
    d[0] = 1;   /* highest-cell index, numbering starts at 1 */
    d[1] = 75;  /* 25 C, offset -50. Zero would be -50 C and trips the pile. */
    d[2] = 1;
    d[3] = 70;  /* 20 C */
    d[4] = 1;
    bits |= (1u << 12); /* charge allowed */
    bits |= (3u << 14); /* reserved bits filled with 1 */
    d[5] = (uint8_t)(bits & 0xFF);
    d[6] = (uint8_t)(bits >> 8);
    (void)gbt_can_send(GBT_ID_BSM, d, 7);
}

/* Optional in every GB/T 27930 edition. 2011 period is 1 s, 2015/2023-A is 10 s. */
static void tx_optional_cells(void)
{
    uint8_t mv[2];
    uint8_t mt[1];
    uint8_t sp[1];
    uint16_t cell = 420; /* 4.20 V in 12 bits, group 0 */
    mv[0] = (uint8_t)(cell & 0xFF);
    mv[1] = (uint8_t)(cell >> 8);
    mt[0] = 75;
    sp[0] = 0xFF;
    if (tx_bam(0x001500u, mv, 2) != ESP_OK) return;
    if (tx_bam(0x001600u, mt, 1) != ESP_OK) return;
    if (tx_bam(0x001700u, sp, 1) != ESP_OK) return;
    app_state_log("доп. данные ушли");
}

static void tx_bst(void)
{
    uint8_t d[8] = {0x01, 0, 0, 0}; /* normal stop */
    (void)gbt_can_send(0x101956F4u, d, 4);
}

static int pack_0p1(void)
{
    bms_link_t p;
    bms_link_get(0, &p);
    if (!p.ok || p.mv < 15000 || p.mv > 120000) return 0;
    return p.mv / 100;
}

/* Station output is close enough to the pack that the contactor will not
 * weld. Unknown pack: any held voltage at or above 50 V is accepted. */
static int volts_close(uint16_t station_0p1, int pack)
{
    int diff;
    if (pack < 150) return station_0p1 >= 500;
    diff = (int)station_0p1 - pack;
    if (diff < 0) diff = -diff;
    return station_0p1 >= 400 && diff * 5 <= pack;
}

void sm_relay_pins_safe(void)
{
    gpio_config_t io = {
        .pin_bit_mask = (1ULL << CUBE_RELAY_A_GPIO) | (1ULL << CUBE_RELAY_B_GPIO) | (1ULL << CUBE_RELAY_PAR_GPIO),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_set_level(CUBE_RELAY_A_GPIO, 1);
    gpio_set_level(CUBE_RELAY_B_GPIO, 1);
    gpio_set_level(CUBE_RELAY_PAR_GPIO, 1);
    gpio_config(&io);
    gpio_set_level(CUBE_RELAY_A_GPIO, 1);
    gpio_set_level(CUBE_RELAY_B_GPIO, 1);
    gpio_set_level(CUBE_RELAY_PAR_GPIO, 1);
}

esp_err_t sm_relay_init(void)
{
    hv_load();
    sm_relay_pins_safe();
    s_drv_a = 0;
    s_drv_b = 0;
    s_main = ST_IDLE;
    s_sub = 0;
    s_handoff = false;
    s_entry_ms = now_ms();
    app_state_set_main_state(ST_IDLE);
    app_state_set_substate(0);
    app_state_set_handoff(false);
    app_state_set_relays(0, 0);
    app_state_set_session(false);
    ESP_LOGW(TAG, "relays OK A=GPIO%d B=GPIO%d PAR=GPIO%d follows B, converter %s",
             CUBE_RELAY_A_GPIO, CUBE_RELAY_B_GPIO, CUBE_RELAY_PAR_GPIO,
             s_hv_fitted ? "wired" : "absent");
    return ESP_OK;
}

void sm_start_session(void)
{
    if (s_main != ST_IDLE && s_main != ST_STOP && s_main != ST_FINALIZE) {
        ESP_LOGW(TAG, "start ignored, already in state %u", (unsigned)s_main);
        return;
    }
    s_crm_ok = false;
    s_cro_ok = false;
    s_crm00 = false;
    s_crmaa = false;
    s_user_hold = 0;
    s_user_a = 0;
    s_user_b = 0;
    s_bench = 0;
    relays_set(0, 0);
    gbt_b_reset();
    s_sub = 0;
    app_state_set_substate(0);
    app_state_set_session(true);
    set_state(ST_HANDSHAKE_INIT);
}

void sm_request_relay_test(void)
{
    cube_state_snapshot_t st;
    uint32_t t = now_ms();
    int live = (s_last_chg_ms != 0 && (t - s_last_chg_ms) < 3000) ||
               s_main == ST_CHARGING || s_main == ST_READY_WAIT_CRO ||
               s_main == ST_PARAM_CONFIG || s_main == ST_WAIT_CRM ||
               s_main == ST_HANDSHAKE_INIT;
    app_state_snapshot(&st);
    if (live) {
        app_state_log("тест выхода только без станции");
        return;
    }
    s_bench = st.relay_b ? 0 : 1;
    relays_set(0, s_bench);
    app_state_log(s_bench ? "тест выхода ВКЛ" : "тест выхода ВЫКЛ");
}

void sm_stop_session(void)
{
    cube_state_snapshot_t st;
    app_state_snapshot(&st);
    if (st.protocol == 3) gbt_b_request_stop();
    else if (s_main == ST_CHARGING || s_main == ST_READY_WAIT_CRO ||
        s_main == ST_PARAM_CONFIG || s_main == ST_WAIT_CRM) {
        tx_bst();
    }
    end_session();
}

void sm_ble_cmd_0x66(uint8_t val)
{
    if (val == 1 && !s_hv_fitted) {
        app_state_log("IN6 запрещён: преобразователь не подключён");
        return;
    }
    if (val == 1 && s_drv_b == 1) {
        app_state_log("IN6 не вместе с зарядниками");
        return;
    }
    if (val == 0) {
        s_user_a = 0;
        relays_set(0, s_drv_b == 1);
        s_sub = 6;
        app_state_set_substate(6);
        ESP_LOGI(TAG, "BLE 0x66=0 -> GPIO6 OFF substate=6");
    } else if (val == 1) {
        s_user_a = 1;
        relays_set(1, 0);
        s_sub = 3;
        app_state_set_substate(3);
        ESP_LOGI(TAG, "BLE 0x66=1 -> GPIO6 ON substate=3");
    }
}

void sm_user_relay(int which, int on)
{
    int live = s_main == ST_CHARGING || s_main == ST_READY_WAIT_CRO ||
               s_main == ST_PARAM_CONFIG || s_main == ST_WAIT_CRM;
    if (live) {
        app_state_log("реле занято станцией");
        return;
    }
    if (which == 6) {
        if (on && !s_hv_fitted) {
            app_state_log("IN6 запрещён: преобразователь не подключён");
            return;
        }
        s_user_a = on ? 1 : 0;
    } else if (which == 7) s_user_b = on ? 1 : 0;
    else return;
    /* 240 V from the boost must not land on the pack. */
    if (s_user_a && s_user_b) {
        if (which == 6) s_user_b = 0;
        else s_user_a = 0;
    }
    s_user_hold = 1;
    s_bench = s_user_b;
    relays_set(s_user_a, s_user_b);
}

void sm_ble_cmd_0x0D(void)
{
    s_sub = 6;
    app_state_set_substate(6);
    ESP_LOGI(TAG, "BLE 0x0D -> substate=6");
}

uint8_t sm_get_main_state(void) { return s_main; }
uint8_t sm_get_substate(void) { return s_sub; }
bool sm_get_handoff_done(void) { return s_handoff; }

/* Called every 10 ms from CAN/SM task */
void sm_relay_tick(void)
{
    cube_state_snapshot_t st;
    app_state_snapshot(&st);
    uint32_t t = now_ms();

    /* Observe charger signals for transitions */
    if (st.cro_status_raw == 0xAA) s_cro_ok = true;
    if (st.charger_stage == CUBE_STAGE_HANDSHAKE || st.last_cml_ms != 0) {
        /* CRM presence approximated by any handshake traffic */
    }
    /* Simple CRM OK: we saw CHM/CRM stage */
    if (st.charger_stage == CUBE_STAGE_HANDSHAKE || st.charger_stage == CUBE_STAGE_PARAMETER) {
        s_crm_ok = true;
    }

    if (!s_boot_started && t > 400) {
        s_boot_started = true;
        app_state_log("реле свободны, шлю приветствие станции");
    }
    if (s_main == ST_IDLE && s_user_hold) relays_set(s_user_a, s_user_b);
    if (st.rx_count != s_last_rx_count) {
        s_last_rx_count = st.rx_count;
        s_last_chg_ms = t;
    }

    bool skip_a = false;
    if (st.protocol == 3) {
        gbt_b_tick(t);
        if (gbt_b_stop()) {
            if (s_main != ST_IDLE) {
                app_state_log("B session end");
                gbt_b_reset();
                end_session();
            }
        } else if (gbt_b_energy()) {
            if (s_main != ST_CHARGING) set_state(ST_CHARGING);
        }
        if (s_main != ST_CHARGING) skip_a = true;
    }

    if (!skip_a && st.last_cst_ms != 0 && (int32_t)(st.last_cst_ms - s_entry_ms) >= 0 &&
        (s_main == ST_WAIT_CRM || s_main == ST_PARAM_CONFIG || s_main == ST_READY_WAIT_CRO)) {
        s_auto_hold_until = t + 15000;
        end_session();
    } else if (!skip_a) switch (s_main) {
    case ST_IDLE:
        if (st.last_charger_rx_ms != 0 && (t - st.last_charger_rx_ms) < 1000) {
            if (s_station_since == 0) s_station_since = t;
        } else {
            s_station_since = 0;
        }
        if (t > s_auto_hold_until && s_station_since != 0 && (t - s_station_since) >= 600) {
            app_state_log("куб увидел станцию");
            ESP_LOGW(TAG, "куб увидел станцию");
            s_station_since = 0;
            sm_start_session();
            break;
        }
        /* GB/T 27930: the vehicle sends BHM every 250 ms. This pile sends
         * nothing until it hears the cube, so idle must speak. An unanswered
         * hello adds 8 to TEC; drop that at once so the node stays
         * error-active and can still ACK the CHM that comes back. */
        if (t > s_auto_hold_until && gbt_can_get_tx_enabled() &&
            (t - s_last_bhm_ms) >= 250) {
            esp_err_t e = tx_bhm();
            s_last_bhm_ms = t;
            if (e == ESP_OK) {
                if ((t - s_bhm_log_ms) >= 3000) {
                    s_bhm_log_ms = t;
                    app_state_log("приветствие ушло, жду кадр станции");
                    ESP_LOGW(TAG, "приветствие ушло, жду кадр станции");
                }
            } else {
                int tec = 0, rec = 0, crx = 1;
                const char *m;
                gbt_can_counters(&tec, &rec, &crx);
                m = gbt_can_fault();
                if ((t - s_bhm_log_ms) >= 3000) {
                    char line[110];
                    s_bhm_log_ms = t;
                    snprintf(line, sizeof(line), "%s TEC=%d REC=%d CRX=%d",
                             m[0] ? m : "приветствие без ответа", tec, rec, crx);
                    app_state_log(line);
                    ESP_LOGW(TAG, "%s", line);
                }
                gbt_can_recover_if_quiet();
            }
        }
        break;
    case ST_HANDSHAKE_INIT:
        set_state(ST_WAIT_CRM);
        break;

    case ST_WAIT_CRM: {
        /* CRM from the previous plug must not skip BHM. */
        int crm_fresh = st.last_crm_ms != 0 && (int32_t)(st.last_crm_ms - s_entry_ms) >= 0;
        if (crm_fresh) {
            if (st.crm_status == 0xAA) s_crmaa = true;
            else s_crm00 = true;
        }
        if (s_crmaa) {
            app_state_log("станция узнала батарею");
            set_state(ST_PARAM_CONFIG);
        } else if (s_crm00 && (t - s_last_brm_ms) >= 250) {
            /* CRM 0x00: BRM only. A BHM that nobody ACKs holds TEC at 128
             * and the pile never finishes recognition (log 8). */
            esp_err_t e = tx_brm();
            s_last_brm_ms = t;
            if (e != ESP_OK && (t - s_bhm_log_ms) >= 1000) {
                const char *m = gbt_can_fault();
                s_bhm_log_ms = t;
                app_state_log(m[0] ? m : "паспорт батареи не ушёл");
                ESP_LOGW(TAG, "%s", m[0] ? m : "паспорт батареи не ушёл");
            }
        } else if (!s_crm00 && (st.protocol == 0 || st.protocol == 1) && (t - s_last_bhm_ms) >= 250) {
            esp_err_t e = tx_bhm();
            s_last_bhm_ms = t;
            if ((t - s_bhm_log_ms) >= 1000) {
                const char *m = (e == ESP_OK) ? (s_bhm_pri3 ? "приветствие ушло, станция шумная" : "приветствие ушло") : gbt_can_fault();
                s_bhm_log_ms = t;
                app_state_log(m[0] ? m : "приветствие без ответа");
                ESP_LOGW(TAG, "%s", m[0] ? m : "приветствие без ответа");
            }
        }
        if ((t - s_entry_ms) > 30000) {
            int quiet = st.last_charger_rx_ms == 0 || (t - st.last_charger_rx_ms) > 3000;
            if (quiet) {
                /* Do not leave the converter coil on while nobody is talking.
                 * BHM keeps going so a pile that woke up late can still answer. */
                relays_set(0, 0);
                s_entry_ms = t;
                app_state_log("кадров станции нет, преобразователь выкл");
            } else {
                tx_bem(s_crm00 ? 1 : 0);
                end_session();
            }
        }
        break;
    }

    case ST_PARAM_CONFIG:
        if ((t - s_last_bcp_ms) >= 500) {
            tx_bcp();
            s_last_bcp_ms = t;
        }
        if (st.last_cml_ms != 0 && (t - st.last_cml_ms) < 5000) {
            app_state_log("пределы есть, куб готов");
            set_state(ST_READY_WAIT_CRO);
        }
        if ((t - s_entry_ms) > 20000) {
            tx_bem(2);
            end_session();
        }
        break;

    case ST_READY_WAIT_CRO:
        /* 2 s BRO=00: vehicle insulation / contactors not ready, then AA */
        if ((t - s_entry_ms) % 250 < CUBE_SM_TIMEBASE_MS) {
            if ((t - s_entry_ms) < 2000) tx_bro(0x00);
            else tx_bro(0xAA);
        }
        if (s_cro_ok) {
            set_state(ST_CHARGING);
        }
        if ((t - s_entry_ms) > 30000) {
            tx_bem(3);
            end_session();
        }
        break;

    case ST_CHARGING:
        /* Output closes itself after the handshake, once station voltage holds. The tile is not consulted. */
        if (!s_load_on) {
            uint16_t v = st.ccs_output_voltage_raw;
            int pack = pack_0p1();
            int take = 0;
            /* No 12-220 imitator: after the pile says CRO the bus is still
             * near 0 V because it is waiting to measure a battery. The pack
             * is the only voltage we can show it. Never do this while the
             * station is already driving the bus. */
            if (!s_hv_fitted && v < 300 && pack >= 150 && (t - s_entry_ms) >= 500) {
                take = 1;
            } else if (v >= 500 && volts_close(v, pack)) {
                if (s_power_seen_ms == 0 || s_v_anchor == 0) {
                    s_power_seen_ms = t;
                    s_v_anchor = v;
                } else {
                    uint32_t lo = (uint32_t)s_v_anchor - (uint32_t)s_v_anchor / 5u;
                    uint32_t hi = (uint32_t)s_v_anchor + (uint32_t)s_v_anchor / 5u;
                    if (v < lo || v > hi) {
                        s_power_seen_ms = t;
                        s_v_anchor = v;
                    }
                }
                if ((t - s_power_seen_ms) >= 5000) take = 1;
            } else {
                s_power_seen_ms = 0;
                s_v_anchor = 0;
            }
            if (take && relays_set(0, 1)) {
                s_load_on = true;
                s_handoff = true;
                s_bench = 0;
                app_state_set_handoff(true);
                if (!s_hv_fitted && v < 300)
                    app_state_log("преобразователя нет, батарея на шине станции");
                else
                    app_state_log(s_hv_fitted
                        ? "пачка включена, имитация выкл"
                        : "напряжение станции рядом с батареей, зарядники включены");
            }
        } else if (st.ccs_output_voltage_raw < 300 && s_hv_fitted) {
            relays_set(0, 0);
            s_load_on = false;
            s_power_seen_ms = 0;
            s_v_anchor = 0;
            app_state_log("выход ВЫКЛ");
        }
        {
            float v = st.ccs_output_voltage_raw / 10.0f;
            float i = st.ccs_output_current_0p1a / 10.0f;
            if (i < 0) i = -i;
            if (v > 5 && i > 0.2f) app_state_add_energy(v * i, 0.01f);
        }
        if (st.protocol != 3) {
            /* periodic BCL / BCS / BSM and optional BMV/BMT/BSP */
            if ((t - s_last_bcl_ms) >= 50) {
                tx_bcl();
                s_last_bcl_ms = t;
            }
            if ((t - s_last_bcs_ms) >= 250) {
                tx_bcs();
                s_last_bcs_ms = t;
            }
            if ((t - s_last_bsm_ms) >= 250) {
                tx_bsm();
                s_last_bsm_ms = t;
            }
            {
                uint32_t opt_ms = st_proto_is_2011() ? 1000u : 10000u;
                if ((t - s_last_opt_ms) >= opt_ms) {
                    tx_optional_cells();
                    s_last_opt_ms = t;
                }
            }
            if (st.charger_stage == CUBE_STAGE_COMPLETED ||
                st.charger_stage == CUBE_STAGE_ERROR ||
                st.charger_stage == CUBE_STAGE_SUSPENDED) {
                tx_bst();
                tx_bsd();
                end_session();
            }
        }
        break;

    case ST_STOP:
    case ST_FINALIZE:
        relays_fail_safe();
        break;

    default:
        break;
    }
    if (s_main != ST_IDLE && st.last_charger_rx_ms != 0) {
        uint32_t quiet_ms = 3000;
        /* The pile may go quiet while it measures the pack we just connected.
         * Opening again after 3 s would hide the battery before it answers. */
        if (!s_hv_fitted && s_load_on && st.ccs_output_voltage_raw < 300) quiet_ms = 20000;
        if ((t - st.last_charger_rx_ms) > quiet_ms) {
            app_state_log("станция замолчала, реле выкл");
            s_bench = 0;
            s_auto_hold_until = t + 8000;
            sm_stop_session();
        }
    }
}
